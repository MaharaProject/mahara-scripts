<?php

defined('INTERNAL') || die();

$string['annotationreadonlymessage'] = 'Les annotations ne sont plus modifiables une fois qu\'un commentaire a été fait.';
$string['description'] = 'Un bloc qui vous permet d\'afficher vos annotations expliquant comment votre pièce, votre preuve, correspond à un standard de compétence.';
$string['title'] = 'Annotation';
