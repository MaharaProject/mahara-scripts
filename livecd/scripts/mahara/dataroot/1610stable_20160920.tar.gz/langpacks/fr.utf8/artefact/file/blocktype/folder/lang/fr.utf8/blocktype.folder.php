<?php

defined('INTERNAL') || die();

$string['defaultsortorder'] = 'Ordre de tri par déaut des fichiers';
$string['defaulttitledescription'] = 'Si vous ne renseignez pas le titre, le nom du dossier sera affiché';
$string['description'] = 'Un dossier de votre zone de fichiers';
$string['foldersettings'] = 'Paramètres du dossier';
$string['title'] = 'Dossier';
