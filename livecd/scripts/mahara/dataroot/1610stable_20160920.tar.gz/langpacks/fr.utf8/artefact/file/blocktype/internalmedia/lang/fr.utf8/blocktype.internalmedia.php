<?php

defined('INTERNAL') || die();

$string['browsercannotplay'] = 'Votre navigateur Web ne peut pas afficher ce média';
$string['configdesc1'] = 'Déterminez quels types de fichiers les utilisateurs pourront inclurent dans ce bloc. Si vous désactivé un type de fichier qui est déjà utilisé par le bloc, l\'image n\'y sera alors plus affichée.';
$string['description'] = 'Sélectionnez les fichiers à afficher intégrés dans la page';
$string['flashanimation'] = 'Animation Flash';
$string['media'] = 'Média';
$string['title'] = 'Média intégré';
$string['typeremoved'] = 'Ce bloc renferme un contenu de type désactivé par l\'administrateur';
