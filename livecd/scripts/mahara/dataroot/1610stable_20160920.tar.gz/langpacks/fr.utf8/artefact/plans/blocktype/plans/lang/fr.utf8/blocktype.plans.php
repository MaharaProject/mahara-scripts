<?php

defined('INTERNAL') || die();

$string['defaulttitledescription'] = 'Si vous laissez cette rubrique vide, le titre du projet sera utilisé.';
$string['description1'] = 'Afficher un projet (voir Contenu -> Projets)';
$string['newerplans'] = 'Nouveaux projets';
$string['noplansaddone'] = 'Pas de projet pour l\'instant. %sAjoutez-en un%s!';
$string['olderplans'] = 'Anciens projets';
$string['planstoshow'] = 'Choisissez le projet à afficher';
$string['taskstodisplay'] = 'Tâches à afficher';
$string['title'] = 'Vos Projets';
