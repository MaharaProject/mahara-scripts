<?php

defined('INTERNAL') || die();

$string['admin'] = 'Administrateur';
$string['member'] = 'Membre';
$string['name'] = 'Cours';
$string['tutor'] = 'Tuteur';
$string['youaregrouptutor'] = 'Vous êtes tuteur dans ce groupe';
