<?php

defined('INTERNAL') || die();

$string['buildingindexpage'] = 'Création de la page d\'index';
$string['copyingextrafiles'] = 'Duplication des fichiers supplémentaires';
$string['description'] = 'Crée un site web autonome avec votre portfolio. Vous ne pouvez pas le réimporter, mais il est lisible à l\'aide d\'un navigateur web.';
$string['duplicatepagetitle'] = 'L\'exportation a échoué car deux pages portent le même titre. Veuillez vous assurer à ce que les titres de pages soient uniques.';
$string['exportingdatafor'] = 'Exportation des données pour %s';
$string['preparing'] = 'Préparation de %s';
$string['title'] = 'Site web HTML autonome';
$string['usersportfolio'] = 'Portfolio de %s';
