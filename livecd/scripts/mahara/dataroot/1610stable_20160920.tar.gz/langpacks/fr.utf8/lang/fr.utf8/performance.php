<?php

defined('INTERNAL') || die();

$string['cached'] = 'en cache';
$string['csys'] = 'csys';
$string['cuser'] = 'cuser';
$string['dbqueries'] = 'requêtes BD';
$string['included'] = 'Fichiers inclus';
$string['memoryused'] = 'Mémoire';
$string['reads'] = 'lectures';
$string['seconds'] = 'secondes';
$string['serverload'] = 'Charge du serveur';
$string['sys'] = 'sys';
$string['ticks'] = 'ticks';
$string['timeused'] = 'Temps d\'exécution';
$string['user'] = 'utilisateur';
$string['writes'] = 'écritures';
