<?php

defined('INTERNAL') || die();

$string['emailfooter'] = 'Ceci est une notification automatique de « %s ». Pour modifier vos réglages de notification, rendez-vous sur %s';
$string['emailheader'] = 'Une notification vous a été envoyée par « %s ». Voici le message envoyé :';
$string['emailsubject'] = '%s';
$string['name'] = 'Courriel';
$string['referurl'] = 'Pour accéder à ce commentaire, cliquez sur le lien suivant : %s';
