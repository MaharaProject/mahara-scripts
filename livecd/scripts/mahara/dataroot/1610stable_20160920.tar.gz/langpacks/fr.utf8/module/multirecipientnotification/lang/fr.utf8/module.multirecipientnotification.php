<?php

defined('INTERNAL') || die();

$string['cantsendemptysubject'] = 'Un message doit avoir un sujet. Veuillez en saisir un.';
$string['cantsendemptytext'] = 'Votre message est vide. Veuillez saisir votre message.';
$string['cantsendnorecipients'] = 'Veuillez choisir au moins un destinataire pour votre message.';
$string['clickformore'] = '(Pressez la touche « entrée » pour afficher plus de messages)';
$string['composemessage'] = 'Nouveau message';
$string['composemessagedesc'] = 'Créer un nouveau message';
$string['deletednotifications1'] = '%s notifications supprimées. Notez que les notifications internes ne peuvent pas être supprimées de la zone « Envoyées ».';
$string['deleteduser'] = 'utilisateur(s) supprimé(s)';
$string['fromuser'] = 'De';
$string['inboxdesc1'] = 'Messages envoyés par le système et les autres utilisateurs';
$string['labelinbox'] = 'Boîte de réception';
$string['labeloutbox1'] = 'Boîte d\'envoi';
$string['labelrecipients'] = 'À : ';
$string['labelsubject'] = 'Objet :';
$string['linkindicator'] = '»';
$string['notification'] = 'Notifications';
$string['outboxdesc'] = 'Messages envoyés à d\'autres utilisateurs';
$string['removeduserfromlist'] = 'Un utilisateur qui ne pouvait pas recevoir de message de votre part a été supprimé de la liste de destinataires.';
$string['reply'] = 'Répondre';
$string['replyall'] = 'Répondre à tous';
$string['replybuttonplaceholder'] = '...';
$string['replysubjectprefix'] = 'Re :';
$string['selectalldelete'] = 'Toutes les notifications marquées pour suppression';
$string['selectallread'] = 'Toutes les notifications non lues';
$string['sendmessageto'] = 'Envoyer le message';
$string['titlerecipient'] = 'Destinataires';
$string['titlesubject'] = 'Objet';
$string['touser'] = 'À';
