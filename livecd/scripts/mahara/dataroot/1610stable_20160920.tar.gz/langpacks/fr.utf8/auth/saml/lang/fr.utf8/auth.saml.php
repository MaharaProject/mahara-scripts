<?php

defined('INTERNAL') || die();

$string['defaultinstitution'] = 'Default institution';
$string['description'] = 'Authentification à l\'aide d\'un service SAML2.0 IdP';
$string['errnosamluser'] = 'No User found';
$string['errorbadcombo'] = 'Vous ne pouvez activer l\'option d\'autocréation seulement si vous n\'avez pas sélectionné l\'option des utilisateurs distants.';
$string['errorbadconfig'] = 'Le chemin vers le fichier de configuration de SimpleSAMLPHP %s est invalide.';
$string['errorbadinstitution'] = 'Institution for connecting user not resolved';
$string['errorbadinstitutioncombo'] = 'Il existe déjà une combinaison de cette instance d\'authentification avec cet attribut d\'institution et cette valeur d\'attribut.';
$string['errorbadlib'] = 'Le chemin vers la librairie SimpleSAMLPHP %s est invalide.';
$string['errorbadssphp'] = 'Paramètre de session SimpleSAML.php invalide - ne doit pas être phpsession';
$string['errorbadssphplib'] = 'Configuration de la librairie SimpleSAML.php invalide';
$string['errormissinguserattributes1'] = 'Nous avons pu vous authentifier mais nous n\'avons pas reçu les renseignements attendus de la plateforme d\'authentification. Veuillez vérifier avec cette dernière qu\'elle envoie bien le Prénom, le Nom et l\'Adresse mail des utilisateurs lors de la connexion SSO à %s, ou informez votre administrateur de ce problème.';
$string['errorregistrationenabledwithautocreate'] = 'Une institution a l\'option d\'enregistrement des utilisateurs activée, pour des raisons de sécurité le système de création automatique de comptes a été enlevée.';
$string['errorremoteuser'] = 'L\'appariement sur remoteuser est obligatoire lorsque useruniquebyusername est désactivé.';
$string['errorretryexceeded'] = 'Maximum number of retries exceeded (%s) - there must be a problem with the Identity Service';
$string['institutionattribute'] = 'L\'attribut d\'institution (contient « %s »)';
$string['institutionregex'] = 'Utiliser une chaîne partielle sur le nom court de l\'institution';
$string['institutionvalue'] = 'Valeur à tester avec l\'attribut de l\'institution';
$string['link'] = 'Lier les comptes';
$string['linkaccounts'] = 'Désirez-vous lier le compte distant %s avec le local local %s ?';
$string['login'] = 'Connexion SSO';
$string['loginlink'] = 'Permettre aux utilisateurs de lier leur propre compte';
$string['logintolink'] = 'Accès local à %s pour le lier au compte distant';
$string['logintolinkdesc'] = '<p><b>Vous êtes actuellement connecté avec l\'utilisateur distant %s. Veuillez vous connecter sur votre compte local afin de les lier l\'un à l\'autre, ou enregistrez-vous si vous n\'avez pas déjà un compte sur %s.</b></p>';
$string['notusable'] = 'Veuillez installer les librairie de SimpleSAMLPHP SP';
$string['remoteuser'] = 'Faire correspondre le nom d\'utilisateur avec celui du serveur distant';
$string['samlfieldforemail'] = 'Rubrique SSO pour le courriel';
$string['samlfieldforfirstname'] = 'Rubrique SSO pour le prénom';
$string['samlfieldforsurname'] = 'Rubrique SSO pour le nom';
$string['simplesamlphpconfig'] = 'Chemin vers le fichier de configuration SimpleSAMLPHP';
$string['simplesamlphplib'] = 'Chemin vers la librairie SimpleSAMLPHP';
$string['title'] = 'SAML';
$string['updateuserinfoonlogin'] = 'Update user details on login';
$string['userattribute'] = 'Attribut utilisateur';
$string['weautocreateusers'] = 'Mahara crée automatiquement les utilisateurs';
