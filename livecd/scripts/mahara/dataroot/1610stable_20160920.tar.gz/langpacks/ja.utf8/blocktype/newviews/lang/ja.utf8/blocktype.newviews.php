<?php

defined('INTERNAL') || die();

$string['defaulttitledescription'] = 'タイトルフィールドを空白にした場合、デフォルトタイトルが生成されます。';
$string['description2'] = 'このサイトにおいて、あなたがアクセスした中から最も最近に更新されたページおよびコレクションを一覧表示します。';
$string['title1'] = '私が閲覧できる最新の変更';
$string['viewstoshow1'] = '表示する結果の最大数';
$string['viewstoshowdescription'] = '設定範囲: 1～100';
