<?php

defined('INTERNAL') || die();

$string['description1'] = 'あなたのプロファイルを閲覧している人に対して、あなたの閲覧可能なポートフォリオすべてを表示します。';
$string['otherusertitle1'] = '%s のポートフォリオ';
$string['title1'] = 'マイポートフォリオ';
