<?php

defined('INTERNAL') || die();

$string['collection'] = 'コレクション';
$string['defaulttitledescription'] = 'ここを空白にした場合、コレクションのタイトルが使用されます。';
$string['description'] = 'ページコレクションのナビゲーションです (「ポートフォリオ -> コレクション」、グループ内の場合はコレクションタブをご覧ください)。';
$string['nocollections1'] = 'コレクションはありません。<a href="%s">コレクションを作成してください</a>。';
$string['title'] = 'ナビゲーション';
