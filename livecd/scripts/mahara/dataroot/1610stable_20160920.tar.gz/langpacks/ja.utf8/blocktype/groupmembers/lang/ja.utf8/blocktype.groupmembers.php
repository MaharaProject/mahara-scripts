<?php

defined('INTERNAL') || die();

$string['Latest'] = '最新';
$string['Random'] = 'ランダム';
$string['defaulttitledescription'] = 'タイトルフィールドを空白にした場合、デフォルトタイトルが生成されます。';
$string['description'] = 'このグループのメンバーを一覧表示します。';
$string['options_numtoshow_desc'] = 'あなたが表示したいメンバー数です。';
$string['options_numtoshow_title'] = '表示メンバー';
$string['options_order_desc'] = 'あなたはグループメンバーの表示順に関して、最新グループメンバーまたはランダムを選択することができます。';
$string['options_order_title'] = '表示順';
$string['show_all'] = 'このグループのメンバーすべてを表示する ...';
$string['title'] = 'グループメンバー';
