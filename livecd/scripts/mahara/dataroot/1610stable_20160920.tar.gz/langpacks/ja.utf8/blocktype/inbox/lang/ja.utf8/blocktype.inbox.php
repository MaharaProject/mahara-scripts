<?php

defined('INTERNAL') || die();

$string['More'] = 'さらに';
$string['defaulttitledescription'] = 'タイトルフィールドを空白にした場合、デフォルトタイトルが生成されます。';
$string['description'] = 'あなたの受信箱から選択された最近のメッセージを表示します';
$string['maxitems'] = '表示するアイテムの最大数';
$string['maxitemsdescription'] = '設定範囲: 1～100';
$string['messagetypes'] = '表示するメッセージタイプ';
$string['nomessages'] = 'メッセージなし';
$string['title'] = '受信箱';
