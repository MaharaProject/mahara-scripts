<?php

defined('INTERNAL') || die();

$string['exactusersearch'] = 'ユーザ厳密検索';
$string['exactusersearchdescription1'] = 'この設定を有効にした場合、「ユーザを検索する」ボックスおよび「フレンドを探す」ページの結果には、検索キーワード全体に合致するプロファイルフィールドのユーザのみ表示されます。';
