<?php

defined('INTERNAL') || die();

$string['Files'] = 'ファイル';
$string['description'] = 'ユーザがダウンロードできるファイルを選択してください (「コンテンツ -> ファイル」をご覧ください)。';
$string['title'] = 'ダウンロードできるファイル';
