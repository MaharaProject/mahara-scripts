<?php

defined('INTERNAL') || die();

$string['description'] = '表示するソーシャルメディアアカウントを選択する';
$string['displayaddressesas'] = '次のようにソーシャルメディアアカウントを表示する:';
$string['displaydefaultemail'] = 'ボタンとしてデフォルトメールアドレスのリンクを表示しますか?';
$string['displaymsgservices'] = 'ボタンとしてメッセージングサービスを表示しますか?';
$string['displaysettings'] = '表示設定';
$string['optionicononly'] = 'アイコンのみのボタン';
$string['optiontexticon'] = 'アイコンおよびテキストのボタン';
$string['optiontextonly'] = 'テキストのみのボタン';
$string['profilestoshow'] = '表示するソーシャルメディアアカウント';
$string['title'] = 'ソーシャルメディア';
