<?php

defined('INTERNAL') || die();

$string['configdesc1'] = 'どのタイプのファイルをユーザがこのブロックに埋め込むことができるか設定します。あなたがすでにブロックで使用しているファイルタイプを無効にした場合、表示されないようになります。';
$string['description'] = '埋め込みメディアのファイルを選択してください。';
$string['flashanimation'] = 'Flashアニメーション';
$string['media'] = 'メディア';
$string['title'] = '埋め込みメディア';
$string['typeremoved'] = 'このブロックでは管理者によって許可されないメディアタイプを示します。';
