<?php

defined('INTERNAL') || die();

$string['blockcontent'] = 'ブロックコンテンツ';
$string['description'] = 'あなたのページにテキストボックスを追加します。';
$string['makeacopy'] = 'コピーを作成する';
$string['managealltextboxcontent1'] = 'すべてのノートコンテンツを管理する';
$string['readonlymessage'] = 'あなたが選択したテキストはこのページで編集することはできません。';
$string['textusedinotherblocks'] = 'あなたがこのブロックのテキストを編集した場合、テキストが表示されている他の %s 件のブロックも更新されます。';
$string['textusedinothernotes'] = array(
    0 => 'あなたがこのノートのテキストを編集した場合、テキストが表示されている %s 件のブロックでも更新されます。',
);
$string['title'] = 'ノート';
$string['usecontentfromanothertextbox1'] = '別のノートのコンテンツを使用する';
