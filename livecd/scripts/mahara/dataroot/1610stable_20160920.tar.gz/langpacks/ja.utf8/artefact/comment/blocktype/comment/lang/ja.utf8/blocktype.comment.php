<?php

defined('INTERNAL') || die();

$string['description'] = 'コメントを表示するブロック';
$string['ineditordescription1'] = 'このページのコメントはページ下部ではなく、ここに表示されます。';
$string['title'] = 'コメント';
