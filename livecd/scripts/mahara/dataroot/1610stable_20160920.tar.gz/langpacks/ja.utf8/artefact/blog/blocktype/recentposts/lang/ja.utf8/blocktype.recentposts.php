<?php

defined('INTERNAL') || die();

$string['description'] = '最新の日誌エントリを表示します (「コンテンツ -> 日誌」をご覧ください)。';
$string['itemstoshow'] = '表示するアイテム数';
$string['postedin'] = '-';
$string['postedon'] = '投稿日時';
$string['title'] = '最新の日誌エントリ';
