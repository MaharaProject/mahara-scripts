<?php

defined('INTERNAL') || die();

$string['description'] = 'あなたのファイルエリアの単独イメージです。';
$string['showdescription'] = '説明を表示する';
$string['title'] = 'イメージ';
$string['width'] = '幅';
$string['widthdescription1'] = 'あなたのイメージの幅 (ピクセル) を指定してください。イメージがこの幅にサイズ変更されます。オリジナルサイズが大きすぎる場合、ブロック幅に縮小されます。';
