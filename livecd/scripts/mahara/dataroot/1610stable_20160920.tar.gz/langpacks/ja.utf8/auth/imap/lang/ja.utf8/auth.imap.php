<?php

defined('INTERNAL') || die();

$string['description'] = 'IMAPメールサーバで認証する';
$string['notusable'] = 'PHP IMAP拡張モジュールをインストールしてください。';
$string['title'] = 'IMAP';
