<?php

defined('INTERNAL') || die();

$string['description'] = '外部アプリケーションからのSSOで認証する';
$string['networkingdisabledonthissite'] = 'このサイトではネットワーキングが無効にされています。';
$string['networkservers'] = 'ネットワークサーバ';
$string['notusable'] = 'XML-RPC、CurlおよびOpenSSL PHP拡張モジュールをインストールしてください。';
$string['title'] = 'XML-RPC';
$string['youhaveloggedinfrom1'] = '<a href="%s">%s</a>に戻る';
