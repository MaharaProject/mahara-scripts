<?php

defined('INTERNAL') || die();

$string['cantsendemptysubject'] = 'あなたの件名は空です。件名を入力してください。';
$string['cantsendemptytext'] = 'あなたのメッセージは空です。メッセージを入力してください。';
$string['cantsendnorecipients'] = '少なくとも1名の受信者を選択してください。';
$string['clickformore'] = '(さらに情報を表示するには「Enter」を押してください)';
$string['composemessage'] = '作成';
$string['composemessagedesc'] = '新しいメッセージを作成する';
$string['deletednotifications1'] = '%s 件の通知が削除されました。内部通知は「送信」エリアから削除できないことに留意してください。';
$string['deleteduser'] = '削除済みユーザ';
$string['fromuser'] = 'From';
$string['inboxdesc1'] = 'システムおよび他のユーザから受信したメッセージ';
$string['labelinbox'] = '受信箱';
$string['labeloutbox1'] = '送信済み';
$string['labelrecipients'] = 'To: ';
$string['labelsubject'] = '件名:';
$string['linkindicator'] = '»';
$string['notification'] = '通知';
$string['outboxdesc'] = '他のユーザに送信されたメッセージ';
$string['removeduserfromlist'] = 'あなたからのメッセージを受信できないユーザは受信者リストから削除されました。';
$string['reply'] = '返信';
$string['replyall'] = 'すべてに返信する';
$string['replybuttonplaceholder'] = '...';
$string['replysubjectprefix'] = 'Re:';
$string['selectalldelete'] = '削除のためにすべての通知';
$string['selectallread'] = 'すべての未読通知';
$string['sendmessageto'] = 'メッセージを送信する';
$string['titlerecipient'] = '受信者';
$string['titlesubject'] = '件名';
$string['touser'] = 'To';
