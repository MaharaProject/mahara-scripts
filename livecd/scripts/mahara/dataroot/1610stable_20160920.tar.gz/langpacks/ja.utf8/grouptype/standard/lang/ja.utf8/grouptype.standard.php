<?php

defined('INTERNAL') || die();

$string['admin'] = '管理者';
$string['member'] = 'メンバー';
$string['name'] = 'スタンダード';
