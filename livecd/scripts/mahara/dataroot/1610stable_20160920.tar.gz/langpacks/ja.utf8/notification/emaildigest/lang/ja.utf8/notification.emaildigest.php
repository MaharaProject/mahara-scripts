<?php

defined('INTERNAL') || die();

$string['emailbodyending'] = 'あなたの通知プリファレンスを更新するには、%s にアクセスしてください。';
$string['emailbodynoreply'] = 'これは %s から自動的に生成された通知メールです。以下、あなたのすべての通知に関するデイリーダイジェストです。

--------------------------------------------------

';
$string['emailsubject'] = '%s からのメッセージ: デイリーダイジェスト';
$string['name'] = 'メールダイジェスト';
