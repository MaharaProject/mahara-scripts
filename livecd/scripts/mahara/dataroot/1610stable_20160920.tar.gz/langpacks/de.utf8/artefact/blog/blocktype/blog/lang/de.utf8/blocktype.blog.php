<?php

defined('INTERNAL') || die();

$string['defaulttitledescription'] = 'Wenn Sie dieses Feld leer lassen, wird der Titel des Blogs verwendet.';
$string['description'] = 'Einen gesamten Blog anzeigen';
$string['postsperpage'] = 'Blogeinträge pro Seite';
$string['title'] = 'Blog';
