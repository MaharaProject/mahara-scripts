<?php

defined('INTERNAL') || die();

$string['description'] = 'Einzelne PDF-Datei aus Ihrer Dateiablage';
$string['title'] = 'PDF';
