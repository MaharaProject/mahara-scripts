<?php

defined('INTERNAL') || die();

$string['defaulttitledescription'] = 'Wenn du das Feld leer lässt, wir der Titel des Feldes benutzt';
$string['description'] = 'Anzeige von Biografieinformationen';
$string['fieldtoshow'] = 'Feld, das angezeigt werden soll';
$string['filloutyourresume'] = '%sBiografie ausfüllen%s und weitere Felder einfügen!';
$string['title'] = 'Ein Biografiefeld';
