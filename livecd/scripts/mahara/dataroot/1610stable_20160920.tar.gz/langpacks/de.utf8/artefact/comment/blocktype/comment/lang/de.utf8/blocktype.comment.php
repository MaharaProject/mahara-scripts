<?php

defined('INTERNAL') || die();

$string['description'] = 'Block zur Anzeige des Feedbacks';
$string['ineditordescription1'] = 'Feedback für diese Ansicht wird an dieser Stelle und nicht am Ende der Seite angezeigt.';
$string['title'] = 'Feedback';
