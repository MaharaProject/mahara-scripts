<?php

defined('INTERNAL') || die();

$string['defaulttitledescription'] = 'Wenn du das Feld leer lässt, wird der Titel des Plans benutzt.';
$string['description1'] = 'Zeige einen Plan (siehe Inhalt -> Pläne)';
$string['newerplans'] = 'Neuere Pläne';
$string['noplansaddone'] = 'Es sind noch keine Pläne vorhanden. %sPläne anlegen%s!';
$string['olderplans'] = 'Ältere Pläne';
$string['planstoshow'] = 'Pläne zur Anzeige';
$string['title'] = 'Pläne';
