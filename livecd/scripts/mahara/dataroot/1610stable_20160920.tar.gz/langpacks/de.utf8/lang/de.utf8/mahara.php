<?php

defined('INTERNAL') || die();

$string['All'] = 'Alle';
$string['Allinstitutions'] = 'Alle Institutionen';
$string['Artefact'] = 'Artefakt';
$string['Artefacts'] = 'Artefakte';
$string['Close'] = 'Schließen';
$string['Content'] = 'Inhalt';
$string['Copyof'] = 'Kopie von %s';
$string['Created'] = 'Erstellt';
$string['Failed'] = 'Fehlgeschlagen';
$string['From'] = 'Von';
$string['Help'] = 'Hilfe';
$string['Hide2'] = 'Informatiosnbox verbergen';
$string['Invitations'] = 'Einladungen';
$string['Memberships'] = 'Mitgliedschaften';
$string['Permissions'] = 'Berechtigungen';
$string['Query'] = 'Suchanfrage';
$string['Requests'] = 'Anfragen';
$string['Results'] = 'Ergebnisse';
$string['Site'] = 'Site';
$string['Tag'] = 'Schlagwort';
$string['Title'] = 'Bezeichnung';
$string['To'] = 'Bis';
$string['Total'] = 'Gesamt';
$string['Updated'] = 'Aktualisiert';
$string['Visibility'] = 'Sichtbarkeit';
$string['Visits'] = 'Besuche';
$string['about'] = 'Über';
$string['accept'] = 'Bestätigen';
$string['accessforbiddentoadminsection'] = 'Du hast keine Zugangsberechtigung für den Administrations-Bereich';
$string['accesstotallydenied_institutionsuspended'] = 'Deine Institution %s wurde gesperrt.  Du kannst dich erst wieder bei %s anmelden, wenn die Institution freigegeben wurde.
Bitte melde dich bei der Institution für weitergehende Unterstützung.';
$string['account'] = 'Einstellungen';
$string['accountcreated'] = '%s: Neuer Nutzerzugang';
$string['accountcreatedchangepasswordhtml'] = '<p>Guten Tag %s</p>

<p>für dich wurde bei <a href="%s">%s</a> ein neuer Nutzerzugang angelegt. Hier folgen die Einzelheiten:</p>

<ul>
    <li><strong>Nutzername:</strong> %s</li>
    <li><strong>Passwort:</strong> %s</li>
</ul>

<p>Beim 1. Anmelden wirst du Sie aufgefordert, das Passwort zu ändern.</p>

<p>Besuche <a href="%s">%s</a> um zu starten!</p>

<p>Mit freundlichen Grüßen 
%s (Site-Administration)</p>
';
$string['accountcreatedchangepasswordtext'] = 'Guten Tag %s,

für dich wurde bei %s ein neuer Nutzerzugang angelegt. Hier folgen die Einzelheiten:

Nutzername: %s
Passwort: %s

Beim 1. Anmelden wirst due aufgefordert, das Passwort zu ändern.

Besuche %s um zu starten!

Mit freundlichen Grüßen
%s (Site-Administration)';
$string['accountcreatedhtml'] = '<p>Guten Tag %s,</p>

<p>für dich wurde bei <a href="%s">%s</a> ein neuer Nutzerzugang angelegt. Hier folgen die Einzelheiten:</p>

<ul>
    <li><strong>Nutzername:</strong> %s</li>
    <li><strong>Passwort:</strong> %s</li>
</ul>


<p>Besuchee <a href="%s">%s</a> um zu starten!</p>

<p>Mit freundlichen Grüßen 
%s (Site-Administration)</p>
';
$string['accountcreatedtext'] = 'Guten Tag %s,

für dich wurde bei %s ein neuer Nutzerzugang angelegt. Hier folgen die Einzelheiten:

Nutzername: %s
Passwort: %s

Besuche %s um zu starten!

Mit freundlichen Grüßen
 %s (Site- Administration)';
$string['accountdeleted'] = 'Entschuldigung, Ihr Konto wurde gelöscht.';
$string['accountexpired'] = 'Entschuldigung, Ihr Konto ist abgelaufen.';
$string['accountexpirywarning'] = 'Achtung, Ihr Konto läuft bald aus.';
$string['accountexpirywarninghtml'] = '<p>Guten Tag  %s,</p>
    
<p>dein Zugang auf %s wird innerhalb von %s ablaufen.</p>

<p>Wir empfehlen, dass du die Inhalte deines Portfolios mit dem Exporttool sichern. Die Beschreibung hierzu findest du in den Nutzeranleitungen.</p>

<p>Wenn du deinen Zugang verlängern willst oder Fragen hast, nimm bitte mit uns Kontakt auf <a href="%s">Kontaktaufnahme</a>.</p>

<p>Freudliche Grüße, %s Site Administrator</p>';
$string['accountexpirywarningtext'] = 'Guten Tag  %s,

dein Konto %s wird innerhalb von %s ablaufen.

Wir empfehlen, dass du die Inhalte deines Portfolios mit dem Exporttool sicherst. Die Beschreibung hierzu findest du in den Nutzeranleitungen.

Wenn du den Zugang verlängern willst oder Fragen hast, nimm bitte mit uns Kontakt auf:

%s

Freudliche Grüße, %s Site Administrator';
$string['accountinactive'] = 'Entschuldigung, Ihr Konto ist zur Zeit nicht aktiv';
$string['accountinactivewarning'] = 'Hinweis: Ihr Portfolio-Nutzerzugang ist inaktiv';
$string['accountinactivewarninghtml'] = '<p>Guten Tag  %s,</p>

<p>dein Zugang bei %s wird in  Kürze (%s) enden.</p>

<p>Du kannst den Zugang erst dann wieder benützen, wenn ein Administrator den Zugang freigeschaltet hat.</p>

<p>Du kannst dieses umgehen, indem du dich erneut anmeldst.</p>

<p>Mit freundlichen Grüßen, 

%s (Site-Administration)</p>';
$string['accountinactivewarningtext'] = 'Guten Tag %s,

Ihr Zugang bei %s wird in Kürze (%s) enden.

du kannst den Zugang dann erst wieder benützen, wenn ein Administrator den Zugang wieder freigeschaltet hat.

Du kannst dies umgehen, indem du sich erneut anmeldst.

Mit freundlichen Grüßen, 

%s (Site-Administration)';
$string['accountprefs'] = 'Einstellungen';
$string['accountsuspended'] = 'Ihr Zugangskonto wurde vorübergehend gesperrt %s. Der Grund hierfür ist: <b>%s</b>';
$string['activityprefs'] = 'Nachrichteneinstellungen';
$string['add'] = 'Hinzufügen';
$string['addemail'] = 'E-Mail-Adresse hinzufügen';
$string['addone'] = 'Weiteres hinzufügen';
$string['admin'] = 'ADMIN';
$string['adminfirst'] = 'Administratoren zuerst';
$string['administration'] = 'Administration';
$string['adminofinstitutions'] = 'Administrator/in für %s';
$string['adminphpuploaderror'] = 'Ihre Serverkonfiguration hat möglicherweise beim Hochladen der Datei einen Fehler verursacht.';
$string['after'] = 'nach';
$string['alignment'] = 'Ausrichtung';
$string['allonline'] = 'Online-Nutzer/innen anzeigen';
$string['allowpublicaccess'] = 'Öffentlichen Zugang erlauben';
$string['alltags'] = 'Alle Schlagwörter';
$string['allusers'] = 'Alle Nutzer/innen';
$string['alphabet'] = 'A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z';
$string['anonymoususer'] = '(Name des Autors verborgen)';
$string['applychanges'] = 'Änderungen übernehmen';
$string['approvalrequired'] = 'Bestätigung erforderlich';
$string['artefact'] = 'Artefakt';
$string['artefactnotfound'] = 'Das Artefakt mit der ID %s wurde nicht gefunden';
$string['artefactnotpublishable'] = 'Das Artefakt %s ist nicht zur Veröffentlichung in der Ansicht %s geeignet';
$string['artefactnotrendered'] = 'Artefakt wurde nicht richtig geladen';
$string['artefacts'] = 'Artefakte';
$string['ascending'] = 'Aufsteigend';
$string['at'] = 'bei';
$string['attachedimage'] = 'Angehängtes Bild';
$string['attachment'] = 'Anhang';
$string['authentication'] = 'Authentifizierung';
$string['back'] = 'Zurück';
$string['backto'] = 'Zurück zu %s';
$string['before'] = 'vor';
$string['belongingto'] = 'Gehört zu';
$string['betweenxandy'] = 'Zwischen %s und %s';
$string['blacklisteddomaininurl'] = 'Eine URL in diesem Feld enthält die Blacklistdomain %s und wird gesperrt.';
$string['blocks'] = 'Blöcke';
$string['border'] = 'Rahmenbreite';
$string['bulkselect'] = 'Nutzer zum Bearbeiten / für Bericht auswählen';
$string['bytes'] = 'Bytes';
$string['cancel'] = 'Abbrechen';
$string['cancelrequest'] = 'Anfrage abbrechen';
$string['cannotremovedefaultemail'] = 'Du kannst die primäre E-Mail Adresse nicht löschen';
$string['cantbedeleted'] = 'Dieses Artefakt kann nicht gelöscht werden, da es selbst oder Teilartefakte in eingereichten Ansichten genutzt werden.';
$string['cantchangepassword'] = 'Entschuldigung, du kannst dein Passwort hier nicht abändern - bitte benutze dafür die Möglichkeiten der Nutzerverwaltung deiner Institution.';
$string['cantmoveitem'] = 'Dieses Artefakt kann nicht verschoben werden';
$string['change'] = 'Ändern';
$string['changepassword'] = 'Passwort ändern';
$string['changepasswordinfo'] = 'Du musst dein Passwort ändern, bevor du weitermachen kannst.';
$string['chooseinstitution'] = 'Wählen deine Institution';
$string['choosetheme'] = 'Theme auswählen ...';
$string['chooseusernamepassword'] = 'Bitte lege deinen Nutzernamen und das Passwort fest';
$string['chooseusernamepasswordinfo'] = 'Um sich bei %s anzumelden, benötigst du einen Nutzernamen und ein Passwort.  Bitte lege beides jetzt an.';
$string['clambroken'] = 'Die Administrator/innen haben die Virenprüfung aktiviert, aber es scheint ein Fehler bei der Konfiguration vorzuliegen. Das Hochladen der Datei ist fehlgeschlagen. Deine/e Administrator/innen wurden benachrichtigt um dies zu beheben. Vielleicht versuche das Hochladen später noch einmal.';
$string['clamdeletedfile'] = 'Die Datei wurde gelöscht';
$string['clamdeletedfilefailed'] = 'Die Datei konnte nicht gelöscht werden';
$string['clamemailsubject'] = '%s :: Clam AV Benachrichtigung';
$string['clamfailed'] = 'Clam AV konnte nicht ausgeführt werden.  Der gemeldete Fehlercode war %s. Hier ist die Ausgabe:';
$string['clamlost'] = 'Clam AV wurde so konfiguriert, dass es beim Hochladen einer Datei aufgerufen wird, aber der Suchpfad %s ist ungültig.';
$string['clammovedfile'] = 'Die Datei wurde in eine Quarantäne-Verzeichnis verschoben.';
$string['clamnotset'] = 'Du hast die Virenprüfung aktiviert. Du hast jedoch noch keinen Pfad zu \'ClamAV\' eingetragen. Die Virenprüfunbg kann erst dann vorgenommen werden wenn ein Pfad zu ClamAV als Eintrag in deiner config-php-Datei als $cfg->pathtoclam Wert erfolgt ist.';
$string['clamunknownerror'] = 'Bei der Benutzung von Clam AV ist ein unbekannter Fehler aufgetreten.';
$string['cleanurlallowedcharacters'] = 'Nur Kleinbuchstaben von \'a\' bis \'z\', Zahlen und \'-\' sind zulässig.';
$string['cli_incorrect_value'] = 'Falscher Wert, bitte versuchen Sie es erneut.';
$string['clickformore'] = '(Mit der Eingabeteatse erhalten Sie weitere Informationen)';
$string['closehelp'] = 'Hilfe schließen';
$string['collapse'] = 'Zusammenklappen';
$string['complaint'] = 'Beschwerde';
$string['complete'] = 'Vollständig';
$string['config'] = 'Konfiguration';
$string['configfor'] = 'Konfiguration für';
$string['confirmdeletetag'] = 'Willst du dieses Schlagwort wirklich aus allen Elementen Ihres Portfolio löschen?';
$string['confirminvitation'] = 'Einladung bestätigen';
$string['confirmpassword'] = 'Passwort bestätigen';
$string['constrain'] = 'Beschränkung';
$string['contactus'] = 'Kontaktaufnahme';
$string['content'] = 'Inhalt';
$string['cookiesnotenabled'] = 'Dein Browser erlaubt keine Cookies oder blockiert sie von dieser Seite. Mahara erfordert Cookies, um dir den Zugang zu den verschiedenen Seiten zu erlauben';
$string['copy'] = 'Kopieren';
$string['copytoclipboard'] = 'Geheime URL in die Zwischenablage kopieren';
$string['couldnotgethelp'] = 'Beim Lesen der Hilfedatei ist ein Fehler aufgetreten';
$string['country.ad'] = 'Andorra';
$string['country.ae'] = 'Vereinigte Arabische Emirate';
$string['country.af'] = 'Afghanistan';
$string['country.ag'] = 'Antigua und Barbados';
$string['country.ai'] = 'Anguilla';
$string['country.al'] = 'Albanien';
$string['country.am'] = 'Armenien';
$string['country.an'] = 'Niederländische Antillen';
$string['country.ao'] = 'Angola';
$string['country.aq'] = 'Antarktis';
$string['country.ar'] = 'Argentinien';
$string['country.as'] = 'Amerikan. Samoa';
$string['country.at'] = 'Österreich';
$string['country.au'] = 'Australien';
$string['country.aw'] = 'Aruba';
$string['country.ax'] = 'Åland Inseln';
$string['country.az'] = 'Aserbaidschan';
$string['country.ba'] = 'Bosnien und Herzegowina';
$string['country.bb'] = 'Barbados';
$string['country.bd'] = 'Bangladesch';
$string['country.be'] = 'Belgien';
$string['country.bf'] = 'Burkina Faso';
$string['country.bg'] = 'Bulgarien';
$string['country.bh'] = 'Bahrain';
$string['country.bi'] = 'Burundi';
$string['country.bj'] = 'Benin';
$string['country.bm'] = 'Bermuda';
$string['country.bn'] = 'Brunei';
$string['country.bo'] = 'Bolivien';
$string['country.br'] = 'Brasilien';
$string['country.bs'] = 'Bahamas';
$string['country.bt'] = 'Bhutan';
$string['country.bv'] = 'Bouvet Inseln';
$string['country.bw'] = 'Botswana';
$string['country.by'] = 'Weißrussland';
$string['country.bz'] = 'Belize';
$string['country.ca'] = 'Kanada';
$string['country.cc'] = 'Cocos Inseln';
$string['country.cd'] = 'Demokratische Republik Congo';
$string['country.cf'] = 'Zentralafrikanische Republik';
$string['country.cg'] = 'Kongo';
$string['country.ch'] = 'Schweiz';
$string['country.ci'] = 'Elfenbeinküste';
$string['country.ck'] = 'Cook Inseln';
$string['country.cl'] = 'Chile';
$string['country.cm'] = 'Kamerun';
$string['country.cn'] = 'China';
$string['country.co'] = 'Kolumbien';
$string['country.cr'] = 'Costa Rica';
$string['country.cs'] = 'Serbien und Montenegro';
$string['country.cu'] = 'Kuba';
$string['country.cv'] = 'Cap Verde';
$string['country.cx'] = 'Weihnachtsinseln';
$string['country.cy'] = 'Zypern';
$string['country.cz'] = 'Tschechische Republik';
$string['country.de'] = 'Deutschland';
$string['country.dj'] = 'Djibuti';
$string['country.dk'] = 'Dänemark';
$string['country.dm'] = 'Dominica';
$string['country.do'] = 'Dominikanische Republik';
$string['country.dz'] = 'Algerien';
$string['country.ec'] = 'Ecuador';
$string['country.ee'] = 'Estland';
$string['country.eg'] = 'Ägypten';
$string['country.eh'] = 'Westsahara';
$string['country.er'] = 'Eritrea';
$string['country.es'] = 'Spanien';
$string['country.et'] = 'Äthiopien';
$string['country.fi'] = 'Finnland';
$string['country.fj'] = 'Fiji';
$string['country.fk'] = 'Falkland Inseln';
$string['country.fm'] = 'Mikronesien';
$string['country.fo'] = 'Färoer-Inseln';
$string['country.fr'] = 'Frankreich';
$string['country.ga'] = 'Gabun';
$string['country.gb'] = 'Großbritannien';
$string['country.gd'] = 'Grenada';
$string['country.ge'] = 'Georgien';
$string['country.gf'] = 'Franz. Guiana';
$string['country.gg'] = 'Guernsey';
$string['country.gh'] = 'Ghana';
$string['country.gi'] = 'Gibraltar';
$string['country.gl'] = 'Grönland';
$string['country.gm'] = 'Gambia';
$string['country.gn'] = 'Guinea';
$string['country.gp'] = 'Guadeloupe';
$string['country.gq'] = 'Äquatorial Guinea';
$string['country.gr'] = 'Griechenland';
$string['country.gs'] = 'Südgeorgien und die Südlichen Sandwichinseln';
$string['country.gt'] = 'Guatemala';
$string['country.gu'] = 'Guam';
$string['country.gw'] = 'Guinea-Bissau';
$string['country.gy'] = 'Guyana';
$string['country.hk'] = 'Hongkong';
$string['country.hm'] = 'Heard und Mc Donald Inseln';
$string['country.hn'] = 'Honduras';
$string['country.hr'] = 'Kroatien';
$string['country.ht'] = 'Haiti';
$string['country.hu'] = 'Ungarn';
$string['country.id'] = 'Indonesien';
$string['country.ie'] = 'Irland';
$string['country.il'] = 'Israel';
$string['country.im'] = 'Isle of Man';
$string['country.in'] = 'Indien';
$string['country.io'] = 'Ozeanien (Brit.)';
$string['country.iq'] = 'Irak';
$string['country.ir'] = 'Iran';
$string['country.is'] = 'Island';
$string['country.it'] = 'Italien';
$string['country.je'] = 'Jersey';
$string['country.jm'] = 'Jamaika';
$string['country.jo'] = 'Jordanien';
$string['country.jp'] = 'Japan';
$string['country.ke'] = 'Kenia';
$string['country.kg'] = 'Kirgisien';
$string['country.kh'] = 'Kambodscha';
$string['country.ki'] = 'Kiribati';
$string['country.km'] = 'Komoren';
$string['country.kn'] = 'Saint Kitts und Nevis';
$string['country.kp'] = 'Korea, Demokratische Republik';
$string['country.kr'] = 'Korea, Republik';
$string['country.kw'] = 'Kuwait';
$string['country.ky'] = 'Cayman Inseln';
$string['country.kz'] = 'Kasachstan';
$string['country.la'] = 'Laos';
$string['country.lb'] = 'Libanon';
$string['country.lc'] = 'Santa Lucia';
$string['country.li'] = 'Liechtenstein';
$string['country.lk'] = 'Sri Lanka';
$string['country.lr'] = 'Liberia';
$string['country.ls'] = 'Lesotho';
$string['country.lt'] = 'Litauen';
$string['country.lu'] = 'Luxemburg';
$string['country.lv'] = 'Lettland';
$string['country.ly'] = 'Libyen';
$string['country.ma'] = 'Marokko';
$string['country.mc'] = 'Monaco';
$string['country.md'] = 'Moldavien';
$string['country.mg'] = 'Madagaskar';
$string['country.mh'] = 'Marshall Inseln';
$string['country.mk'] = 'Mazedonien';
$string['country.ml'] = 'Mali';
$string['country.mm'] = 'Myanmar (Burma)';
$string['country.mn'] = 'Mongolei';
$string['country.mo'] = 'Makao';
$string['country.mp'] = 'Nordmarinen';
$string['country.mq'] = 'Martinique';
$string['country.mr'] = 'Mauretanien';
$string['country.ms'] = 'Montserrat';
$string['country.mt'] = 'Malta';
$string['country.mu'] = 'Mauritius';
$string['country.mv'] = 'Malediven';
$string['country.mw'] = 'Malawi';
$string['country.mx'] = 'Mexiko';
$string['country.my'] = 'Malaysia';
$string['country.mz'] = 'Mozambique';
$string['country.na'] = 'Namibia';
$string['country.nc'] = 'Neukaledonien';
$string['country.ne'] = 'Niger';
$string['country.nf'] = 'Norfolk Inseln';
$string['country.ng'] = 'Nigeria';
$string['country.ni'] = 'Nicaragua';
$string['country.nl'] = 'Niederlande';
$string['country.no'] = 'Norwegen';
$string['country.np'] = 'Nepal';
$string['country.nr'] = 'Nauru';
$string['country.nu'] = 'Niue';
$string['country.nz'] = 'Neuseeland';
$string['country.om'] = 'Oman';
$string['country.pa'] = 'Panama';
$string['country.pe'] = 'Peru';
$string['country.pf'] = 'Franz. Polynesien';
$string['country.pg'] = 'Papua Neuguinea';
$string['country.ph'] = 'Phillipinen';
$string['country.pk'] = 'Pakistan';
$string['country.pl'] = 'Polen';
$string['country.pm'] = 'St. Pierre und Miquelon';
$string['country.pn'] = 'Pitcairn';
$string['country.pr'] = 'Puerto Rico';
$string['country.ps'] = 'Palästina';
$string['country.pt'] = 'Portugal';
$string['country.pw'] = 'Palau';
$string['country.py'] = 'Paraguay';
$string['country.qa'] = 'Katar';
$string['country.re'] = 'Reunion';
$string['country.ro'] = 'Rumänien';
$string['country.ru'] = 'Russland';
$string['country.rw'] = 'Ruanda';
$string['country.sa'] = 'Saudi-Arabien';
$string['country.sb'] = 'Salomon Inseln';
$string['country.sc'] = 'Seychellen';
$string['country.sd'] = 'Sudan';
$string['country.se'] = 'Schweden';
$string['country.sg'] = 'Singapore';
$string['country.sh'] = 'St. Helen';
$string['country.si'] = 'Slowenien';
$string['country.sj'] = 'Spitzbergen und Jan Mayen Inseln (Schweden)';
$string['country.sk'] = 'Slowakei';
$string['country.sl'] = 'Sierra Leone';
$string['country.sm'] = 'San Marino';
$string['country.sn'] = 'Senegal';
$string['country.so'] = 'Somalia';
$string['country.sr'] = 'Surinam';
$string['country.st'] = 'Sao Tome und Principe';
$string['country.sv'] = 'El Salvador';
$string['country.sy'] = 'Syrien';
$string['country.sz'] = 'Swaziland';
$string['country.tc'] = 'Turks- und Caicosinseln';
$string['country.td'] = 'Tschad';
$string['country.tf'] = 'Franz. Süd- und Antarktisterritorien';
$string['country.tg'] = 'Togo';
$string['country.th'] = 'Thailand';
$string['country.tj'] = 'Tadschikistan';
$string['country.tk'] = 'Tokelau';
$string['country.tl'] = 'Timor-Leste (Osttimor)';
$string['country.tm'] = 'Turkmenistan';
$string['country.tn'] = 'Tunesien';
$string['country.to'] = 'Tonga';
$string['country.tr'] = 'Türkei';
$string['country.tt'] = 'Trinidad und Tobago';
$string['country.tv'] = 'Tuvalu';
$string['country.tw'] = 'Taiwan';
$string['country.tz'] = 'Tansania';
$string['country.ua'] = 'Ukraine';
$string['country.ug'] = 'Uganda';
$string['country.um'] = 'Kleinere abseitsliegende Inseln der Vereinigten Staaten';
$string['country.us'] = 'Vereinigte Staaten von Amerika';
$string['country.uy'] = 'Uruguay';
$string['country.uz'] = 'Usbekistan';
$string['country.va'] = 'Vatikanstaat';
$string['country.vc'] = 'Saint Vincent und Grenadin';
$string['country.ve'] = 'Venezuela';
$string['country.vg'] = 'Virgin Inseln (britisch)';
$string['country.vi'] = 'Virgin Inseln (U.S.)';
$string['country.vn'] = 'Vietnam';
$string['country.vu'] = 'Vanuatu';
$string['country.wf'] = 'Wallis und Futuna';
$string['country.ws'] = 'Samoa';
$string['country.ye'] = 'Jemen';
$string['country.yt'] = 'Mayotte';
$string['country.za'] = 'Südafrika';
$string['country.zm'] = 'Sambia';
$string['country.zw'] = 'Simbabwe';
$string['create'] = 'Erstellen';
$string['createdetail'] = 'Erzeugen Sie Ihr digitales Profil in einem flexiblen persönlichen Lernsystem';
$string['createsubtitle'] = 'Eigenes Portfolio entwickeln';
$string['dashboarddescription'] = 'Deine Dashboard-Ansicht ist die Seite, die du siehst, wenn du dich einloggst. Nur du hast dafür die Zugriffserlaubnis.';
$string['date'] = 'Datum';
$string['dateformatguide1'] = 'Das Format %s verwenden';
$string['dateofbirthformatguide1'] = 'Das Format %s verwenden';
$string['datepicker_amNames'] = '[\'AM\', \'A\']';
$string['datepicker_clearText'] = 'Löschen';
$string['datepicker_closeStatus'] = 'Ohne Veränderung schliessen';
$string['datepicker_closeText'] = 'Erledigt';
$string['datepicker_currentStatus'] = 'Aktuellen Monat anzeigen';
$string['datepicker_currentText'] = 'Jetzt';
$string['datepicker_dateStatus'] = 'Wählen Sie DD,MM d,yy';
$string['datepicker_dayNames'] = '[\'Sonntag\',\'Montag\',\'Dienstag\',\'Mittwoch\',\'Donnerstag\',\'Freitag\',\'Samstag\']';
$string['datepicker_dayNamesMin'] = '[\'So\',\'Mo\',\'Di\',\'Mi\',\'Do\',\'Fr\',\'Sa\']';
$string['datepicker_dayNamesShort'] = '[\'So\',\'Mo\',\'Di\',\'Mi\',\'Do\',\'Fr\',\'Sa\']';
$string['datepicker_dayStatus'] = 'DD als ersten Tag der Woche anzeigen';
$string['datepicker_hourText'] = 'Stunde';
$string['datepicker_initStatus'] = 'Datum auswählen';
$string['datepicker_millisecText'] = 'Millisekunde';
$string['datepicker_minuteText'] = 'Minute';
$string['datepicker_monthNames'] = '[\'Januar\',\'Februar\',\'März\',\'April\',\'Mai\',\'Juni\',\'Juli\',\'August\',\'September\',\'Oktober\',\'November\',\'Dezember\']';
$string['datepicker_monthNamesShort'] = '[\'Jan\',\'Feb\',\'März\',\'Apr\',\'Mai\',\'Juni\',\'Juli\',\'Aug\',\'Sep\',\'Okt\',\'Nov\',\'Dez\']';
$string['datepicker_monthStatus'] = 'Einen anderen Monat anzeigen';
$string['datepicker_nextStatus'] = 'Nächsten Monat anzeigen';
$string['datepicker_nextText'] = 'Nächster';
$string['datepicker_pmNames'] = '[\'PM\', \'P\']';
$string['datepicker_prevStatus'] = 'Vorherigen Monat anzeigen';
$string['datepicker_prevText'] = 'Vorherige';
$string['datepicker_secondText'] = 'Sekunde';
$string['datepicker_timeOnlyTitle'] = 'Zeit festlegen';
$string['datepicker_timeText'] = 'Zeit';
$string['datepicker_timezoneText'] = 'Zeitzone';
$string['datepicker_weekHeader'] = 'KW';
$string['datepicker_yearStatus'] = 'Ein anderes Jahr anzeigen';
$string['datetimeformatguide1'] = 'Das Format %s verwenden';
$string['day'] = 'Tag';
$string['days'] = 'Tage';
$string['debugemail'] = 'ACHTUNG: Diese E-Mail war für %s bestimmt<%s>, wurde aber an diese Adresse versendet, weil die Einstellung "sendallemailto"  so eingerichtet ist.';
$string['decline'] = 'Ablehnen';
$string['default'] = 'Standard';
$string['defaulthint'] = 'Gib einen Suchbegriff ein.';
$string['delete'] = 'Löschen';
$string['deleteaccount'] = 'Account von %s / %s löschen';
$string['deleted'] = 'gelöscht';
$string['deleteduser'] = 'Gelöschte/r Nutzer/in';
$string['deleteitem'] = 'Löschen';
$string['deletespecific'] = '"%s" löschen';
$string['deletetag'] = 'Lösche <a href="%s">%s</a>';
$string['deletetagdescription'] = 'Schlagwort aus allen Einträgen in Ihrem Portfolio löschen';
$string['descending'] = 'Absteigend';
$string['description'] = 'Beschreibung';
$string['details'] = 'Details';
$string['dimensions'] = 'Dimensionen';
$string['disable'] = 'Deaktivieren';
$string['disabled'] = 'deaktiviert';
$string['displayname'] = 'Anzeigename';
$string['divertingemailto'] = 'Umleiten einer E-Mail an %s';
$string['done'] = 'Fertig';
$string['dropdownmenu'] = 'Menü';
$string['earliest'] = 'Älteste';
$string['edit'] = 'Bearbeiten';
$string['editaccess'] = 'Zugriff bearbeiten';
$string['editdashboard'] = 'Bearbeiten';
$string['editing'] = 'Bearbeiten';
$string['editmyprofilepage'] = 'Profilseite bearbeiten';
$string['editspecific'] = '"%s" bearbeiten';
$string['edittag'] = 'Bearbeite <a href="%s">%s</a>';
$string['edittagdescription'] = 'Alle Elemente in deinem Portfolio, die mit "%s" verschlagwortet sind, werden aktualisiert';
$string['edittags'] = 'Schlagwörter bearbeiten';
$string['editthistag'] = 'Dieses Schlagwort bearbeiten';
$string['email'] = 'E-Mail';
$string['emailaddress'] = 'E-Mail Adresse';
$string['emailaddressdescription'] = 'E-Mail Adresse ';
$string['emailaddressorusername'] = 'E-Mail-Adresse oder Benutzername';
$string['emailnotsent'] = 'Fehler beim Versenden der Nachricht. Fehlermeldung: "%s"';
$string['emails'] = 'E-Mails';
$string['emailtoolong'] = 'Die E-Mail Adresse darf nicht länger als 255 Zeichen sein';
$string['enable'] = 'Aktivieren';
$string['enabled'] = 'Aktiviert';
$string['engage'] = 'Aktivieren';
$string['engagedetail'] = 'Diskutieren Sie mit anderen Personen in Foren und arbeiten Sie mit ihnen in Gruppen zusammen';
$string['engagesubtitle'] = 'Personen finden und Gruppen beitreten';
$string['errorLoading'] = 'Die Ergebnisse konnten nicht geladen werden.';
$string['errorprocessingform'] = 'Beim Übertragen dieses Formulars hat sich ein Fehler ereignet. Bitte kontrolliere die markierten Felder und probiere es erneut.';
$string['expand'] = 'Aufklappen';
$string['exportfiletoobig'] = 'Die zu erzeugende Datei ist zu groß. Bitte räumen Sie etwas Speicher frei.';
$string['facebookdescription'] = 'Mahara ist eine Open-Source-Portfolio Software und Social-Network Anwendung.
Es unterstützt die Nutzer beim Erstellen und Pflegen digitaler Portfolios ihrer lernerfahrungen und gibt ihnen Vernetzungsmöglichkeiten, um miteinander zu arbeiten.';
$string['false'] = 'Falsch';
$string['filenotfound'] = 'Datei nicht gefunden';
$string['filenotfoundmaybeexpired'] = 'Datei nicht gefunden. Exportdateien werden nach 24 Stunden gelöscht. Bitte exportieren Sie Ihren Inhalt erneut.';
$string['filenotimage'] = 'Die hochgeladene Datei hat kein gültiges Dateiformat. Erlaubt sind PNG-, JPEG- oder GIF-Dateien.';
$string['fileunknowntype'] = 'Der Typ der hochgeladenen Datei konnte nicht bestimmt werden. Die Datei ist vielleicht beschädigt oder es besteht ein Konfigurationsproblem. Wende dich an die Administrator/innen.';
$string['filter'] = 'Filter';
$string['filterresultsby'] = 'Ergebnisse filtern nach:';
$string['findfriends'] = 'Kontakte finden';
$string['findgroups'] = 'Gruppen finden';
$string['first'] = 'Erste';
$string['firstjoined'] = 'Erster Zugriff';
$string['firstname'] = 'Vorname';
$string['firstnameall'] = 'Alle Vornamen';
$string['firstnamedescription'] = 'Vorname ';
$string['firstpage'] = 'Erste Seite';
$string['forgotpassemailsendunsuccessful'] = 'Entschuldigung. Die E-Mail konnte vermutlich nicht erfolgreich versandt werden. Der Fehler liegt bei uns, bitte versuche es erneut';
$string['forgotpassemailsentanyway1'] = 'Eine E-Mail wurde an die gespeicherte E-Mail-Adressse dieses Nutzers gesandt.  Die Adresse war jedoch nicht korrekt  oder der empfangende Mail-Server hat sie zurückgesandt. Nimm  bitte mit den %s Administroren Kontakt auf, um das Passwort zurückzusetzen falls du die E-Mail tatsächlich nicht erhalten hast.';
$string['forgotpassnosuchemailaddressorusername'] = 'Die E-Mail-Adresse oder der Benutzername konnte nicht im System gefunden werden.';
$string['forgotpassuserusingexternalauthentication'] = 'Der von dir eingegebene Nutzer wird auf einem anderen System (externe Authentifizierung) verwaltet.  <a href="%s">Frag den Administrator</a> und bitte ihn das Passwort zu ändern oder verwende einen anderen Nutzernamen oder die E-Mail-Adresse.';
$string['forgotpasswordenternew'] = 'Bitte gib zum Fortsetzen Ihr neues Passwort ein';
$string['forgotusernamepassword'] = 'Hast du deinen Benutzernamen oder Passwort vergessen?';
$string['forgotusernamepasswordemailmessagehtml'] = '<p>Guten Tag %s,</p>

<p>wenn du das Passwort für dein %s Nutzerkonto ändern willst:</p>
<p>der Nutzername lautet <strong>%s</strong>.</p>
<p>Wenn du dein Passwort zurücksetzen willst, folge bitte dem Link:</p>

<p><a href="%s">%s</a></p>

<p>Falls du diesen Link nicht selbst angefordert hast, ignoriere bitte diese Mail.</p>

<p>Wenn du Fragen hast,  freuen wir uns über deinen <a href="%s">Kontakt</a>.</p>

<p>Mit freundlichen Grüßen</p>
<p>%s (Site-Administration)</p>';
$string['forgotusernamepasswordemailmessagetext'] = 'Guten Tag %s,

für deinen Nutzerzugang bei %s wurde eine Nutzernamen- bzw. Passwort-Anforderung eingereicht.

Ihr Nutzername lautet %s.

Wenn du dein Passwort zurücksetzen willst, folge bitte dem Link:

%s

Falls du das Zurücksetzen des Passwortes nicht selbst angefordert haben, ignoriere
bitte diese Mail.

Wenn du Fragen hast, freuen wir uns über deine Kontaktaufnahme:

%s

Mit freundlichen Grüßen
%s (Site-Administration)';
$string['forgotusernamepasswordemailsubject'] = 'Benutzername/Passwort Details für %s';
$string['forgotusernamepasswordtextprimaryemail'] = '<p>Falls du deinen Nutzernamen oder dein Passwort vergessen hast, gib die primäre E-Mail-Adresse ein, die du im Profil hinterlegt hast. Wir senden dir dann per E-Mail eine Nachricht mit der du dein Passwort selber zurücksetzen kannst. </p>
<p>Wenn du deinen Nutzernamen kennst, kannst du auch diese eintragen, um das Passwort zu ändern.</p>';
$string['formerror'] = 'Fehler beim Einreichen. Bitte versuche es noch einmal.';
$string['formerroremail'] = 'Melde dich bitte bei %s, wenn das Problem weiterhin auftritt.';
$string['fullname'] = 'Vollständiger Name';
$string['general'] = 'Allgemein';
$string['go'] = 'Weiter';
$string['goto'] = 'Gehen Sie zu \'%s\'';
$string['gotoinbox'] = 'Zum Nachrichteneingang wechseln';
$string['gotomore'] = 'Lesen Sie mehr...';
$string['groupquota'] = 'Grupppen-Kontingent';
$string['groups'] = 'Gruppen';
$string['height'] = 'Höhe';
$string['heightshort'] = 'H';
$string['helpfor'] = 'Hilfe für"%s"';
$string['hidden'] = 'Verbergen';
$string['hide'] = 'Verbergen';
$string['historical'] = 'Zurückliegend';
$string['home'] = 'Startseite';
$string['howtodisable'] = 'Sie haben die Anzeige der Übersichten-Tabelle deaktiviert.  Die Sichtbarkeit kann bei den <a href="%s">Einstellungen</a> bearbeitet werden.';
$string['hspace'] = 'Horizontaler Abstand';
$string['image'] = 'Bild';
$string['imagebrowserdescription'] = 'Fügen Sie die URL eines externen Bildes ein oder nutzen Sie die untenstehende Bildauswahl, um ein eigenes Bild auszuwählen oder hochzuladen.';
$string['imagebrowsertitle'] = 'Bild einfügen oder auswählen';
$string['imagexofy'] = 'Bild {x} von {y}';
$string['importedfrom'] = 'Importiert von %s';
$string['inbox'] = 'Nachrichteneingang';
$string['inboxblocktitle'] = 'Eingangsbox';
$string['incomingfolderdesc'] = 'Dateien, die von anderen Netzwerken importiert wurden';
$string['inputTooLong'] = 'Zu viele Zeichen';
$string['inputTooShort'] = 'Suchanfrage eingeben';
$string['installedplugins'] = 'Installierte Erweiterungen';
$string['institution'] = 'Institution';
$string['institutioncontacts'] = '\'%s\' Kontakte';
$string['institutionexpirywarning'] = 'Warnung über den Ablauf der Institution';
$string['institutionexpirywarninghtml_institution'] = '<p>Guten Tag  %s,</p>

<p>%s\'s Mitgliedschaft bei %s wird innerhalb von %s ablaufen.</p>

<p>Wenn Sie die Institutionsmitgliedschaft verlängern wollen oder Fragen haben, <a href="%s">nehmen Sie bitte mit uns Kontakt auf</a>.</p>

<p>Freundliche Grüße, %s Site Administrator</p>';
$string['institutionexpirywarninghtml_site'] = '<p>Guten Tag  %s,</p>

<p>die Institution\'%s\' wird innerhalb von %s ablaufen.</p>

<p>du solltest dich melden, um die Mitgliedschaft von %s zu verlängern.</p>

<p>Mit freundlichen Grüßen, 

%s (Site Administration)</p>';
$string['institutionexpirywarningtext_institution'] = 'Guten Tag  %s,

%s\'s Mitgliedschaft bei %s wird innerhalb von %s ablaufen.

Wenn Sie die Institutionmitgliedschaft verlängern wollen oder Fragen haben, nehmen Sie bitte mit uns Kontakt auf:

%s

Freundliche Grüße, %s Site Administrator';
$string['institutionexpirywarningtext_site'] = 'Guten Tag  %s,

die Institution \'%s\' wird innerhalb von %s ablaufen.

du solltest dich melden, um die Mitgliedschaft von %s zu verlängern.

Freundliche Grüße, %s Site Administrator';
$string['institutionfull'] = 'Die gewählte Institution nimmt keine weiteren Mitglieder auf.';
$string['institutioninformation'] = 'Institutionsinformationen';
$string['institutionlink'] = '<a href="%s">%s</a>';
$string['institutionmemberconfirmmessage'] = 'Sie wurden als Mitglied in der Institution %s aufgenommen.';
$string['institutionmemberconfirmsubject'] = 'Bestätigung der Mitgliedschaft in einer Institution';
$string['institutionmemberrejectmessage'] = 'Ihre Anfrage  %s als Mitglied beizutreten wurde abgelehnt.';
$string['institutionmemberrejectsubject'] = 'Die Mitgliedsanfrage wurde abgelehnt';
$string['institutionmembership'] = 'Mitgliedschaft bei Institutionen';
$string['institutionmembershipdescription'] = 'Hier werden die Mitgliedschaften bei den Institutionen angezeigt.  Du kannst Mitgliedschaften beantragen und die Einladung zu Mitgliedschaften annehmen oder ablehnen.';
$string['institutionmembershipexpirywarning'] = 'Institutionsmitgliedschaft: Ankündigung des Ablaufs';
$string['institutionmembershipexpirywarninghtml'] = '<p>Guten Tag  %s,</p>

<p>deine Mitgliedschaft %s bei %s wird innerhalb von %s ablaufen.</p>

<p>Wenn du deinen Zugang verlängern willst oder Fragen hast, <a href="%s">nimm mit uns Kontakt auf</a> .</p>

<p>Freundliche Grüße, %s Site Administrator</p>';
$string['institutionmembershipexpirywarningtext'] = 'Guten Tag  %s,

Deine Mitgliedschaft %s bei %s wird innerhalb von %s ablaufen.

Wenn du den Zugang verlängern willst oder Fragen hast, nimm bitte mit uns Kontakt auf:

%s

Freundliche Grüße, %s Site Administrator';
$string['institutionmembershipfullmessagetext'] = 'Hallo %s,

die Höchstzahl der Mitglieder für %s auf %s wurde erreicht.

Bitte löschen Sie nicht mehr benötigte Nutzeraccounts oder sprechen Sie mit dem Site-Administrator eine Erhöhung der Nutzerzahl ab.

Grüsse vom
%s Team';
$string['institutionmembershipfullsubject'] = 'Höchstmitgliederzahl der Institution erreicht';
$string['institutions'] = 'Institutionen';
$string['invalidsesskey'] = 'Ungültiger Sitzungsschlüssel';
$string['invitedgroup'] = 'Gruppeneinladung';
$string['invitedgroups'] = 'Gruppeneinladungen';
$string['itemdeleted'] = 'Element gelöscht';
$string['itemstaggedwith'] = 'Elemente mit »%s« verschlagwortet';
$string['itemupdated'] = 'Element aktualisiert';
$string['javascriptnotenabled'] = 'Ihre Browsereinstellungen erlauben für diese Site kein Javascript. Du kannst dich bei Mahara nur anmelden, wenn Javascript aktiviert ist';
$string['joininstitution'] = 'Einrichtung beitreten';
$string['language'] = 'Sprache';
$string['last'] = 'Letzte';
$string['lastjoined'] = 'Letzter Zugriff';
$string['lastminutes'] = 'Letzte %s Minuten';
$string['lastname'] = 'Nachname';
$string['lastnameall'] = 'Alle Nachnamen';
$string['lastnamedescription'] = 'Nachname ';
$string['lastpage'] = 'Letzte Seite';
$string['lastupdate'] = 'Letzte Aktualisierung';
$string['lastupdateorcomment'] = 'Letzte Aktualisierung oder Kommentar';
$string['latest'] = 'Neueste';
$string['leaveinstitution'] = 'Institution verlassen';
$string['license'] = 'Lizenz';
$string['licensedesc'] = 'Lizenz für diesen Inhalt';
$string['licensemandatoryerror'] = 'Dies ist ein Pflichtfeld';
$string['licensenocustomerror'] = 'Diese Lizenz ist für diese Site nicht zugelassen.';
$string['licensenone'] = 'Keine ausgewählt';
$string['licensenonedetailed'] = '%s hat keine Lizenz für den Inhalt festgelegt';
$string['licensenonedetailedowner'] = 'Du hast keine Lizenz für den Inhalt festgelegt.';
$string['licenseother'] = 'Andere Lizenz (URL eingeben)';
$string['licenseotherurl'] = 'URL eingeben';
$string['licensingadvanced'] = 'Erweiterte Lizensierung';
$string['licensor'] = 'Lizenzgeber';
$string['licensordesc'] = 'Originallizenzgeber für diesen Inhalt';
$string['licensorurl'] = 'Ursprüngliche Adresse (URL)';
$string['licensorurldesc'] = 'Ursprüngliche Adresse für diesen Inhalt';
$string['link'] = '<a href="%s">%s</a>';
$string['linksandresources'] = 'Links und Ressourcen';
$string['loading'] = 'Laden ...';
$string['loadingMore'] = 'Weitere Ergebnisse werden geladen...';
$string['loggedinusersonly'] = 'Zugriff für eingeloggte Nutzer/innen erlauben';
$string['loggedoutok'] = 'Du hast dich erfolgreich ausgeloggt';
$string['login'] = 'Anmelden';
$string['loginfailed'] = 'Fehler bei der Anmeldung. Bitte kontrolliere den Benutzernamen und das Passwort.';
$string['logins'] = 'Anmeldungen';
$string['loginto'] = 'Anmelden bei %s';
$string['logout'] = 'Abmelden';
$string['lostusernamepassword'] = 'Benutzername/Passwort vergessen?';
$string['maximumSelected'] = 'Maximale Anzahl von Elementen ausgewählt';
$string['maxitemsperpage1'] = 'Ergebnisse pro Seite:';
$string['memberofinstitutions'] = 'Mitglied von %s';
$string['members'] = 'Mitglieder';
$string['membershipexpiry'] = 'Die Mitgliedschaft endet';
$string['menu'] = 'Menü';
$string['message'] = 'Nachricht';
$string['messagesent'] = 'Nachricht wurde versendet!';
$string['modified'] = 'Verändert';
$string['month'] = 'Monat';
$string['months'] = 'Monate';
$string['more...'] = 'Mehr ...';
$string['move'] = 'Verschieben';
$string['moveitemdown'] = 'Nach unten';
$string['moveitemup'] = 'Nach oben';
$string['mustspecifyoldpassword'] = 'Du musst dein  aktuelles Passwort eingeben';
$string['mydashboard'] = 'Mein Dashboard';
$string['myfriends'] = 'Meine Kontakte';
$string['mygroups'] = 'Meine Gruppen';
$string['mymessages'] = 'Meine Meldungen';
$string['myportfolio'] = 'Portfolio';
$string['mytags'] = 'Meine Schlagwörter';
$string['name'] = 'Name';
$string['nameatoz'] = 'Namen A bis Z';
$string['namedfieldempty'] = 'Das erforderliche Feld "%s" ist leer';
$string['nameztoa'] = 'Namen Z bis A';
$string['newpassword'] = 'Neues Passwort';
$string['newuserscantpostlinksorimages'] = 'Neu registrierte Mitglieder können noch keine Links posten. Bitte passe deinen Beitrag an und entferne alle Links und URLs.';
$string['next'] = 'Nächste';
$string['nextpage'] = 'Nächste Seite';
$string['nitems'] = array(
    0 => '% Wert',
    1 => '% Werte',
);
$string['no'] = 'Nein';
$string['noResults'] = 'Es wurden keine Ergebnisse gefunden';
$string['nocountryselected'] = 'Kein Land ausgewählt';
$string['nodeletepermission'] = 'Du hast nicht die Berechtigung, dieses Artefakt zu löschen';
$string['noeditpermission'] = 'Du hast nicht die Berechtigung, dieses Artefakt zu bearbeiten';
$string['noenddate'] = 'Kein Enddatum';
$string['nohelpfound'] = 'Das System hat keine Hilfe für diesen Punkt gefunden';
$string['nohelpfoundpage'] = 'Das System hat keine Hilfe für diese Seite gefunden';
$string['noinstitutionadminfound'] = 'Es wurden keine Institutionsadmimistrator/innen gefunden';
$string['noinstitutionoldpassemailmessagehtml'] = '<p>Guten Tag %s,</p>

<p>du bist nicht mehr als aktives Mitglied bei %s gespeichert.</p>
<p>du kannst jedoch %s weiter nutzen mit deinem derzeitigen Nutzernamen %s und dem bisher genutzten Passwort für deinen Zugang.</p>

<p>Falls du dein Passwort vergessen hast, kannst du es durch Eingabe deines Nutzernamens auf der folgenden Seite erneuern:</p>

<p><a href="%sforgotpass.php">%sforgotpass.php</a></p>

<p>Falls du hierzu Fragen hast, wende dich bitte direkt  <a href="%scontact.php">an uns</a>.</p>

<p>Mit freundlichen Grüßen</p>
<p> %s (Administrator/in)</p>

<p><a href="%sforgotpass.php">%sforgotpass.php</a></p>';
$string['noinstitutionoldpassemailmessagetext'] = 'Guten Tag %s,

du bist nicht mehr als aktives Mitglied bei %s gespeichert.
Du kannst jedoch %s weiter nutzen mit deinem derzeitigen Nutzernamen %s und dem bisher genutzten Passwort für den Zugang. 

Falls du dein Passwort vergessen hast, kannst du es durch Eingabe deines Nutzernamens auf der folgenden Seite erneuern:

%sforgotpass.php

Falls du hierzu Fragen hast, wende dich bitte direkt an uns. 

%scontact.php

Mit freundlichen Grüßen

Ihr %s (Administrator/in)

%sforgotpass.php';
$string['noinstitutionoldpassemailsubject'] = '%s: Mitgliedschaft bei %s';
$string['noinstitutionsetpassemailmessagehtml'] = '<p>Guten Tag %s,</p>

<p>du bist kein aktives Mitglied bei %s mehr.</p>
<p>Du kannst %s deinen aktuellen Benutzernamen %s weiter benutzen, musst aber für den Nutzerzugang ein neues Passwort festlegen.</p>

<p>Klick bitte den folgenden Link:</p>

<p><a href="%sforgotpass.php?key=%s">%sforgotpass.php?key=%s</a></p>

<p>Wenn du Fragen haben, freuen wir uns über deinen <a href="%scontact.php">Kontakt</a>.</p>

<p>Mit freundlichen Grüßen</p>
<p>%s (Site-Administration)</p>

<p><a href="%sforgotpass.php?key=%s">%sforgotpass.php?key=%s</a></p>';
$string['noinstitutionsetpassemailmessagetext'] = 'Guten Tag  %s,

du bist kein aktives Mitglied bei %s. mehr 
Du kannst %s  deinem aktuellen Benutzernamen %s weiter benutzen, mustst aberfür den Nutzerzugang ein neues Passwort festlegen.

Klicke bitte den folgenden Link:

%sforgotpass.php?key=%s

Wenn du Fragen hast, freuen wir uns über deine Kontaktaufnahme.

%scontact.php

Mit freundlichen Grüßen
%s (Site-Administration)

%sforgotpass.php?key=%s';
$string['noinstitutionsetpassemailsubject'] = '%s: Mitgliedschaft bei %s';
$string['noinstitutionstafffound'] = 'Es wurden keine Mitarbeiter/innen der Institution gefunden';
$string['none'] = 'Nichts';
$string['noonlineusersfound'] = 'Es sind keine Nutzer/innen online';
$string['nopathfound'] = 'Kein Pfad für dieses Artefakt gefunden';
$string['noprogressitems'] = 'Für diese Institution sind keine Werte zur Vervollständigung des Profils festgelegt.';
$string['nopublishpermissiononartefact'] = 'Du hast keine Erlaubnis zur Veröffentlichung von %s';
$string['noresultsfound'] = 'Keine Ergebnisse gefunden';
$string['nosendernamefound'] = 'Es wurde kein/e Empfänger/in eingetragen';
$string['nosessionreload'] = 'Zum Anmelden bitte die Seite neu laden';
$string['nosuchpasswordrequest'] = 'Keine solche Passwortanforderung';
$string['notifications'] = 'Nachrichten';
$string['notifyadministrator'] = 'Administrator/in benachrichtigen';
$string['notifyadministratorconfirm'] = 'Willst du wirklich überprüfen lassen, ob diese Seite fragwürdigem Inhalt enthält?';
$string['notinstallable'] = 'Nicht installierbar!';
$string['notinstalledplugins'] = 'Nicht installierte Plugins';
$string['notobjectionable'] = 'Nicht anstößig';
$string['notphpuploadedfile'] = 'Die Datei ging beim Hochladen verloren. Das sollte nicht passieren, wende dich für weitere Details an die Administrator/innen.';
$string['nusers'] = array(
    0 => '1 Nutzer/in',
    1 => '%s Nutzer/innen',
);
$string['off'] = 'Deaktiviert';
$string['oldpassword'] = 'Aktuelles Passwort';
$string['on'] = 'An';
$string['onlineusers'] = 'Nutzer gerade online';
$string['optionalinstitutionid'] = 'Institutions-ID (optional)';
$string['orloginvia'] = 'Oder Login über:';
$string['overview'] = 'Überblick';
$string['password'] = 'Passwort';
$string['passwordchangedok'] = 'Ihr Passwort wurde erfolgreich geändert';
$string['passworddescription'] = 'Das Passwort, das du für den Zugang benutzt. ';
$string['passwordhelp'] = 'Das Passwort, das du für den Zugang benutzt.';
$string['passwordnotchanged'] = 'Du hast dein Passwort nicht geändert, bitte wähle ein neues Passwort';
$string['passwordresetexpired'] = 'Der Schlüssel zum Zurücksetzen des Kennworts ist abgelaufen.';
$string['passwordsaved'] = 'Ihr neues Passwort wurde gespeichert';
$string['passwordsdonotmatch'] = 'Die eingegebenen Passworte stimmen nicht überein';
$string['passwordtooeasy'] = 'Dein Passwort ist zu einfach! Bitte wähle ein sicheres Passwort';
$string['pendingfriend'] = 'unerledigte Kontaktanfrage';
$string['pendingfriends'] = 'unerledigte Kontaktanfragen';
$string['phpuploaderror'] = 'Beim Hochladen ist ein Fehler aufgetreten: %s (Fehlercode %s)';
$string['phpuploaderror_1'] = 'Die hochgeladene Datei ist zu groß. Sie übersteigt die upload_max_filesize Anweisung in der Datei php.ini. Nutze eine kleinere Datei oder informiere die Administrator/innen.';
$string['phpuploaderror_2'] = 'Die hochgeladene Datei ist zu groß  übersteigt die max_file_size Anweisung, die im HTML Formular festgelegt wurde. Nutzen Sie eine kleinere Datei oder informieren Sie die Administrator/innen.';
$string['phpuploaderror_3'] = 'Die hochgeladene Datei wurde nur teilweise hochgeladen.';
$string['phpuploaderror_4'] = 'Es wurde keine Datei hochgeladen.';
$string['phpuploaderror_6'] = 'Es fehlt ein temporärer Ordner.';
$string['phpuploaderror_7'] = 'Die Datei konnte nicht gespeichert werden.';
$string['phpuploaderror_8'] = 'Das Hochladen der Datei wurde durch eine Erweiterung gestoppt.';
$string['pleasedonotreplytothismessage'] = 'Bitte antworte nicht auf diese Mail.';
$string['pluginbrokenanddisabled'] = 'Ein Nutzer versuchte das %s Plugin zu laden. Es konnte jedoch nicht 
aufgerufen werden.
Um weitere Fehlermeldungen zu vermeiden, wurde das Plugin vorläufig
deaktiviert.

Das Plugin erzeugte folgende Fehlermeldung:
----------------------------------------------------------------------------

    %s

----------------------------------------------------------------------------

Um das Plugin wieder zu aktivieren, gehen Sie zur Seite \'Erweiterungen\'.
';
$string['pluginbrokenanddisabledtitle'] = 'Ein fehlerhaftes Plugin (%s) wurde deaktiviert';
$string['plugindisabled'] = 'Das Plugin ist verborgen';
$string['plugindisableduser'] = 'Das %s-Plugin wurde  deaktiviert. Nimm mit dem Administrator Kontakt auf.';
$string['pluginenabled'] = 'Das Plugin ist sichtbar.';
$string['pluginexplainaddremove'] = 'Die Plugins in Mahara sind immer installiert und können aufgerufen werden, wenn die Nutzer/innen die URL kennen und eine Zugriffsberechtigung besitzen. Anstatt die Funktionalität zu aktivieren und deaktivieren, werden die Plugins sichtbar gemacht oder versteckt, indem die Links \'anzeigen\' oder \'verbergen\'  neben den Pluginnamen betätigt werden.';
$string['pluginexplainartefactblocktypes'] = 'Wenn ein \'Artefakt\' Plugin versteckt wird, verhindert Mahara auch die Anzeige der entsprechenden Blöcke.';
$string['pluginnotenabled'] = 'Das Plugin ist verborgen.  Du musst das %s Plugin erst anzeigen lassen.';
$string['plugintype'] = 'Plugintyp';
$string['posts'] = 'Beiträge';
$string['preferences'] = 'Einstellungen';
$string['preferredname'] = 'Anzeigename';
$string['previous'] = 'Vorherige';
$string['prevpage'] = 'Vorherige Seite';
$string['primaryemailinvalid'] = 'Ihre primäre E-Mail-Adresse ist ungültig';
$string['privacystatement'] = 'Datenschutzerklärung';
$string['processing'] = 'Bearbeitung';
$string['profile'] = 'Profil';
$string['profilecompleteness'] = 'Profil-Vollständigkeit';
$string['profilecompletenesspreview'] = 'Profil-Vollständigkeit Vorschau';
$string['profilecompletenesstips'] = 'Tipps zum Vervollständigen des Profils';
$string['profilecompletionforwhichinstitution'] = 'für';
$string['profiledescription'] = 'Deine Profilansicht ist die Seite, die andere Nutzer/innen sehen, wenn du auf deinen Namen oder dein Profilbild klicken';
$string['profileicon'] = 'Profilbild';
$string['profileimagetext'] = '%s\'s Profilbild';
$string['profileimagetextanonymous'] = 'anonymes Profilbild';
$string['progressbargenerictask'] = array(
    0 => 'Einen %2$s hinzufügen',
    1 => '%d hinzufügen: %s',
);
$string['pwchangerequestsent'] = 'Du erhältst in Kürze eine E-Mail mit einer Linkadresse, damit du dein Passwort abändern können';
$string['quarantinedirname'] = 'Quarantäne';
$string['query'] = 'Suchanfrage';
$string['querydescription'] = 'Worte, nach denen gesucht wird';
$string['quota'] = 'Kontingent';
$string['quotausage'] = 'Du hastn <span id="quota_used">%s</span> Ihres <span id="quota_total">%s</span> Kontingents benutzt.';
$string['quotausagegroup'] = 'Diese Gruppe hat bereits <span id="quota_used">%s</span> von <span id="quota_total">%s</span> Speicherplatz in Gebrauch.';
$string['reallyleaveinstitution'] = 'Willst du diese Institution wirklich verlassen?';
$string['reason'] = 'Grund';
$string['register'] = 'Registrieren';
$string['registeragreeterms'] = 'Du musst den <a href="terms.php">Nutzungsbedingen</a> zustimmen.';
$string['registeringdisallowed'] = 'Entschuldigung, du kannst dich gerade nicht für dieses System anmelden';
$string['registerprivacy'] = 'Persönliche Daten werden entsprechend der <a href="privacy.php">Datenschutzerklärung</a> gespeichert.';
$string['registerstep3fieldsmandatory'] = '<h3>Fülle bitte die Pflichtfelder aus</h3><p>Die folgenden Felder sind vorgeschrieben. Du musst sie ausfüllen, bevor die Anmeldung komplett ist.</p>';
$string['registerstep3fieldsoptional'] = '<h3>Du kannst ein  Profilbild hinterlegen</h3><p>Deine Anmeldung bei %s war erfolgreich. Du kannst nun ein Bild hochwählen, das als Profilbild benutzt wird. Die Nutzung eines Profilbilds ist freiwillig. </p>';
$string['registerwelcome'] = 'Herzlich Willkommen! Bist du das erste Mal auf dieser Site? Bitte registriere dich!';
$string['registrationcomplete'] = 'Vielen Dank für die Registrierung bei %s';
$string['registrationnotallowed'] = 'Die gewählte Institution erlaubt keine Selbstregistrierung.';
$string['reject'] = 'Ablehnen';
$string['remotehost'] = 'Remote Host %s';
$string['remove'] = 'Entfernen';
$string['reportobjectionablematerial'] = 'Anstößiges Material anzeigen';
$string['reportsent'] = 'Ihr Bericht wurde gesendet';
$string['republish'] = 'Veröffentlichen';
$string['requestmembershipofaninstitution'] = 'Mitgliedschaft in einer Institution beantragen';
$string['result'] = 'Ergebnis';
$string['results'] = 'Ergebnisse';
$string['resultsperpage'] = 'Ergebnisse pro Seite';
$string['returntosite'] = 'Zurück zur Site';
$string['save'] = 'Speichern';
$string['search'] = 'Suche';
$string['searching'] = 'Suche...';
$string['searchresultsfor'] = 'Suchergebnis für';
$string['searchtype'] = 'Suchtyp';
$string['searchusers'] = 'Nutzer/innen suchen';
$string['searchwithin'] = 'Suchen innerhalb von';
$string['select'] = 'Auswählen';
$string['selectall'] = 'Alle auswählen';
$string['selectatagtoedit'] = 'Wähle ein Schlagwort zum Bearbeiten aus';
$string['selected'] = 'ausgewählt';
$string['selectnone'] = 'Keine auswählen';
$string['selfsearch'] = 'Mein Portfolio durchsuchen';
$string['send'] = 'Senden';
$string['sendmessage'] = 'Nachricht senden';
$string['sendrequest'] = 'Anfrage absenden';
$string['sessiontimedout'] = 'Ihre Sitzung ist abgelaufen. Bitte erneut anmelden, um fortzufahren.';
$string['sessiontimedoutpublic'] = 'Deine Sitzung ist abgelaufen. Du kannst dich <a href="%s">hier anmelden</a>, um weiter zu arbeiten.';
$string['sessiontimedoutreload'] = 'Deine Sitzung ist abgelaufen. Lade die Seite erneut, um dich erneut anzumelden.';
$string['setblocktitle'] = 'Blocktitel festlegen';
$string['settings'] = 'Einstellungen';
$string['settingssaved'] = 'Einstellungen gesichert';
$string['settingssavefailed'] = 'Die Sicherung der Einstellungen fehlgeschlagen';
$string['settingsspecific'] = 'Einstellungen für "%s"';
$string['share'] = 'Teilen';
$string['sharedetail'] = 'Teilen Sie Ihre Erfolge und Ihre Entwicklung an einem Ort den Sie selbst gestalten';
$string['sharesubtitle'] = 'Kontrollieren Sie Ihren privaten Bereich';
$string['show'] = 'Anzeigen';
$string['showtags'] = 'Meine Schlagwörter anzeigen';
$string['siteclosed'] = 'Die Site ist für ein Datenbank-Upgrade vorübergehend geschlossen.  Administrator/innen können sich anmelden.';
$string['siteclosedlogindisabled'] = 'Die Site ist für ein Datenbank-Upgrade vorübergehend geschlossen.  <a href="%s">Den Upgrade-Vorgang jetzt starten.</a>';
$string['sitecontentnotfound'] = '%s Text ist nicht verfügbar';
$string['siteinformation'] = 'Site-Informationen';
$string['sizeb'] = 'b';
$string['sizegb'] = 'GB';
$string['sizekb'] = 'KB';
$string['sizemb'] = 'MB';
$string['skipmenu'] = 'Zum Hauptinhalt zurückspringen';
$string['sortalpha'] = 'Schlagwörter alphabetisch sortieren';
$string['sortby'] = 'Sortieren nach:';
$string['sortedby'] = 'Sortiert nach';
$string['sortfreq'] = 'Schlagwörter nach Häufigkeit sortieren';
$string['sortorder'] = 'Sortierfolge der Dateien';
$string['sortresultsby'] = 'Sortiere Ergebnisse nach:';
$string['spamtrap'] = 'Spamfilter';
$string['staffofinstitutions'] = 'Mitarbeiter/in für %s';
$string['status'] = 'Status';
$string['studentid'] = 'ID Nummer';
$string['style'] = 'Style (CSS)';
$string['subject'] = 'Betreff';
$string['submit'] = 'Absenden';
$string['system'] = 'System';
$string['tab'] = 'Tab';
$string['tabs'] = 'TABS';
$string['tagdeletedsuccessfully'] = 'Schlagwort erfolgreich gelöscht';
$string['tagfilter_all'] = 'Alle';
$string['tagfilter_collection'] = 'Sammlungen';
$string['tagfilter_file'] = 'Dateien';
$string['tagfilter_image'] = 'Bilder';
$string['tagfilter_text'] = 'Text';
$string['tagfilter_view'] = 'Ansichten';
$string['tags'] = 'Schlagwörter';
$string['tagsdesc'] = 'Schlagwörter für dieses Element mit Kommata getrennt eingeben';
$string['tagsdescprofile'] = 'Die Schlagwörter mit Kommata getrennt eingeben. Artefakte die mit »Profil« verschlagwortet wurden, werden in Ihrer Seitenleiste angezeigt.';
$string['tagupdatedsuccessfully'] = 'Schlagwort erfolgreich aktualisiert';
$string['termsandconditions'] = 'Nutzungsbedingung';
$string['theme'] = 'Theme';
$string['toggletoolbarsoff'] = 'Toolbar abschalten. Nur Basisbuttons anzeigen';
$string['toggletoolbarson'] = 'Toolbar anschalten. Liste mit allen Buttons anzeigen.';
$string['topicsimfollowing'] = 'Beobachtete Themen';
$string['true'] = 'Richtig';
$string['units'] = 'Einheiten';
$string['unknownerror'] = 'Unbekannter Fehler (0x20f91a0)';
$string['unreadmessage'] = 'ungelesene Nachricht';
$string['unreadmessages'] = 'ungelesene Nachrichten';
$string['update'] = 'Aktualisieren';
$string['updatefailed'] = 'Die Aktualisierung ist fehlgeschlagen';
$string['upload'] = 'Hochladen';
$string['uploadedfiletoobig'] = 'Die Datei ist zu groß. Wende dich für weitere Details an die Administrator/innen.';
$string['url'] = 'Bild-URL';
$string['username'] = 'Benutzername';
$string['usernamedescription'] = ' ';
$string['usernamehelp'] = 'Der Benutzername mit dem du auf der Site angemeldet bist.';
$string['users'] = 'Nutzer/innen';
$string['usersdashboard'] = '%s\'s Dashboard';
$string['usersprofile'] = '%s\'s Profilansicht';
$string['version.'] = 'v.';
$string['view'] = 'Ansicht';
$string['viewmyprofilepage'] = 'Profilseite darstellen';
$string['views'] = 'Ansichten';
$string['virusfounduser'] = 'Die Datei %s, die du hochgeladen hast, wurde mit dem Virenscanner geprüft und ist verdächtig! Das Hochladen der Datei ist fehlgeschlagen.';
$string['virusrepeatmessage'] = 'Der/die Nutzer/in %s hat verschiedene Dateien hochgeladen, die laut Virenchecker infiziert sind.';
$string['virusrepeatsubject'] = 'Warnung: %s scheint ein wiederholter Viren-Upload zu sein.';
$string['vspace'] = 'Vertikaler Abstand';
$string['wanttoleavewithoutsaving?'] = 'Du hast Änderungen vorgenommen.  Willst du die Seite verlassen ohne die Änderungen abzuspeichern.';
$string['weeks'] = 'Wochen';
$string['width'] = 'Breite';
$string['widthshort'] = 'B';
$string['year'] = 'Jahr';
$string['years'] = 'Jahre';
$string['yes'] = 'Ja';
$string['youareamemberof'] = 'Du bist Mitglied bei %s';
$string['youaremasqueradingas'] = 'Du hast dich als %s angemeldet.';
$string['youhavebeeninvitedtojoin'] = 'Du wurdest eingeladen, der Einrichtung %s beizutreten';
$string['youhavenottaggedanythingyet'] = 'Sie haben bisher noch keine Schlagwörter vergeben';
$string['youhaverequestedmembershipof'] = 'Du hast die Mitgliedschaft bei %s beantragt';
$string['youraccounthasbeensuspended'] = 'Ihr Zugang wurde gesperrt';
$string['youraccounthasbeensuspendedreasontext'] = 'Ihr Zugang bei %s wurde von %s gesperrt. Grund:

%s';
$string['youraccounthasbeensuspendedtext2'] = 'Ihr Zugang bei %s wurde von %s gesperrt';
$string['youraccounthasbeenunsuspended'] = 'Ihr Zugang wurde wieder aktiviert';
$string['youraccounthasbeenunsuspendedtext2'] = 'Dein Zugang bei %s wurde wieder aktiviert. Du kannst dich wieder anmelden und die Plattform benutzen.';
$string['yournewpassword'] = 'Dein neues Passwort. Passwörter müssen mindestens sechs Zeichen lang sein und dürfen nicht mit dem Nutzernamen identisch sein. Achte auf Groß-/Kleinschreibung. <br />
Ein sicheres Passwort ist z.B. ein kurzer Satz.';
$string['yournewpasswordagain'] = 'Wiederhole dein neues Passwort';
