<?php

defined('INTERNAL') || die();

$string['addauthority'] = 'Authentifizierungsplugin anlegen';
$string['application'] = 'Anwendung';
$string['authloginmsg2'] = 'Wenn Sie keine primäre Authentifizierungsmethdoe gewählt haben, können Sie hier eine Information festlegen, die bei der Nutzung des Login-Formulars angezeigt wird.';
$string['authname'] = 'Authentifizierungsname';
$string['cannotjumpasmasqueradeduser'] = 'Sie können nicht in eine andere Anwendung wechseln, während Sie \'als anderer Nutzer\' aktiv sind.';
$string['cannotremove'] = 'Dieses Authentifizierungsplugin kann nicht gelöscht werden, 
da für die Institution kein weiteres Plugin installiert ist.';
$string['cannotremoveinuse'] = 'Dieses Authentifizierungsplugin kann nicht gelöscht werden, 
da es von einigen Nutzern gebraucht wird.
Sie müssen diese Nutzerdatensätze aktualisieren, bevor Sie 
das Plugin löschen können.';
$string['cantretrievekey'] = 'Beim Abholen des Public Key beim Remote Server ist ein Fehler aufgetreten.<br>Bitte stellen Sie sicher, dass das Programm und die WWW Rootfelder richtig eingetragen sind und die Remoteseite auch Netzwerkzugriffe gewährt.';
$string['changepasswordurl'] = 'URL für Passwortänderungen';
$string['duplicateremoteusername'] = 'Dieser externe Authentifizierungsname wird schon von %s benutzt. Die externen Authentifizierungsnamen müssen innerhalb einer Authentifizierungsmethode eindeutig sein.';
$string['duplicateremoteusernameformerror'] = 'Die externen Authentifizierungsnamen müssen innerhalb einer Authentifizierungsmethode eindeutig sein.';
$string['editauthority'] = 'Authentifizierungsplugin bearbeiten';
$string['errnoauthinstances'] = 'Wir haben anscheinend für diesen Host keine Authentifizierungsplugin bei %s eingerichtet.';
$string['errnoxmlrpcinstances'] = 'Wir haben anscheinend für diesen Host keine Authentifizierungsplugin bei %s eingerichtet.';
$string['errnoxmlrpcuser1'] = 'Leider konnten wir deinen Nutzerzugang nicht authentifizieren. Gründe hierfür können sein:

    * Deine SSO Session ist abgelaufen. Gehe zu der Herkunftsanwendung zurück und klicke den Link für %s noch einmal.
    * Du bist nicht berechtigt SSO für %s zu verwenden. Prüfe dies mit dem Administrator, wenn du meinst, dies sollte möglich sein.';
$string['errnoxmlrpcwwwroot'] = 'Wir haben keinen Datensatz für diesen Host bei %s eingerichtet.';
$string['errorcertificateinvalidwwwroot'] = 'Das Zertifikat beansprucht zu %s zu gehören, aber Sie versuchen es für %s zu benutzen.';
$string['errorcouldnotgeneratenewsslkey'] = 'Das System kann keinen neuen SSL Schlüssel anlegen. Sind Sie sicher, dass die das Openssl Modul und das PHP Module für Openssl auf diesem Rechner installiert sind?';
$string['errornotvalidsslcertificate'] = 'Das ist kein gültiges SSL Zertifikat';
$string['host'] = 'Rechnername oder Adresse';
$string['hostwwwrootinuse'] = 'WWW Root wird schon von einer anderen Institution  benutzt (%s)';
$string['ipaddress'] = 'IP-Adresse';
$string['mobileuploadnotenabled'] = 'Der Upload für mobile Endgeräte ist nicht aktiviert.';
$string['mobileuploadtokennotfound'] = 'Der Token für mobile Uploads wurde nicht gefunden. Prüfe die Siteeinstellungen und die Einträge für mobile Anwendungen.';
$string['mobileuploadtokennotset'] = 'Der Tokeneintrag für mobile Endgeräte darf nicht leer bleiben. Prüfe die Einstellungen für mobile Endgeräte und versuche es dann nochmals.';
$string['mobileuploadusernamenotset'] = 'Der Nutzername für den mobilen Upload darf nicht leer bleiben. Prüfe die Einstellungen für mobile Endgräte und versuche es dann nochmals.';
$string['name'] = 'Site-Name';
$string['noauthpluginconfigoptions'] = 'Mit diesem Plugin sind keine Konfigurationsoptionen verknüpft.';
$string['nodataforinstance'] = 'Es werden keine Daten für die Authentifizierungsinstanz gefunden ';
$string['parent'] = 'Primäre Authentifizierung';
$string['port'] = 'Port';
$string['primaryemaildescription'] = 'Die primäre E-Mail-Adresse. Sie erhalten eine E-Mail mit einem anklickbaren Verweis. Klicken Sie diesen an und melden Sie sich im System an, um die Einstellung zu bestätigen.';
$string['protocol'] = 'Protokoll';
$string['requiredfields'] = 'Erforderliche Profilfelder';
$string['requiredfieldsset'] = 'Die erforderlichen Profilfelder wurden angelegt';
$string['saveinstitutiondetailsfirst'] = 'Bitte speichern Sie die Institutionsdetails bevor Sie das Authentifizierungsplugin konfigurieren.';
$string['shortname'] = 'Kurzbezeichnung Ihrer Site';
$string['ssodirection'] = 'SSO Richtung';
$string['theyautocreateusers'] = 'Die Gegenseite legt die Nutzer/innen automatisch an';
$string['theyssoin'] = 'Die Gegenseite loggt sich via SSO ein';
$string['toomanytries'] = 'Du hast die maximale Zahl der Anmelde-Versuche überschritten. Dieses Konto wurde für bis zu 5 Minuten gesperrt.';
$string['unabletosigninviasso'] = 'Die Anmeldung via SSO ist fehlgeschlagen';
$string['updateuserinfoonlogin'] = 'Aktualisierung der Benutzerdaten beim Einloggen';
$string['updateuserinfoonlogindescription'] = 'Bei jedem Einloggen des Benutzers werden Informationen vom Remote Server geholt und der lokale Datensatz aktualisiert.';
$string['validationprimaryemailsent'] = 'Eine Überprüfungsnachricht wurde versandt. Klicken Sie den Verweis in der E-Mail zur Bestätigung an.';
$string['weautocreateusers'] = 'Wir legen Nutzer/innen automatisch an';
$string['weimportcontent'] = 'Wir importieren Content';
$string['weimportcontentdescription'] = '(ist nur bei einigen Applikationen möglich)';
$string['wessoout'] = 'Wir benutzen SSO nach außen';
$string['wwwroot'] = 'WWW Root';
$string['xmlrpccouldnotlogyouin'] = 'Entschuldigung, im Augenblick ist keine Anmeldung möglich :(';
$string['xmlrpccouldnotlogyouindetail1'] = 'Leider konnten wir dich im Moment nicht anmelden bei %s. Bitte versuche es später noch einmal. Wenn das Problem weiter fortbesteht, wenden dich bitte an den Administrator.';
$string['xmlrpcserverurl'] = 'XML-RPC Server URL';
