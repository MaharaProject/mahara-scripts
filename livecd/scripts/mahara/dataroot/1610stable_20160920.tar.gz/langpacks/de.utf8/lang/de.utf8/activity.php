<?php

defined('INTERNAL') || die();

$string['addtowatchlist'] = 'Der Beobachtungsliste hinzufügen';
$string['adminnotificationerror'] = 'Die fehlerhafte Nutzerbenachrichtigung wurde wahrscheinlich von Ihrer Server-Konfiguration verursacht.';
$string['alltypes'] = 'Alle Typen';
$string['artefacts'] = 'Artefakte';
$string['attime'] = 'am';
$string['blockinstancenotification'] = 'Der Block "%s" wurde hinzugefügt oder geändert.';
$string['date'] = 'Datum';
$string['deleteallnotifications'] = 'Alle Nachrichten löschen';
$string['deletednotifications1'] = array(
    0 => '%s Benachrichtigung gelöscht',
    1 => '%s Benachrichtigungen gelöscht',
);
$string['failedtodeletenotifications'] = 'Fehler beim Löschen der Nachrichten';
$string['failedtomarkasread'] = 'Fehler beim Versuch Ihre Nachrichten als gelesen zu markieren';
$string['groups'] = 'Gruppen';
$string['institutioninvitemessage'] = 'Du kannst die Mitgliedschaft für diese Institution auf Ihrer Seite Einstellungen Präferenzen bestätigen:';
$string['institutioninvitesubject'] = 'Du wurdest eingeladen, der Institution %s beizutreten.';
$string['institutionrequestmessage'] = 'Du kannst neue Mitglieder auf der Seite Institutionsmitglieder bestätigen:';
$string['institutionrequestsubject'] = '%s hat die Mitgliedschaft in %s beantragt.';
$string['markasread'] = 'Als gelesen markieren';
$string['markedasread'] = 'Ihre Nachrichten wurden als gelesen markiert';
$string['messagetype'] = 'Mitteilungstyp';
$string['missingparam'] = 'Der erforderliche Wert %s für den Nachrichtentyp %s ist nicht vorhanden';
$string['monitored'] = 'In Beobachtung';
$string['newcollectionaccessmessage'] = 'Sie haben jetzt Zugriff zur Sammlung "%s" von %s';
$string['newcollectionaccessmessagenoowner'] = 'Sie haben jetzt Zugriffzur Sammlung "%s"';
$string['newcollectionaccessmessagenoownerviews'] = 'Sie haben jetzt Zugriff zu den Ansichten "%s" in Sammlung "%s"';
$string['newcollectionaccessmessageviews'] = 'Sie haben jetzt Zugriff zu den Ansichten "%s" in der Sammlung "%3$s" von %2$s';
$string['newcollectionaccesssubject'] = 'Neu: Zugriff auf die Sammlung "%s"';
$string['newcontactus'] = 'Neue Kontaktmeldung';
$string['newcontactusfrom'] = 'Neue Kontaktmeldung';
$string['newgroupmembersubj'] = '%s ist nun Mitglied der Gruppe';
$string['newviewaccessmessage'] = 'Du hast die Zugriffserlaubnis auf die Ansicht "%s" von %s';
$string['newviewaccessmessagenoowner'] = 'Du hast die Zugrifferlaubnis für die Ansicht "%s" erhalten';
$string['newviewaccessmessagenoownerviews'] = 'Sie haben jetzt Zugriffsliste zu den Ansichten "%s"';
$string['newviewaccessmessageviews'] = 'Sie haben jetzt Zugriff zu den Ansichten "%s"  von %s';
$string['newviewaccesssubject1'] = 'Neuer Zugang zur Ansicht "%s"';
$string['newviewaccesssubjectviews'] = 'Neu: Zugriff auf die Ansichten "%s"';
$string['newviewmessage'] = '%s hat die neue Ansicht "%s" angelegt';
$string['newviewsubject'] = 'Es wurde eine neue Ansicht angelegt';
$string['newwatchlistmessage'] = 'Neue Aktivität auf Ihrer Watchlist';
$string['newwatchlistmessageview1'] = 'Die Ansicht "%s" von %s wurde verändert.';
$string['nodelete'] = 'Kein Benachrichtigungen zum Löschen';
$string['nonamegiven'] = 'kein Name eingegeben';
$string['objectionablecontentview'] = 'Anstößiger Inhalt in der Ansicht "%s" gemeldet von %s';
$string['objectionablecontentviewartefact'] = 'Anstößiger Inhalt in der Ansicht "%s" im Artefakt "%s" gemeldet von %s';
$string['objectionablecontentviewartefacthtml'] = '<div style="padding: 0.5em 0; border-bottom: 1px solid #999;">Anstößiger Inhalt bei "%s" in "%s" gemeldet von %s<strong></strong><br>%s</div>

<div style="margin: 1em 0;">%s</div>

<div style="font-size: smaller; border-top: 1px solid #999;">
<p>Die Beschwerde bezieht sich auf: <a href="%s">%s</a></p>
<p>Gemeldet von: <a href="%s">%s</a></p>
</div>';
$string['objectionablecontentviewartefacttext'] = 'Anstößiger Inhalt bei "%s" in "%s" gemeldet von %s
%s
------------------------------------------------------------------------

%s

------------------------------------------------------------------------
Zur Anzeige der Seite diesem Link folgen:
%s
Um das Profil des Berichterstatters zu sehen, diesem Link folgen:
%s';
$string['objectionablecontentviewhtml'] = '<div style="padding: 0.5em 0; border-bottom: 1px solid #999;">Anstößiger Inhalt in "%s" gemeldet von %s<strong></strong><br>%s</div>

<div style="margin: 1em 0;">%s</div>

<div style="font-size: smaller; border-top: 1px solid #999;">
<p>Die Beschwerde bezieht sich auf: <a href="%s">%s</a></p>
<p>Gemeldet von: <a href="%s">%s</a></p>
</div>';
$string['objectionablecontentviewtext'] = 'Anstößiger Inhalt in "%s" gemeldet von %s
%s
------------------------------------------------------------------------

%s

------------------------------------------------------------------------
Zur Anzeige der Seite diesem Link folgen:
%s
Um das Profi des Berichterstatters zu sehen, diesem Link folgen:
%s';
$string['ongroup'] = 'auf die Gruppe';
$string['ownedby'] = 'im Besitz von';
$string['prefsdescr'] = 'Wenn du eine der E-Mail Optionen auswählst, werden die Benachrichtigungen trotzdem bei den Nachrichten eingetragen, aber automatisch als gelesen markiert';
$string['read'] = 'Gelesen';
$string['reallydeleteallnotifications'] = 'Willst du wirklich alle Nachrichten dieses Nachrichtentyps löschen?';
$string['recurseall'] = 'Markierung umdrehen';
$string['removedgroupmembersubj'] = '%s ist nicht mehr Mitglied der Gruppe';
$string['removefromwatchlist'] = 'Von der Beobachtungsliste streichen';
$string['selectall'] = 'Alle Nachrichten auswählen';
$string['selectalldelete'] = 'Alle Benachrichtigungen zum Löschen';
$string['selectallread'] = 'Alle ungelesenen Benachrichtigungen';
$string['stopmonitoring'] = 'Beobachtung stoppen';
$string['stopmonitoringfailed'] = 'Fehler beim Beenden der Beobachtung';
$string['stopmonitoringsuccess'] = 'Beobachtung beendet';
$string['subject'] = 'Betreff';
$string['type'] = 'Nachrichtentyp';
$string['typeadminmessages'] = 'Administrationsmitteilungen';
$string['typecontactus'] = 'Kontaktaufnahme';
$string['typefeedback'] = 'Feedback';
$string['typegroupmessage'] = 'Gruppennachricht';
$string['typeinstitutionmessage'] = 'Meldungen einer Institution';
$string['typemaharamessage'] = 'Systemmeldung';
$string['typenewpost'] = 'Forumnachricht';
$string['typeobjectionable'] = 'Anstößiger Inhalt';
$string['typeusermessage'] = 'Meldungen anderer Nutzer/innen';
$string['typeviewaccess'] = 'Neuer Ansichtenzugriff';
$string['typevirusrelease'] = 'Virenkennung Freigabe';
$string['typevirusrepeat'] = 'Wiederholter Virenupload';
$string['typewatchlist'] = 'Beobachtungsliste';
$string['unread'] = 'Ungelesen';
$string['viewmodified'] = 'hat die Ansicht geändert';
$string['viewsubmittedmessage1'] = '%s hat "%s" für %s eingereicht';
$string['viewsubmittedsubject1'] = 'Einreichungen für %s';
$string['yourinboxisempty'] = 'Ihr Posteingang ist leer.';
$string['youroutboxisempty'] = 'Ihr Postausgang ist leer.';
