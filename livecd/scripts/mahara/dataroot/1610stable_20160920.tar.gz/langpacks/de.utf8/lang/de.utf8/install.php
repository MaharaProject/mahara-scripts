<?php

defined('INTERNAL') || die();

$string['aboutdefaultcontent'] = '<h1>Über</h1>

<p><i>Füge hier Text über die Institution und diese Instanz von Mahara ein.</i></p>

<p>[<i>Name of your installation here</i>] wird durch das ePortfolio-System <a href="http://mahara.org">Mahara</a> betrieben.

<p>Eingeführt im Jahr 2006, ist Mahara das Ergebnis eines gemeinschaftlichen Projektes mit New Zealand\'s Tertiary Education Commission\'s e-learning Collaborative Development Fund (eCDF), zusammen mit der Massey Universität, der Auckland University of Technology, dere Open Polytechnic of New Zealand und Victoria University of Wellington.</p>

<p>Mahara ist ein online ePortfolio, Weblog, Lebenslaufgenerator
und Social Networking System, das Nutzer/innen verbindet und Onlinegruppen anlegt. Mahara wurde so
konzipiert, dass es den Nutzer/innen alle Werkzeuge bereitstellt, um eine persönliche, professionelle Lernum-
gebung, eine Entwicklungs- und Präsentationsplattfrom zu gestalten.</p>

<p>Mahara bedeutet \'Denken\' oder \'Gedanke\' in der Te Reo Maori Sprache, der Name reflektiert sowohl den
Einsatz der Projektmitarbeiter eine nutzerzentrierte lebenslange Lernumgebung zu
entwickeln, als auch die Überzeugung, dass eine technische Lösung nicht ohne Berücksichtigung der
Pädagogik und Politik entwickelt werden kann.</p>

<p>Mahara wird als Open Source Software (unter der GNU Public Lizenz) kostenlos bereitgestellt. Dies meint, dass Sie die  Mahara-Software kopieren, benutzen und verändern dürfen, wenn Sie dem Folgendem zustimmen:</p>

<ul>
    <li>Den Quellcode auch für andere bereitstellen; </li>
    <li>Die Originallizenzen nicht ändern oder entfernen, und</li>
    <li>diese Lizenz bei jeder Weiterentwicklung mitgeben.</li>
</ul>

<p>Bitte melde dich über <a href="contact.php">Kontakt</a>, wenn sich Fragen zu Mahara ergeben.</p>

<p><a href="http://mahara.org">http://mahara.org</a></p>
';
$string['homedefaultcontent'] = '<h1>Herzlich Willkommen bei Mahara</h1>

<p>Mahara ist ein online Portfolio, Weblog, Lebenslaufgenerator
und Social Networking System, das Nutzer/innen verbindet und Onlinegruppen anlegt. Mahara wurde so
konzipiert, dass es den Nutzer/innen alle Werkzeuge bereitstellt, um eine persönliche, professionelle Lernum-
gebung, eine Entwicklungs- und Präsentationsplattfrom zu gestalten.</p>

<p>Für weitere Informationen kannst du <a href="about.php">Über</a> Mahara lesen beziehungsweise gerne <a href="contact.php">Kontakt</a> aufnehmen.</p>';
$string['licensedisplaynameby'] = 'Creative Commons Attribution 3.0';
$string['licensedisplaynamebync'] = 'Creative Commons Attribution Non Commercial 3.0';
$string['licensedisplaynamebyncnd'] = 'Creative Commons Attribution Non Commercial No Derivatives 3.0';
$string['licensedisplaynamebyncsa'] = 'Creative Commons Attribution Non Commercial Share Alike 3.0';
$string['licensedisplaynamebynd'] = 'Creative Commons Attribution No Derivatives 3.0';
$string['licensedisplaynamebysa'] = 'Creative Commons Attribution Share Alike 3.0';
$string['licensedisplaynamegfdl'] = 'GNU Free Documentation License v1.3';
$string['licenseshortnameby'] = 'CC-BY-3.0';
$string['licenseshortnamebync'] = 'CC-BY-NC-3.0';
$string['licenseshortnamebyncnd'] = 'CC-BY-NC-ND-3.0';
$string['licenseshortnamebyncsa'] = 'CC-BY-NC-SA-3.0';
$string['licenseshortnamebynd'] = 'CC-BY-ND-3.0';
$string['licenseshortnamebysa'] = 'CC-BY-SA-3.0';
$string['licenseshortnamegfdl'] = 'GFDL-1.3';
$string['loggedouthomedefaultcontent'] = '<h1>Herzlich Willkommen bei Mahara</h1>

<p>Mahara ist ein online Portfolio, Weblog, Lebenslaufgenerator
und Social Networking System, das Nutzer/innen verbindet und Onlinegruppen anlegt. Mahara wurde so
konzipiert, dass es den Nutzer/innen alle Werkzeuge bereitstellt, um eine persönliche, professionelle Lernum-
gebung, eine Entwicklungs- und Präsentationsplattfrom zu gestalten.</p>

<p>Für weitere Informationen kannst du <a href="about.php">Über</a> Mahara lesen beziehungsweise gerne <a href="contact.php">Kontakt</a> aufnehmen.</p>';
$string['privacydefaultcontent'] = '<h1>Datenschutzerklärung</h1>
    
<h2>Einführung</h2>

<p>Wir sind verpflichtet Ihren Daten zu schützen und den Nutzer/innen eine sichere und funktionale persönliche Lernumgebung bereitzustellen. Diese Datenschutzerklärung gilt für die Maharaseite und regelt die Datensammlung und deren Gebrauch.</p>

<h2>Die Sammlung persönlicher Informationen</h2>

<p>Mit der Anmeldung bei Mahara werden Sie bestimmte persönliche Daten bereitstellen müssen.  Ohne Ihr schriftliches Einverständnis oder ein vorschreibendes Gesetz werden wir keine Ihrer Daten an andere Personen oder Organisationen weitergeben.</p>

<h2>Cookies</h2>

<p>Zur Nutzung von Mahara müssen Cookies in Ihrem Browser aktiviert werden.  Die Cookies dienen nur dazu, dass Sie beim Aufruf einer Seite nach dem Login als zugriffsberechtigte/r Nutzer/in erkannt werden.</p>

<p>Cookies sind kleine Dateien, die vom Webserver auf Ihrem Computer abgelegt werden. Bei Cookies handelt es sich nichtum ausführbare Programme, Viren oder Spionageprogramm. Sie können selber nichts ausführen.</p>

<h2>Wie Ihre persönlichen Daten verwendet</h2>

<p>Wir werden Ihre persönlichen Daten nur für die Zwecke verwenden zu denen sie von Ihnen zur Verfügung gestellt wurden.</p>

<p>Als Mahara Nutzer/in können Sie selber festlegen, welche persönlichen Informationen Sie für andere sichtbar machen.  In der Basisieinstellung können nur Administrator/innen, Kursverwalter oder Tutoren auf Ihre Daten zugreifen. Andere Nutzer/innen können nur Ihren präferierten Namen sehen. Administrator/innen, Kursverwalter/innen und Tutor/innen sehen auch was sie zuletzt getan haben und Ihre Logdaten. </p>

<p>Für statistische Zwecke werden weitere Nutzungsinformationen ausgewertet. Dabei werden jedoch keinerlei personenbezogene Informationen gespeichert.</p>

<h2>Die Speicherung und Sicherheit persönlicher Daten</h2>

<p>Wir unternehmen alles uns Mögliche, um Ihre personenbezogenen Daten vor unberechtigtem Zugriff, Verlust, Veröffentlichung oder unberechtigter Änderung zu schützen. </p>

<p>Zum Schutz Ihrer persönlichen Daten achten Sie sorgfältig darauf, welchen Daten Sie welchen anderen Nutzer/innen oder öffentlich sichtbar machen. Achten Sie besonders auf den Schutz des Nutzernamens und des Passworts.</p>

<h2>Änderungen der Datenschutzerklärung</h2>

<p>Diese Datenschutzerklärung kann von Zeit zu Zeit angepasst werde. Dies kann aufgrund technischer oder gesetzlicher Änderungen oder von Anregungen der Nutzer/innen erforderlich werden. Bitte sehen Sie sich diese Informationen daher von Zeit zu Zeit wieder an.</p>

<h2>Kontakt</h2>

<p>Wenn Sie zu dieser Erklärung Fragen haben, um sie besser zu verstehen oder der Ansicht sind, dass etwas nicht so gehandhabt wird, wie hier erklärt, nehmen Sie bitte mit uns <a href="contact.php">Kontakt</a> auf.  Wir werden uns bemühen Ihnen kurzfristig zu antworten.</p>';
$string['staticpageconfigdefault'] = '"Startseiten" in "Site-Konfiguration" in "Administration"';
$string['staticpageconfiginstitution'] = '"Startseiten" in "Institutionen" in "Administration"';
$string['termsandconditionsdefaultcontent'] = '<h2>Nutzungsbedingungen</h2>

<p>Mit Ihrer Registrierung auf dieser Plattform stimmst du den folgenden Nutzungsbedingungen zu. </p>

<h2>Unsere Pflichten</h2>

<p>Die Betreiber der Seite unternehmen alle ihnen möglichen Massnahmen, die Daten auf dieser Plattform sorgfältig zu verwalten, die Plattform sicher zu betreiben und verfügbar zu halten. Falls du jemals den Eindruck hast, deine Rechte als Nutzer/in seien beeinträchtigt worden oder wenn du diesbezüglich Fragen hast, wende dich bitte über das <a href="contact.php">Kontaktformular an uns</a>. Wir werden uns bemühen, umgehend zu antworten.</p>

<p>Wir versuchen, dieses System so durchgängig wie möglich für die registrierten Nutzer/innen zur Verfügung zu halten. Während kurzer Wartungsperioden und bei Updates kann es zu Unterbrechungen kommen. Wir werden diese in der Regel im vorhinein ankündigen.</p>

<p>Wir bitten dich unangemessenes Material auf den verschiedenen Seiten  oder anstössiges Verhalten anderer Nutzer/innen <a href="contact.php">an uns zu berichten</a>.  Wir werden dem kurzfristig nachgehen.</p>

<p>Site Administrator/innen haben jederzeit Zugriff auf dein Portfolio und von dir hinterlegte Inhalte. Wir werden diese Möglichkeit nur nutzen, um Support bereitzustellen oder aus anderen in diesen Bedingungen genannten Gründen.</p>

<h2>Deine Pflichten</h2>

<p> Die <a href="privacy.php">Datenschutzerklärung</a> ist eine Ergänzung zu diesem Dokument und ist ebenfalls durch alle Nutzer/innen zur Kenntnis zu nehmen und einzuhalten..</p>

<p>Dein Mahara-Nutzerzugang ist zeitlich begrenzt. Die Dauer  ist durch die Administration festgelegt worden. Nach Ablauf dieses Zeitraums oder längerer Inaktivität ist ein Zugriff für dich nicht mehr möglich. Du erhältst kurz vor Ablauf deines Nutzergangs von uns eine E-Mail als Benachrichtigung. Wir empfehlen dir dringend alle Ihre Daten vor Ablauf des Nutzerzugangs auf Ihrem PC zu speichern. Nur so kannst du sicherstellen, später das Material noch nutzen zu können.</p>

<p>Alle Dateien und Inhalte, die du hier hochlädst oder schreibst unterliegen den urheberrechtlichen Bestimmungen des Landes in dem das System betrieben wird.  Du bist als Nutzer/in selber dafür verantwortlich für jegliches Material, für welches du nicht selber als Urheber giltsrn, sicherzustellen, dass die entsprechenden Urheber oder Inhaber der Verwertungsrechte Ihrer Nutzung durch dich zugestimmt haben. Verstösse werden nach den Richtlinien für Plagiate des Betreibers verfolgt. Systemadministrator/innen und gegebenfalls andere Verantwortliche sind berechtigt entsprechendes Material ohne Vorankündigung zu beseitigen oder zu sperren.</p>

<p>Kein/e Nutzer/in ist berechtigt strafbare Inhalte, volksverhetzende, ausländerfeindliche oder beleidigende Inhalte in einem Portfolio abzulegen. Dabei kommt es nicht darauf an, ob dieses öffentlich, nur für Einrichtungen oder Gruppen oder nur privat einsehbar ist. Sofern ein/e Administrator/in oder eine von ihnen beauftragte Person davon Kenntnis erlangt, ist sie berechtigt, deinen Nutzerzugang und den Zugang zu den Inhalten  für weitere Personen zu sperren. Nach einer Untersuchung kann über weitere Schritte entschieden werden. Es besteht in diesem Fall für Nutzer/innen kein Recht auf Zugriff auf irgendein Material oder auf dessen Aushändigung. Die Betreiber der Seite oder die Administrator/innen sind nach eigenem Ermessen dazu berechtigt, entsprechende Inhalte zu löschen oder den gesamten Accounts einen Nutzers samt allen Inhalten zu schließen. In diesem Fall besteht keinerlei Anspruch auf Schadensersatz oder Aushändigung der Inhalte. </p>

<p>Sofern die Betreiber, Administrator/innen oder von ihnen beauftragte Personen von unangemessenem Verhalten von Nutzer/innen erfahren, sind sie in gleicher Weise wie oben beschrieben berechtigt den Nutzerzugang zu sperren und Dateien und Inhalte zu löschen.</p>

<p>Unangemessenes Verhalten können auch das Hochladen von virenverseuchten Medien, der Versuch das System zu kompromittieren, aggressive Forenbeiträge oder Feedback umfassen. </p>

<p>Es liegt in deiner persönlichen Verantwortung welche Informationen über deine Person du in welchem Umfang öffentlich sichtbar machen. Wir empfehlen grundsätzlich, dies nur sehr eingeschränkt zu tun, und immer darauf zu achten, dass die Informationen für dich zu keinem Zeitpunkt negative oder unerwünschte Folgen haben oder haben könnten. Die Betreiber sind nicht dafür verantwortlich wenn es aufgrund von von dir veröffentlichen Informationen und Medien zu nicht gewünschten Kontaktaufnahmen kommt. </p>

<p>Wir möchen dich dennoch bitten, im Falle von unangemessenem Verhalten anderer Nutzer/innen <a href="contact.php">mit uns Kontakt aufzunehmen</a>.</p>

<p>Neben den hier beschreibenen Massnahmen kann bei den beschriebenen Vorfällen auch ein Vorgehen nach anderen Bestimmungen der Institution, die das System betreibt oder deren Mitglied du bist erfolgen. 

<p>Von Zeit zu Zeit werden wir diese Bestimmungen der tatsächlichen Nutzung der Plattform und den gesetzlichen oder institutionellen Bestimmungen anpassen.  Bei größeren Änderungen werden wir diese über die Startseite bekanntgeben.
</p>';
$string['uploadcopyrightdefaultcontent'] = 'Ja: Die Datei, die ich hochladen will, gehört mir oder ich habe die ausdrückliche Genehmigung dieses Element zu benutzen.  Meine Verwendung dieser Datei verstößt gegen keine Copyright Bestimmung. Die Datei entspricht ebenso den Nutzerbestimmungen dieser Website.';
