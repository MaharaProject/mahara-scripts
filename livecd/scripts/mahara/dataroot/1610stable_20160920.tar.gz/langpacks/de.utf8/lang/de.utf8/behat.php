<?php

defined('INTERNAL') || die();

$string['errorbehatcommand'] = 'Fehler beim Ausführen des Behat CLI Befehls. Versuchen Sie "{$a} --help" manuell von CLI auszuführen, um mehr über das Problem zu erfahren.';
$string['errorcomposer'] = 'Die Verfasser-Abhängigkeiten sind nicht installiert.';
$string['errordataroot'] = '$CFG->behat_dataroot ist nicht eingestellt oder ist ungültig.';
$string['errorsetconfig'] = '$CFG->behat_dataroot, $CFG->behat_dbprefix und $CFG->behat_wwwroot muss in config.php eingestellt werden.';
$string['erroruniqueconfig'] = 'Die $CFG->behat_dataroot, $CFG->behat_dbprefix und $CFG->behat_wwwroot Werte müssen sich von $CFG->dataroot, $CFG->dbprefix, $CFG->wwwroot, $CFG->phpunit_dataroot und $CFG->phpunit_prefix Werten unterscheiden.';
