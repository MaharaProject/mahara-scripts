<?php

defined('INTERNAL') || die();

$string['accessdenied'] = 'Der Zugriff wurde verweigert';
$string['accessdeniedexception'] = 'Du hast nicht die Erlaubnis, diese Seite zu betrachten';
$string['accessdeniedobjection'] = 'Zugang verweigert. Der Vorgang wurde bereits von einem anderen Administrator geklärt.';
$string['apcstatoff'] = 'Ihr Server scheint APC mit der Einstellung apc.stat=0 zu benutzen. Mahara unterstützt diese Konfiguration nicht. Sie müssen in der Datei php.ini den Eintrag apc.stat=1 hinzufügen.

Wenn Sie die Site auf einem Shared Host betreiben, können Sie wahrscheinlich wenig tun, um die Einstellung apc.stat=1 zu aktivieren, außer Ihren Hostingprovider zu kontakten. Vielleicht sollten Sie den Wechsel zu einem anderen Host in Erwägung ziehen.';
$string['artefactnotfound'] = 'Das Artefakt mit der ID %s wurde nicht gefunden';
$string['artefactnotfoundmaybedeleted'] = 'Das Artefakt mit der ID %s wurde nicht gefunden';
$string['artefactnotinview'] = 'Das Artefakt %s ist nicht in der Ansicht %s';
$string['artefactonlyviewableinview'] = 'Artefakte dieses Typs sind nur innerhalb einer Ansicht sichtbar';
$string['artefactpluginmethodmissing'] = 'Das Artefaktplugin %s sollte %s implementieren aber es ist ein Fehler aufgetreten';
$string['artefactsnotfound'] = 'Kein(e) Artefakt(e) mit der/ den ID(s) gefunden: %s';
$string['artefacttypeclassmissing'] = 'Die Artefakttypen müssen alle eine Klasse implementieren.  Es fehlt %s';
$string['artefacttypemismatch'] = 'Artefakt Typenunterschied, Sie versuchen %s als %s zu benutzen';
$string['artefacttypenametaken'] = 'Der Artefakttyp %s wird schon von einem anderen Plugin (%s) benutzt';
$string['blockconfigdatacalledfromset'] = 'Configdata Informationen sollten nicht unmittelbar gesetzt werden, benutzen Sie bitte  dafür PluginBlocktype::instance_config_save';
$string['blockinstancenotfound'] = 'Die Blockinstanz mit der ID %s wurde nicht gefunden';
$string['blocktypelibmissing'] = 'Fehlende Datei lib.php für den Block %s im Artefaktplugin %s';
$string['blocktypemissingconfigform'] = 'Der Blocktyp %s muss eine instance_config_form implementieren';
$string['blocktypenametaken'] = 'Der Blocktyp %s wird schon von einem anderen Plugin (%s) benutzt';
$string['blocktypeprovidedbyartefactnotinstallable'] = 'Dies wird im Rahmen der Installation des Artefakttyps %s eingefügt';
$string['classmissing'] = 'Die Klasse %s für den Typ %s im Plugin %s fehlt';
$string['couldnotmakedatadirectories'] = 'Aus irgendeinem Grund können einige der notwendigen Systemverzeichnisse nicht angelegt werden. Das sollte nicht passieren, da Mahara zuvor entdeckt hat, dass das Dataroot Verzeichnis beschreibbar ist. Kontrollieren Sie bitte die Zugriffsberechtigungen des Dataroot Verzeichnisses.';
$string['cssnotpresent'] = 'CSS Dateien sind nicht in Ihrem htdocs/theme/raw/style Datenverzeichnis. Wenn Sie Mahara über eine git Erprobung ausführen, führen Sie "make css" aus um die CSS Datei zu erschaffen. Wenn Sie Mahara über einen ZIP Download ausführen, versuchen Sie diesen erneut herunterzuladen und zu entpacken.';
$string['curllibrarynotinstalled'] = 'Ihre Serverkonfiguration enthält keine curl Erweiterung. Mahara benötigt diese Erweiterung für die Integration von Moodle und zum Abfragen externer Feeds. Stellen Sie bitte sicher, dass die Erweiterung in php.ini geladen wird oder installieren Sie die Erweiterung, wenn dies noch nicht geschehen ist.';
$string['datarootinsidedocroot'] = 'Sie haben Ihr Datenverzeichnis so eingestellt, dass es innerhalb des Dokumentenverzeichnisses angelegt wird. Dies ist eine großes Sicherheitsproblem, weil dann jedermann direkt Sitzungsdaten anfordern kann (um so die Sitzungen anderer Nutzer/innen zu berauben), oder auf Dateien, für die keine Zugriffsberechtigung vorliegt, benutzen kann . Bitte richten Sie das Dataroot Verzeichnis so ein, dass es außerhalb des Dokumentenverzeichnis installiert wird.';
$string['datarootnotwritable'] = 'Ihr festgelegtes Dataroot Verzeichnis, <tt>%s</tt>, ist nicht beschreibbar. Das bedeutet, dass weder Sessiondaten, Benutzerdateien noch sonst irgendetwas, das hochgeladen werden soll, auf Ihrem Server gespeichert werden kann. Stellen Sie bitte sicher, dass das Verzeichnis existiert und benutzt werden kann.';
$string['dbconnfailed'] = 'Mahara kann keine Verbindung zur Applikationdatenbank herstellen.


 * Wenn Sie Mahara als Benutzer/in anwenden, warten Sie bitte eine Minute und versuchen Sie es dann erneut
 * Als Administrator kontrollieren Sie bitte die Datenbankeinstellungen und stellen Sie sicher, dass die Datenbank verfügbar ist

Die Fehlermeldung lautet:
';
$string['dbnotutf8'] = 'Sie nutzen keine UTF-8 Datenbank. Mahara speichert aber intern alle Daten im UTF-8 Format. Bitte löschen Sie die Datenbank und erstellen eine neue Datenbank mit UTF-8 Codierung.';
$string['dbversioncheckfailed'] = 'Ihre Datenbankserverversion ist nicht aktuell, um mit Mahara zu arbeiten. Ihr Server ist %s %s, aber Mahara benötigt zumindest die Version %s.';
$string['domextensionnotloaded'] = 'Ihre Serverkonfiguration enthält keine DOM Erweiterung. Mahara benötigt diese aber um XML Daten von unterschiedlichen Quellen zu untersuchen.';
$string['gdextensionnotloaded'] = 'Ihre Serverkonfiguration enthält keine gd Erweiterung. Mahara benötigt diese Erweiterung um Größenänderungen und andere Operationen beim Hochladen von Bildern auszuführen. Stellen Sie bitte sicher, dass die Erweiterung in php.ini geladen wird oder installieren Sie die Erweiterung, wenn dies noch nicht geschehen ist.';
$string['gdfreetypenotloaded'] = 'Ihre Serverkonfiguration der gd Erweiterung schließt keine Freetype Unterstützung ein. Mahara benötigt diese Erweiterung zur Darstellung des CAPTCHA Bildes. Stellen Sie bitte sicher, dass die Erweiterung damit konfiguriert ist.';
$string['gdlibrarylacksgifsupport'] = 'Die installierte PHP GD Library unterstützt das Anzeigen und Erzeugen von GIF-Dateien nicht. Für den Upload von GIF-Dateien ist dies jedoch erforderlich.';
$string['gdlibrarylacksjpegsupport'] = 'Die installierte PHP GD Library unterstützt JPEG/JPG-Dateien nicht. Für den Upload von JPEG/JPG-Dateien ist dies jedoch erforderlich.';
$string['gdlibrarylackspngsupport'] = 'Die installierte PHP GD Library unterstützt PNG-Dateien nicht. Für den Upload von PNG-Dateien ist dies jedoch erforderlich.';
$string['interactioninstancenotfound'] = 'Die Aktivität mit der ID %s wurde nicht gefunden';
$string['invaliddirection'] = 'Ungültige Vorgabe %s';
$string['invalidlayoutselection'] = 'Du hast versucht, ein Layout zu verwenden, das nicht existiert.';
$string['invalidnumrows'] = 'Du hast versucht ein Layout zu erstellen, das mehr Zeilen nutzt als zugelassen. (Dies sollte eigentlich nicht möglich sein. Benachrichtige den Site-Administrator.)';
$string['invalidviewaction'] = 'Ungültige Aktion die Ansicht zu kontrollieren: %s';
$string['jsonextensionnotloaded'] = 'Ihre Server Konfiguration enthält keine JSON Erweiterung. Mahara benötigt diese aber, um Daten an den Browser zu senden oder zu erhalten. Stellen Sie bitte sicher, dass die Erweiterung in php.ini geladen wird oder installieren Sie die Erweiterung, wenn dies noch nicht geschehen ist.';
$string['magicquotesgpc'] = 'Sie benutzen gefährliche PHP Einstellungen, magic_quotes_gpc ist on. Mahara versucht eine provisorische Lösung, aber Sie sollten diese Einstellung wirklich korrigieren. Wenn Sie einen Shared Host benutzen und die Möglichkeit besteht, können Sie versuchen folgende Zeile in die Datei .htaccess Datei einzufügen:
+php_flag magic_quotes_sybase off';
$string['magicquotesruntime'] = 'Sie benutzen gef&auml;hrliche PHP Einstellungen, magic_quotes_runtime ist on. Mahara versucht eine provisorische L&ouml;sung, aber Sie sollten diese Einstellung wirklich korrigieren. Wenn Sie einen Shared Host benutzen und die Möglichkeit besteht, können Sie versuchen folgende Zeile in die Datei .htaccess Datei einzufügen:
+php_flag magic_quotes_sybase off';
$string['magicquotessybase'] = 'Sie benutzen gefährliche PHP Einstellungen, magic_quotes_sybase is on. Mahara versucht eine provisorische Lösung, aber Sie sollten diese Einstellung wirklich korrigieren. Wenn Sie einen Shared Host benutzen und die Möglichkeit besteht, können Sie versuchen folgende Zeile in die Datei .htaccess Datei einzufügen:
+php_flag magic_quotes_sybase off';
$string['mbstringneeded'] = 'Bitte installieren Sie die mbstring Erweiterung für PHP.  Diese ist bei UTF-8 Zeichen in Nutzernamen (z.B. Umlaute) erforderlich, da diese Nutzer/innen sich sonst nicht einloggen können.';
$string['missingparamblocktype'] = 'Versuche  zunächst einen Blocktyp festzulegen';
$string['missingparamcolumn'] = 'Fehlende Spaltenkonfiguration';
$string['missingparamid'] = 'Fehlende ID';
$string['missingparamorder'] = 'Fehlende Festlegung der Reihenfolge';
$string['missingparamrow'] = 'Fehlende Zeilen-Festelegung';
$string['mysqldbextensionnotloaded'] = 'Ihre Serverkonfiguration enthält keine mysql Erweiterung. Mahara benötigt diese Erweiterung, um Daten in einer relationalen Datenbank anzuspeichern. Stellen Sie bitte sicher, dass die Erweiterung in php.ini geladen wird oder installieren Sie die Erweiterung, wenn dies noch nicht geschehen ist.';
$string['mysqlnotriggerprivilege'] = 'Mahara benötigt die Berechtigung zum Erstellen von Datenbank Triggern, kann dies derzeit aber nicht ausführen.  Stellen Sie sicher, dass die erforderlichen Rechte in Ihrer MySQL Installation gegeben sind.  Hinweise finden Sie hier https://wiki.mahara.org/index.php/System_Administrator\'s_Guide/Granting_Trigger_Privilege';
$string['nopasswordsaltset'] = 'Es wurde keine systemweite Password Salt-Verschlüsselung eingerichtet. Bearbeiten Sie die config.php-Datei und setzen Sie den "passwordsaltmain" Parameter mit hinreichender Sicherheit.';
$string['noreplyaddressmissingorinvalid'] = 'Die noreply-Adress-Einstellung ist entweder leer oder enthält eine ungültige E-Mail-Adresse. Bite prüfen Sie die Einstellung unter <a href="%s">E-Mail-Einstellungen</a>.';
$string['notartefactowner'] = 'Du besitzt dieses Artefakt nicht';
$string['notenoughsessionentropy'] = 'Ihre PHP session.entropy_length Einstellung ist zu niedrigl. Setzen Sie den Wert mindestens auf 16 in der php.ini-Datei, um sicherzustellen, dass die erzeugten Session-IDs zufällig und nicht erratbar sind.';
$string['notfound'] = 'Nicht gefunden';
$string['notfoundexception'] = 'Die gewünschte Seite konnte nicht gefunden werden';
$string['notproductionsite'] = 'Diese Seite ist nicht im Produktiv-Modus. Einige Daten sind daher nicht verfügbar und/oder nicht mehr aktuell.';
$string['onlyoneblocktypeperview'] = 'Du kannst nicht mehr als einen %s Blocktyp in die Ansicht einfügen';
$string['onlyoneprofileviewallowed'] = 'Du darfst nur eine Profilansicht anlegen';
$string['openbasedirenabled'] = 'Auf Ihrem Server sind die php open_basedir Beschränkungen aktiviert.';
$string['openbasedirpaths'] = 'Mahara kann nur Dateien in folgenden Pfad(en) öffnen: %s';
$string['openbasedirwarning'] = 'Einige Aufrufe externer Seiten können scheitern.  Dadurch kann neben anderem die Aktualisierung externer Feeds nicht ausgeführt werden.';
$string['parameterexception'] = 'Ein erforderlicher Parameter fehlt';
$string['passwordsaltweak'] = 'Der systemweite Password Salt-Schlüssel ist nicht sicher genug. Bearbeiten Sie die Einstellung in der config.php-Datei und erstellen Sie einen längeren "passwordsaltmain" Parameter.';
$string['pgsqldbextensionnotloaded'] = 'Ihre Serverkonfiguration enthält keine pgsql Erweiterung. Mahara benötigt diese Erweiterung, um Daten in einer relationalen Datenbank anzuspeichern. Stellen Sie bitte sicher, dass die Erweiterung in php.ini geladen wird oder installieren Sie die Erweiterung, wenn dies noch nicht geschehen ist.';
$string['phpversion'] = 'Mahara arbeitet nicht mit einer PHP Version < %s. Aktualisieren Sie bitte Ihre PHP Version oder installieren Sie Mahara auf einem anderen Host.';
$string['pleaseloginforjournals'] = 'Du musst dich ausloggen und wieder einloggen, um alle Blogs und Beiträge zu sehen.';
$string['plpgsqlnotavailable'] = 'Die PL/pgSQL Sprache ist für Ihre Postgres Installation nicht aktiviert. Mahara kann diese nicht aktivieren. Installieren Sie PL/pgSQL in Ihrer Datenbank manuell.  Hinweise hierzu finden Sie unter https://wiki.mahara.org/index.php/System_Administrator\'s_Guide/Enabling_Plpgsql';
$string['postmaxlessthanuploadmax'] = 'Die PHP Einstellung post_max_size (%s) ist kleiner als die Einstellung upload_max_filesize (%s).  Uploads, die größer als %s sind, werden ohne Fehlermeldung fehlschlagen.  Normalerweise sollte der Wert post_max_size viel größer als der Wert upload_max_filesize sein.';
$string['previewimagegenerationfailed'] = 'Sorry. Beim Erstellen des Vorschau-Bildes ist ein Fehler aufgetreten.';
$string['registerglobals'] = 'Sie benutzen gefährliche PHP Einstellungen, register_globals ist on. Mahara versucht eine provisorische Lösung, aber Sie sollten diese Einstellung wirklich korrigieren. Wenn Sie einen Shared Host benutzen und die Möglichkeit besteht, können Sie versuchen folgende Zeile in die Datei .htaccess Datei einzufügen:
+php_flag magic_quotes_sybase off';
$string['safemodeon'] = '<p>Ihr Server scheint im safe mode zu arbeiten. Mahara unterstützt diesen Modus nicht. Sie müssen den Modus entweder in der php.ini Datei oder in Ihrer Apache-Konfiguration für die Site umstellen.</p><p>Wenn Sie die Site auf einem Shared Host betreiben, können Sie wahrscheinlich wenig tun, um den  safe_mode auszuschalten, außer Ihren Hostingprovider zu kontakten. Vielleicht sollten Sie den Wechsel zu einem anderen Host in Erwägung ziehen.</p>';
$string['sessionextensionnotloaded'] = 'Ihre Serverkonfiguration enthält keine session Erweiterung. Mahara benötigt diese Erweiterung um die Nutzeranmeldung zu unterstützen. Stellen Sie bitte sicher, dass die Erweiterung in php.ini geladen wird oder installieren Sie die Erweiterung, wenn dies noch nicht geschehen ist.';
$string['sessionpathnotwritable'] = 'Das Verzeichnis für Sessiondaten %s kann nicht beschrieben werden. Erstellen Sie das Verzeichnis und geben Sie dem Webserver-Nutzer Nutzungsrechte.';
$string['smallpostmaxsize'] = 'Der PHP Einstellung post_max_size (%s) ist sehr klein.  Uploads, die größer als %s sind, werden ohne Fehlermeldung fehlschlagen.';
$string['switchtomysqli'] = 'Die  <strong>mysqli</strong> PHP Erweiterung ist auf Ihrem Server nicht installiert. Daher verwendet Mahara weiterhin die veraltete <strong>mysql</strong> PHP Erweiterung. Wir empfehlen die Installation von <a href="http://php.net/manual/en/book.mysqli.php">mysqli</a>.';
$string['themenameinvalid'] = 'Der Name des Theme \'%s\' enthält ungültige Zeichen.';
$string['timezoneidentifierunusable'] = 'PHP liefert für Ihren Webhost keinen brauchbaren Wert für die Zeitzonenkennung (%%z) - bestimmte Datenformatierungen, beispielsweise beim Leap2A-Export, können zerstört sein.  %%z ist ein PHP Datenformatierungscode. Dieses Problem tritt in der Regel aufgrund einer Einschränkung in PHP unter Windows auf.';
$string['unabletosetmultipleblogs'] = 'Die Aktivierung mehrer Blogs für Nutzer/in %s ist gescheitert beim Kopieren der Seite %s . Dies kann manuell auf dieser <a href="%s">Zugangsseite</a> eingestellt werden.';
$string['unknowndbtype'] = 'Ihre Serverkonfiguration meldet einen unbekannten Datenbanktyp. Gültige Einträge sind "postgres8" und "mysql5". Bitte ändern Sie den Datenbanktyp in der Datei config.php.';
$string['unrecoverableerror'] = 'Es hat sich ein nicht behebbarer Fehler ereignet. Sie haben vielleicht einen Fehler im System entdeckt.';
$string['unrecoverableerrortitle'] = '%s - Site nicht verfügbar';
$string['versionphpmissing'] = 'Das Plugin %s %s hat keine Datei version.php!';
$string['viewnotfound'] = 'Die Ansicht mit der ID %s wurde nicht gefunden';
$string['viewnotfoundbyname'] = 'Seite %s von %s wurde nicht gefunden';
$string['viewnotfoundexceptionmessage'] = 'Du hast versucht auf eine Ansicht zuzugreifen, die nicht existiert!';
$string['viewnotfoundexceptiontitle'] = 'Die Ansicht wurde nicht gefunden';
$string['wwwrootnothttps'] = 'Der angegeben wwwroot, %s, ist nicht HTTPS. Andere Einstellungen (z.B. der sslproxy) Ihrer Installation erfordert, dass der  wwwroot eine HTTPS Adresse ist.

Ändern Sie die wwwroot Einstellungen auf eine HTTPS Adresse oder ändern Sie die falsche Einstellung.';
$string['xmlextensionnotloaded'] = 'Ihre Serverkonfiguration enthält keine %s Erweiterung. Mahara benötigt diese aber um XML Daten für den Installationsvorgang und Backups zu analysieren. Stellen Sie bitte sicher, dass die Erweiterung in php.ini geladen wird oder installieren Sie die Erweiterung, wenn dies noch nicht geschehen ist.';
$string['youcannotviewthisusersprofile'] = 'Sie können das Profil dieses Benutzers nicht aufrufen';
