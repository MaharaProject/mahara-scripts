<?php

defined('INTERNAL') || die();

$string['buildingindexpage'] = 'Anlegen der Indexseite';
$string['copyingextrafiles'] = 'Kopieren zusätzlicher Dateien';
$string['description'] = 'Erzeugt eine separate Webseite mit deinen Portfoliodaten. Du kannst diese HTML-Webseite nicht wieder importieren, aber die Webseite ist mit jedem Webbrowser anzeigbar.';
$string['duplicatepagetitle'] = 'Der Export wurde unterbrochen, da Ansichtentitel mehrfach vorkamen. Bitte änder die Namen, damit sie einmalig sind.';
$string['exportingdatafor'] = 'Daten für %s werden exportiert';
$string['preparing'] = '%s wird vorbereitet';
$string['title'] = 'Selbständige HTML Webseite';
$string['usersportfolio'] = '%s - Portfolio';
