<?php

defined('INTERNAL') || die();

$string['cantsendemptysubject'] = 'Ihr Betreff ist leer. Bitte geben Sie einen Betreff ein.';
$string['cantsendemptytext'] = 'Ihre Nachrichtenfeld ist leer. Bitte geben Sie eine Nachricht ein.';
$string['cantsendnorecipients'] = 'Bitte wählen Sie mindestens einen Empfänger aus.';
$string['clickformore'] = '(Drücken Sie die \'Enter-Taste", um weitere Informationen anzuzeigen)';
$string['composemessage'] = 'Verfassen';
$string['composemessagedesc'] = 'Neue Nachricht schreiben';
$string['deletednotifications1'] = '%s Benachrichtigungen wurden gelöscht. Interne Benachrichtigungen können nicht im \'Gesendet\'-Bereich gelöscht werden.';
$string['deleteduser'] = 'gelöschte(r) Nutzer';
$string['fromuser'] = 'Von';
$string['inboxdesc1'] = 'Nachrichten vom System und von anderen Nutzern';
$string['labelinbox'] = 'Posteingang';
$string['labeloutbox1'] = 'Gesendet';
$string['labelrecipients'] = 'An: ';
$string['labelsubject'] = 'Betreff:';
$string['linkindicator'] = '»';
$string['notification'] = 'Benach­rich­ti­gungen';
$string['outboxdesc'] = 'Die Nachrichten wurden an die anderen Nutzer versendet';
$string['removeduserfromlist'] = 'Ein Nutzer, der keine Nachrichten von Ihnen empfangen kann, wurde von der Empfängerliste entfernt.';
$string['reply'] = 'Antworten';
$string['replyall'] = 'Allen antworten';
$string['replybuttonplaceholder'] = '…';
$string['replysubjectprefix'] = 'Re:';
$string['selectalldelete'] = 'Alle Benachrichtigungen zum Löschen';
$string['selectallread'] = 'Alle ungelesenen Benachrichtigungen';
$string['sendmessageto'] = 'Nachricht senden';
$string['titlerecipient'] = 'Empfänger';
$string['titlesubject'] = 'Betreff';
$string['touser'] = 'An';
