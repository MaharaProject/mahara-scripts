<?php

defined('INTERNAL') || die();

$string['description'] = 'Externen Content hinzufügen';
$string['glogster'] = 'Glogster';
$string['googlevideo'] = 'Google Video';
$string['height'] = 'Höhe';
$string['invalidurl'] = 'Ungültige URL';
$string['invalidurlorembed'] = 'Ungültige URL oder eingebetteter Code';
$string['prezi'] = 'Prezi';
$string['scivee'] = 'SciVee';
$string['slideshare'] = 'SlideShare';
$string['teachertube'] = 'TeacherTube';
$string['title'] = 'Externes Medium';
$string['urlorembedcode'] = 'URL oder eingebetteter Code';
$string['validiframesites'] = '<strong>Embed code</strong> mit &lt;iFrame&gt; Tags ist für folgende Seiten erlaubt:';
$string['validurlsites'] = '<strong>URL\'s</strong> von folgenden Seiten sind erlaubt:';
$string['videourldescription3'] = 'Kopieren Sie den <strong>eingebetteten Code</strong> oder die <strong>URL</strong> der Seite, die den Inhalt enthält.';
$string['vimeo'] = 'Vimeo';
$string['voicethread'] = 'VoiceThread';
$string['voki'] = 'Voki';
$string['width'] = 'Breite';
$string['widthheightdescription'] = 'Die Breite und Höhe der Felder wird nur für URLs genutzt. Wenn embed Code oder iFrames verwandt werden, müssen die Größeneinträge im Code angepasst werden.';
$string['wikieducator'] = 'WikiEducator';
$string['youtube'] = 'YouTube';
