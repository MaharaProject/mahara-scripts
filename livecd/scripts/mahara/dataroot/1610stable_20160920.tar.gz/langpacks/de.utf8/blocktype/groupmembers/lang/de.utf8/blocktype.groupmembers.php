<?php

defined('INTERNAL') || die();

$string['Latest'] = 'Letzte';
$string['Random'] = 'Zufällig';
$string['defaulttitledescription'] = 'Wenn das Feld leer bleibt, wird ein Standardtitel angezeigt';
$string['description'] = 'Anzeige der Mitglieder in dieser Gruppe';
$string['options_numtoshow_desc'] = 'Anzahl der Mitglieder, die angezeigt werden sollen.';
$string['options_numtoshow_title'] = 'Angezeigte Mitglieder';
$string['options_order_desc'] = 'Du kannst auswählen, ob die letzten Gruppenmitglieder oder eine zufällige Auswahl angezeigt wird.';
$string['options_order_title'] = 'Reihenfolge';
$string['show_all'] = 'Alle Mitglieder dieser Gruppe anzeigen…';
$string['title'] = 'Gruppenmitglieder';
