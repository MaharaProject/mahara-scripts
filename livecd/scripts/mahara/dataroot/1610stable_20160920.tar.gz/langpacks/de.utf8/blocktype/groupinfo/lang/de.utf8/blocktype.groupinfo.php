<?php

defined('INTERNAL') || die();

$string['description'] = 'Anzeige von Informationen über die Gruppe';
$string['title'] = 'Gruppenübersicht';
