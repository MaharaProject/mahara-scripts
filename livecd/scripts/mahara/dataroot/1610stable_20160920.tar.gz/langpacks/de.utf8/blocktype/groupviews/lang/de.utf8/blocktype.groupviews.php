<?php

defined('INTERNAL') || die();

$string['defaulttitledescription'] = 'Wenn das Feld leer bleibt, wird ein Standardtitel angezeigt';
$string['description'] = 'Anzeige der Ansichten, die mit der Gruppe verbunden sind';
$string['displaygroupviews'] = 'Gruppenansichten anzeigen';
$string['displaygroupviewsdesc'] = 'Gruppenansichten - Ansichten, die in der Gruppe angelegt wurden';
$string['displaysharedcollections'] = 'Geteilte Sammlungen anzeigen';
$string['displaysharedcollectionsdesc'] = 'Eine Liste mit Sammlungen anzeigen, die mit der Gruppe geteilt wurden.';
$string['displaysharedviews'] = 'Anzeige der freigegebenen Ansichten?';
$string['displaysharedviewsdesc1'] = 'Eine Liste mit Ansichten, die mit der Gruppe geteilt wurden, anzeigen (Ansichten innerhalb von Sammlungen werden nicht mit angezeigt).';
$string['displaysubmissions'] = 'Ansichten und Sammlungen, die bereitgestellt wurden, anzeigen.';
$string['displaysubmissionsdesc'] = 'Eine Liste mit Ansichten und Sammlungen anzeigen, die mit der Gruppe geteilt wurden.';
$string['itemstoshow'] = 'Einträge pro Seite';
$string['itemstoshowdesc'] = 'Anzahl der Sammlungen oder Ansichten in jedem Abschnitt. Maximal: 100.';
$string['showbyanybody'] = 'Von irgendjemandem';
$string['showbygroupmembers'] = 'Von Mitgliedern dieser Gruppe';
$string['shownone'] = 'Keine';
$string['sortgroupviewstitle'] = 'Gruppenansichten ordnen nach';
$string['sortsharedviewstitle'] = 'Sortieren Sie gemeinsame Ansichten und Sammlungen nach';
$string['sortsubmittedtitle'] = 'Sortieren Sie vorgeschlagene Seiten und Sammlungen nach';
$string['sortviewsbyalphabetical'] = 'Alphabetisch';
$string['sortviewsbylastupdate'] = 'Zuletzt bearbeitet';
$string['sortviewsbytimesubmitted'] = 'Zuletzt eingereicht';
$string['title'] = 'Gruppenansichten';
