<?php

defined('INTERNAL') || die();

$string['description'] = 'Anzeige der Kontakte';
$string['numberoffriends'] = '(%s von %s)';
$string['otherusertitle'] = 'Kontakte';
$string['title'] = 'Meine Kontakte';
