<?php

defined('INTERNAL') || die();

$string['Post'] = 'Beitrag absenden';
$string['addpostsuccess'] = 'Beitrag erfolgreich hinzugefügt';
$string['backtoprofile'] = 'Zurück zum Profil';
$string['delete'] = 'Nachricht löschen';
$string['deletepost'] = 'Nachricht löschen';
$string['deletepostsuccess'] = 'Die Nachricht wurde erfolgreich gelöscht';
$string['deletepostsure'] = 'Willst du die Nachricht wirklich unwiderruflich löschen?';
$string['description'] = 'Hier können die Besucher Nachrichten hinterlasen';
$string['makeyourpostprivate'] = 'Nachricht soll privat sein?';
$string['maxcharacters'] = 'Maximal %s Zeichen pro Nachricht.';
$string['noposts'] = 'Keine Nachrichten auf der Pinnwand vorhanden';
$string['otherusertitle'] = '%s\'s Pinnwand';
$string['postsizelimit'] = 'Maximale Nachrichtengröße';
$string['postsizelimitdescription'] = 'Du kannst die Zeichenanzahl der Nachrichten hier begrenzen. Bestehende Nachrichten werden dadurch nicht verändert';
$string['postsizelimitinvalid'] = 'Dies ist keine gültiger Wert.';
$string['postsizelimitmaxcharacters'] = 'Maximale Zeichenanzahl';
$string['postsizelimittoosmall'] = 'Dert Wert kann nicht kleiner 0 (Null) gesetzt werden.';
$string['posttextrequired'] = 'Dieses Feld ist ein Pflichfeld.';
$string['reply'] = 'Antworten';
$string['sorrymaxcharacters'] = 'Entschuldigung, Ihre Nachricht darf nicht mehr als %s Zeichen umfassen.';
$string['title'] = 'Pinnwand';
$string['viewwall'] = 'Pinnwand anzeigen';
$string['wall'] = 'Pinnwand';
$string['wholewall'] = 'Gesamte Pinnwand anzeigen';
