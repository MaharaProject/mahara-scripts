<?php

defined('INTERNAL') || die();

$string['emailfooter'] = 'Dies ist eine automatisch generierte Benachrichtigung von %s.  Die Nachrichteneinstellungen können hier geändert werden: %s';
$string['emailheader'] = 'Du hast von %s eine Nachricht erhalten. Hier folgt der Inhalt der Benachrichtigung:';
$string['emailsubject'] = '%s';
$string['name'] = 'E-Mail';
$string['referurl'] = 'Siehe %s';
