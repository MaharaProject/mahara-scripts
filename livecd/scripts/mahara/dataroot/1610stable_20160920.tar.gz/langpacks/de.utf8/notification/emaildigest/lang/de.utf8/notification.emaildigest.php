<?php

defined('INTERNAL') || die();

$string['emailbodyending'] = 'Um die Benachrichtigungseinstellungen zu verändern, besuche bitte %s';
$string['emailbodynoreply'] = 'Dies ist eine automatisch erzeugte Benachrichtigung von %s.  Es folgt die tägliche Übersicht aller Benachrichtigungen

--------------------------------------------------

';
$string['emailsubject'] = 'Meldung von %s: tägliche Übersicht';
$string['name'] = 'E-Mail-Tageszusammenfassung';
