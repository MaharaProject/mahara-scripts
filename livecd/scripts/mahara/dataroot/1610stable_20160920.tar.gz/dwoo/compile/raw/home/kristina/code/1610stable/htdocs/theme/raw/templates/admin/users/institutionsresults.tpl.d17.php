<?php
/* template head */
if (class_exists('Dwoo_Plugin_cycle', false)===false)
	$this->getLoader()->loadPlugin('cycle');
if (function_exists('Dwoo_Plugin_str')===false)
	$this->getLoader()->loadPlugin('str');
if (function_exists('Dwoo_Plugin_escape')===false)
	$this->getLoader()->loadPlugin('escape');
/* end template head */ ob_start(); /* template body */ ;

$_fh0_data = (is_string($tmp=(isset($this->scope["institutions"]) ? $this->scope["institutions"] : null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);
if ($this->isTraversable($_fh0_data) == true)
{
	foreach ($_fh0_data as $this->scope['institution'])
	{
/* -- foreach start output */
?>
        <tr class="<?php echo $this->classCall('cycle', array('default', 'r0,r1', true, true, ',', null, false));?>">
                <td>
                    <?php if (! $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'site',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["institution"]) ? $this->scope["institution"]:null), true)) {
?><a href="<?php echo (is_string($tmp=$this->scope["WWWROOT"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>institution/index.php?institution=<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'name',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["institution"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>"><?php 
}?>

                        <?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'displayname',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["institution"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>

                    <?php if (! $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'site',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["institution"]) ? $this->scope["institution"]:null), true)) {
?></a><?php 
}?>

                </td>
                <td class="center">
                  <?php if (! $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'site',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["institution"]) ? $this->scope["institution"]:null), true)) {
?>
                        <a href="<?php echo (is_string($tmp=$this->scope["WWWROOT"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>admin/users/institutionusers.php?usertype=members&amp;institution=<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'name',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["institution"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>"><?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'members',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["institution"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?></a>
                  <?php 
}
else {
?>
                        <a href="<?php echo (is_string($tmp=$this->scope["WWWROOT"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>admin/users/search.php?institution=mahara"><?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'members',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["institution"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?></a>
                  <?php 
}?>

                </td>
                <td class="center"><?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'maxuseraccounts',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["institution"]) ? $this->scope["institution"]:null), true)) {

echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'maxuseraccounts',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["institution"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);

}?></td>
                <td class="center">
                    <?php if (! $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'site',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["institution"]) ? $this->scope["institution"]:null), true)) {
?><a href="<?php echo (is_string($tmp=$this->scope["WWWROOT"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>admin/users/institutionstaff.php?institution=<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'name',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["institution"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>"><?php 
}?>

                        <?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'staff',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["institution"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>

                    <?php if (! $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'site',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["institution"]) ? $this->scope["institution"]:null), true)) {
?></a><?php 
}?></td>
                <td class="center">
                    <?php if (! $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'site',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["institution"]) ? $this->scope["institution"]:null), true)) {
?><a href="<?php echo (is_string($tmp=$this->scope["WWWROOT"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>admin/users/institutionadmins.php?institution=<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'name',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["institution"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>"><?php 
}?>

                        <?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'admins',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["institution"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>

                    <?php if (! $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'site',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["institution"]) ? $this->scope["institution"]:null), true)) {
?></a><?php 
}?></td>
                <td class="center"><?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'suspended',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["institution"]) ? $this->scope["institution"]:null), true)) {
?><span class="suspended"><?php echo Dwoo_Plugin_str($this, "suspendedinstitution", 'admin', null, null, null, null, null);?></span><?php 
}?></td>
                <td class="controls">
                        <?php if ((isset($this->scope["webserviceconnections"]) ? $this->scope["webserviceconnections"] : null)) {
?>
                            <a class="btn-link btn btn-xs pull-right" href="<?php echo (is_string($tmp=$this->scope["WWWROOT"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>webservice/admin/connections.php?i=<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'name',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["institution"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>">
                                <span class="icon icon-plug icon-lg text-default" role="presentation" aria-hidden="true"></span>
                                <span class="sr-only">
                                    <?php echo Dwoo_Plugin_escape($this, Dwoo_Plugin_str($this, 'connectspecific', 'mahara', null, $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'displayname',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["institution"]) ? $this->scope["institution"]:null), true), null, null, null), 'html', null);?>

                                </span>
                            </a>
                        <?php 
}?>

                        <form action="" method="post">
                            <input type="hidden" name="i" value="<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'name',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["institution"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>">
                            <button type="submit" name="edit" value="1" class="btn-link btn btn-xs pull-right" alt="<?php echo Dwoo_Plugin_escape($this, Dwoo_Plugin_str($this, 'editspecific', 'mahara', null, $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'displayname',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["institution"]) ? $this->scope["institution"]:null), true), null, null, null), 'html', null);?>">
                                <span class="icon icon-cog icon-lg text-default" role="presentation" aria-hidden="true"></span>
                                <span class="sr-only">
                                    <?php echo Dwoo_Plugin_str($this, "edit", 'mahara', null, null, null, null, null);?>

                                </span>
                            </button>
                        <?php if ((isset($this->scope["siteadmin"]) ? $this->scope["siteadmin"] : null) && ! $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'members',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["institution"]) ? $this->scope["institution"]:null), true) && $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'name',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["institution"]) ? $this->scope["institution"]:null), true) != 'mahara') {
?>
                            <button type="submit" name="delete" value="1" class="btn-link btn btn-xs pull-right" alt="<?php echo Dwoo_Plugin_escape($this, Dwoo_Plugin_str($this, 'deletespecific', 'mahara', null, $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'displayname',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["institution"]) ? $this->scope["institution"]:null), true), null, null, null), 'html', null);?>">
                                <span class="icon icon-trash text-danger icon-lg" role="presentation" aria-hidden="true"></span>
                                <span class="sr-only">
                                    <?php echo Dwoo_Plugin_str($this, "delete", 'mahara', null, null, null, null, null);?>

                                </span>
                            </button>
                        <?php 
}?>

                        </form>
                </td>
        </tr>
<?php 
/* -- foreach end output */
	}
}?>

<?php  /* end template body */
return $this->buffer . ob_get_clean();
?>