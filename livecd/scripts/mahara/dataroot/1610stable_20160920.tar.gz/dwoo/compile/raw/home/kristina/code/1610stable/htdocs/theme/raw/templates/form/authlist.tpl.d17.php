<?php
/* template head */
if (function_exists('Dwoo_Plugin_str')===false)
	$this->getLoader()->loadPlugin('str');
/* end template head */ ob_start(); /* template body */ ?><script type="application/javascript">

    function move_up(id) {
        instanceArray = document.getElementById('instancePriority').value.split(',');
        var outputArray = new Array();
        for(i = instanceArray.length - 1; i >= 0; i--) {
            if(instanceArray[i] == id) {
                outputArray[i] = instanceArray[i-1];
                outputArray[i-1] = instanceArray[i];
                --i;
            } else {
                outputArray[i] = instanceArray[i];
            }
        }
        rebuildInstanceList(outputArray);
        if (typeof formchangemanager !== 'undefined') {
            var form = jQuery('div#instanceList').closest('form')[0];
            formchangemanager.setFormState(form, FORM_CHANGED);
        }
    }

    function move_down(id) {
        instanceArray = document.getElementById('instancePriority').value.split(',');
        var outputArray = new Array();

        for(i = 0; i < instanceArray.length; i++) {
            if(instanceArray[i] == id) {
                outputArray[i+1] = instanceArray[i];
                outputArray[i] = instanceArray[i+1];
                ++i;
            } else {
                outputArray[i] = instanceArray[i];
            }
        }
        rebuildInstanceList(outputArray);
        if (typeof formchangemanager !== 'undefined') {
            var form = jQuery('div#instanceList').closest('form')[0];
            formchangemanager.setFormState(form, FORM_CHANGED);
        }
    }

    function rebuildInstanceList(outputArray) {
        var displayArray = new Array();
        var instanceListDiv = document.getElementById('instanceList');

        // Take each auth instance div, remove its span tag (containing arrow links) and clone it
        // adding the clone to the displayArray list
        for (i = 0; i < outputArray.length; i++) {
            var myDiv =  document.getElementById('instanceDiv' + outputArray[i]);
            replaceChildNodes(getFirstElementByTagAndClassName('span', 'authIcons', 'instanceDiv' + outputArray[i]));
            displayArray.push(myDiv.cloneNode(true));
        }

        emptyThisNode(instanceListDiv);

        for(i = 0; i < displayArray.length; i++) {
            if(displayArray.length > 1) {
                if (i + 1 != displayArray.length) {
                    getFirstElementByTagAndClassName('span', 'authIcons', displayArray[i]).innerHTML += '<a class="btn btn-link text-midtone" href="" onclick="move_down('+outputArray[i]+'); return false;"><span class="icon icon-long-arrow-down" role="presentation" aria-hidden="true"></span><span class="sr-only">'+get_string('moveitemdown')+'</span></a>'+"\n";
                }
                if(i != 0) {
                    getFirstElementByTagAndClassName('span', 'authIcons', displayArray[i]).innerHTML += '<a class="btn btn-link text-midtone" href="" onclick="move_up('+outputArray[i]+'); return false;"><span class="icon icon-long-arrow-up" role="presentation" aria-hidden="true"></span><span class="sr-only">'+get_string('moveitemup')+'</span></a>'+"\n";
                }
            }

            getFirstElementByTagAndClassName('span', 'authIcons', displayArray[i]).innerHTML += '<a class="btn btn-default btn-sm" href="" onclick="removeAuth('+outputArray[i]+'); return false;"><span class="icon icon-trash icon-lg text-danger" role="presentation" aria-hidden="true"></span><span class="sr-only">'+get_string('deleteitem')+'</span></a>'+"\n";

            instanceListDiv.appendChild(displayArray[i]);
        }
        document.getElementById('instancePriority').value = outputArray.join(',');
    }

    function arrayIze(id) {
        var thing = document.getElementById(id).value;
        if (thing == '') {
            return new Array();
        }
        return thing.split(',');
    }

    function removeAuth(id) {
        instanceArray = arrayIze('instancePriority');
        deleteArray   = arrayIze('deleteList');
        inuseArray   = arrayIze('institution_inuse');

        if (instanceArray.length == 1) {
            alert(<?php echo (isset($this->scope["cannotremove"]) ? $this->scope["cannotremove"] : null);?>);
            return false;
        }

        for(i = 0; i < inuseArray.length; i++) {
            if (id == inuseArray[i]) {
                alert(<?php echo (isset($this->scope["cannotremoveinuse"]) ? $this->scope["cannotremoveinuse"] : null);?>);
                return false;
            }
        }

        for(i = 0; i < instanceArray.length; i++) {
            if(instanceArray[i] == id) {
                instanceArray.splice(i, 1);
                deleteArray.push(id);
                jQuery('#instanceDiv' + id).remove();
            }
        }

        document.getElementById('deleteList').value = deleteArray.join(',');
        rebuildInstanceList(instanceArray);
        if (typeof formchangemanager !== 'undefined') {
            var form = jQuery('div#instanceList').closest('form')[0];
            formchangemanager.setFormState(form, FORM_CHANGED);
        }
    }

    function emptyThisNode(node) {
        while(node.hasChildNodes()) {
            node.removeChild(node.childNodes[0]);
        }
    }

    function requiresConfig(authname) {
        var requires_config = new Array();
        <?php 
$_fh0_data = (is_string($tmp=(isset($this->scope["authtypes"]) ? $this->scope["authtypes"] : null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);
if ($this->isTraversable($_fh0_data) == true)
{
	foreach ($_fh0_data as $this->scope['authtype'])
	{
/* -- foreach start output */
?>
            requires_config['<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'name',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["authtype"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>'] = <?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'requires_config',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["authtype"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>;
        <?php 
/* -- foreach end output */
	}
}?>


        return requires_config[authname];
    }

    function addinstance() {
        var selectedPlugin = document.getElementById('dummySelect').value;
        var institution = '<?php echo (is_string($tmp=$this->scope["institution"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>';
        if (institution.length == 0) {
            alert(<?php echo (isset($this->scope["saveinstitutiondetailsfirst"]) ? $this->scope["saveinstitutiondetailsfirst"] : null);?>);
            return false;
        }

        if (requiresConfig(selectedPlugin) == 1) {
            window.location = 'addauthority.php?add=1&i=<?php echo (is_string($tmp=$this->scope["institution"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>&p=' + selectedPlugin;
            return;
        }

        var authSelect = document.getElementById('dummySelect');
        for (var i=0; i < authSelect.length; i++) {
            if (authSelect.options[i].value == selectedPlugin) {
                authSelect.remove(i);
            }
        }

        sendjsonrequest('<?php echo (is_string($tmp=$this->scope["WWWROOT"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>admin/users/addauthority.php', {'i': '<?php echo (is_string($tmp=$this->scope["institution"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>', 'p': selectedPlugin, 'add': 1, 'j': 1 }, 'GET', function (data) { addAuthority(data.id, data.name, data.authname); });
        return false;
    }

    function editinstance(id, plugin) {
        if (requiresConfig(plugin)) {
            window.location = 'addauthority.php?id='+id+'&edit=1&i=<?php echo (is_string($tmp=$this->scope["institution"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>&p=' + plugin;
        } else {
            alert(<?php echo (isset($this->scope["noauthpluginconfigoptions"]) ? $this->scope["noauthpluginconfigoptions"] : null);?>);
        }
    }

    function addAuthority(id, name, authname) {
        var newDiv = '<div class="authInstance" id="instanceDiv'+id+'"> '+
            '<label class="authLabel"><a href="" onclick="editinstance('+id+',\''+authname+'\'); return false;">'+name+'</a></label> '+
            '<span class="authIcons" id="arrows'+id+'"></span> </div>';
        document.getElementById('instanceList').innerHTML += newDiv;
        if(document.getElementById('instancePriority').value.length) {
            instanceArray = document.getElementById('instancePriority').value.split(',');
        } else {
            instanceArray = new Array();
        }
        instanceArray.push(id);
        rebuildInstanceList(instanceArray);
        replaceChildNodes('messages');
    }

</script>
<div id="instanceList" class="listrow">
    <?php 
$_fh1_data = (is_string($tmp=(isset($this->scope["instancelist"]) ? $this->scope["instancelist"] : null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);
if ($this->isTraversable($_fh1_data) == true)
{
	foreach ($_fh1_data as $this->scope['instance'])
	{
/* -- foreach start output */
?>
    <div class="authInstance" id="instanceDiv<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["instance"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>">
        <label class="authLabel">
            <a href="" onclick="editinstance(<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["instance"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>,'<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'authname',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["instance"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>'); return false;">
            <?php echo Dwoo_Plugin_str($this, "title", "auth.".(is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'authname',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["instance"]) ? $this->scope["instance"]:null), true)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp)."", null, null, null, null, null);?></a>
        </label>
        <span class="authIcons" id="arrows<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["instance"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>">
            <?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'index',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["instance"]) ? $this->scope["instance"]:null), true)+1 < $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'total',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["instance"]) ? $this->scope["instance"]:null), true)) {
?>
            <a class="btn btn-link text-midtone" href="" onclick="move_down(<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["instance"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>); return false;">
                <span class="icon icon-long-arrow-down" role="presentation" aria-hidden="true"></span>
                <span class="sr-only"><?php echo Dwoo_Plugin_str($this, 'moveitemdown', 'mahara', null, null, null, null, null);?></span>
            </a>
            <?php 
}?>

            <?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'index',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["instance"]) ? $this->scope["instance"]:null), true) != 0) {
?>
            <a class="btn btn-link text-midtone" href="" onclick="move_up(<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["instance"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>); return false;">
                <span class="icon icon-long-arrow-up" role="presentation" aria-hidden="true"></span>
                <span class="sr-only"><?php echo Dwoo_Plugin_str($this, 'moveitemup', 'mahara', null, null, null, null, null);?></span>
            </a>
            <?php 
}?>

            <a href="" class="btn btn-default btn-sm" onclick="removeAuth(<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["instance"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>); return false;">
                <span class="icon icon-trash icon-lg text-danger" role="presentation" aria-hidden="true"></span>
                <span class="sr-only"><?php echo Dwoo_Plugin_str($this, 'deleteitem', 'mahara', null, null, null, null, null);?></span>
            </a>
        </span>
    </div>
    <?php 
/* -- foreach end output */
	}
}?>

</div>
<div class="select">
    <span class="picker">
        <select class="select form-control" name="dummy" id="dummySelect">
        <?php 
$_fh2_data = (is_string($tmp=(isset($this->scope["authtypes"]) ? $this->scope["authtypes"] : null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);
if ($this->isTraversable($_fh2_data) == true)
{
	foreach ($_fh2_data as $this->scope['authtype'])
	{
/* -- foreach start output */
?>
            <option value="<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'name',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["authtype"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>"<?php if (! $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'is_usable',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["authtype"]) ? $this->scope["authtype"]:null), true)) {
?> disabled="disabled"<?php 
}?>><?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'title',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["authtype"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?> - <?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'description',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["authtype"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?></option>
        <?php 
/* -- foreach end output */
	}
}?>

        </select>
    </span>
    <button class="btn btn-primary" type="button" onclick="addinstance(); return false;" name="button" value="foo"><?php echo Dwoo_Plugin_str($this, 'Add', 'admin', null, null, null, null, null);?></button>
</div>

<input type="hidden" id="instancePriority" name="instancePriority" value="<?php echo (is_string($tmp=$this->scope["instancestring"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>" />
<input type="hidden" id="deleteList" name="deleteList" value="" />
<?php  /* end template body */
return $this->buffer . ob_get_clean();
?>