<?php
/* template head */
if (function_exists('Dwoo_Plugin_str')===false)
	$this->getLoader()->loadPlugin('str');
/* end template head */ ob_start(); /* template body */ ;
if (! (isset($this->scope["editing"]) ? $this->scope["editing"] : null)) {
?>
    <div class="comments pull-left">
        <?php if ((isset($this->scope["commentcount"]) ? $this->scope["commentcount"] : null) > 0) {
?>
        <a class="commentlink link-blocktype" id="block_<?php echo (is_string($tmp=$this->scope["blockid"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>" data-toggle="modal-docked" data-target="#feedbacktable_<?php echo (is_string($tmp=$this->scope["blockid"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>" href="#">
            <span class="icon icon-comments" role="presentation" aria-hidden="true"></span>
            <?php echo Dwoo_Plugin_str($this, 'Comments', 'artefact.comment', null, null, null, null, null);?> (<?php echo (is_string($tmp=$this->scope["commentcount"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>)
        </a>
        <?php 
}?>

        <?php if ((isset($this->scope["allowcomments"]) ? $this->scope["allowcomments"] : null)) {
?>
            <a class="addcomment link-blocktype" href="<?php echo (is_string($tmp=$this->scope["artefacturl"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>">
                <span class="icon icon-arrow-circle-right" role="presentation" aria-hidden="true"></span>
                <?php echo Dwoo_Plugin_str($this, 'addcomment', 'artefact.comment', null, null, null, null, null);?>

            </a>
        <?php 
}?>

    </div>

    <div class="feedback modal modal-docked" id="feedbacktable_<?php echo (is_string($tmp=$this->scope["blockid"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header clearfix">
                    <button class="deletebutton close" data-dismiss="modal-docked">
                        <span class="times">&times;</span>
                        <span class="sr-only"><?php echo Dwoo_Plugin_str($this, 'Close', 'mahara', null, null, null, null, null);?></span>
                    </button>
                    <h4 class="modal-title pull-left">
                        <span class="icon icon-lg icon-comments left" role="presentation" aria-hidden="true"></span>
                        <?php echo Dwoo_Plugin_str($this, 'Comments', 'artefact.comment', null, null, null, null, null);?> - <?php echo (is_string($tmp=$this->scope["artefacttitle"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>

                    </h4>
                    <?php if ((isset($this->scope["allowcomments"]) ? $this->scope["allowcomments"] : null)) {
?>
                    <a class="addcomment pull-right" href="<?php echo (is_string($tmp=$this->scope["artefacturl"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>">
                        <?php echo Dwoo_Plugin_str($this, 'addcomment', 'artefact.comment', null, null, null, null, null);?>

                        <span class="icon icon-arrow-right right" role="presentation" aria-hidden="true"></span>
                    </a>
                    <?php 
}?>

                </div>
                <div class="modal-body flush">
                <?php echo $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'tablerows',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["comments"]) ? $this->scope["comments"]:null), true);?>

                </div>
            </div>
        </div>
    </div>
<?php 
}?>

<?php  /* end template body */
return $this->buffer . ob_get_clean();
?>