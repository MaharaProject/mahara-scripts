<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ;
$this->scope["time"]=$this->readVar("r.".(is_string($tmp=(isset($this->scope["f"]) ? $this->scope["f"] : null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp))?>

<?php if ((isset($this->scope["time"]) ? $this->scope["time"] : null)) {
?>
<?php echo format_date(strtotime((is_string($tmp=(isset($this->scope["time"]) ? $this->scope["time"] : null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp)), 'strftimedatetime');?>

<?php 
}?>

<?php  /* end template body */
return $this->buffer . ob_get_clean();
?>