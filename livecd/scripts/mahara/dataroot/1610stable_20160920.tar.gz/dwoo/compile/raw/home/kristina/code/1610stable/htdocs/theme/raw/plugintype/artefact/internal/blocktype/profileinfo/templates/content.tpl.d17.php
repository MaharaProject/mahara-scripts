<?php
/* template head */
if (function_exists('Dwoo_Plugin_str')===false)
	$this->getLoader()->loadPlugin('str');
/* end template head */ ob_start(); /* template body */ ?><div class="panel-body flush">
<?php if ((isset($this->scope["profileiconpath"]) ? $this->scope["profileiconpath"] : null)) {
?>
    <div class="user-icon pull-right">
        <img src="<?php echo (is_string($tmp=$this->scope["profileiconpath"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>" alt="<?php echo (is_string($tmp=$this->scope["profileiconalt"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>" />
    </div>
<?php 
}?>


<?php if ((isset($this->scope["profileinfo"]) ? $this->scope["profileinfo"] : null) && (isset($this->scope["profileinfo"]["introduction"]) ? $this->scope["profileinfo"]["introduction"]:null)) {
?>
    <?php echo clean_html((isset($this->scope["profileinfo"]["introduction"]) ? $this->scope["profileinfo"]["introduction"]:null));?>

<?php 
}?>

<?php if ((isset($this->scope["profileinfo"]) ? $this->scope["profileinfo"] : null) && ( count((is_string($tmp=(isset($this->scope["profileinfo"]) ? $this->scope["profileinfo"] : null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp)) != 1 || ! (isset($this->scope["profileinfo"]["introduction"]) ? $this->scope["profileinfo"]["introduction"]:null) || ! (isset($this->scope["profileinfo"]["socialprofiles"]) ? $this->scope["profileinfo"]["socialprofiles"]:null) )) {
?>
    <ul class="unstyled profile-info">
        <?php 
$_fh0_data = (is_string($tmp=(isset($this->scope["profileinfo"]) ? $this->scope["profileinfo"] : null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);
if ($this->isTraversable($_fh0_data) == true)
{
	foreach ($_fh0_data as $this->scope['key']=>$this->scope['item'])
	{
/* -- foreach start output */
?>
            <?php if (! in_array((is_string($tmp=(isset($this->scope["key"]) ? $this->scope["key"] : null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp), array(0=>'introduction', 1=>'socialprofiles'))) {
?>
                <li><strong><?php echo Dwoo_Plugin_str($this, (is_string($tmp=(isset($this->scope["key"]) ? $this->scope["key"] : null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp), 'artefact.internal', null, null, null, null, null);?>:</strong> <?php echo clean_html((isset($this->scope["item"]) ? $this->scope["item"] : null));?></li>
            <?php 
}?>

        <?php 
/* -- foreach end output */
	}
}?>

    </ul>
<?php 
}?>


<?php if ((isset($this->scope["profileinfo"]["socialprofiles"]) ? $this->scope["profileinfo"]["socialprofiles"]:null)) {
?>
    <h4 class="sr-only"><?php echo Dwoo_Plugin_str($this, 'socialprofiles', 'artefact.internal', null, null, null, null, null);?></h4>
    <ul class="unstyled profile-info">
        <?php 
$_fh1_data = (is_string($tmp=(isset($this->scope["profileinfo"]["socialprofiles"]) ? $this->scope["profileinfo"]["socialprofiles"]:null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);
if ($this->isTraversable($_fh1_data) == true)
{
	foreach ($_fh1_data as $this->scope['item'])
	{
/* -- foreach start output */
?>
            <li><strong><?php echo (is_string($tmp=$this->scope["item"]["description"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>:</strong>
                <?php if ((isset($this->scope["item"]["link"]) ? $this->scope["item"]["link"]:null)) {
?><a href="<?php echo (is_string($tmp=$this->scope["item"]["link"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>" title="<?php echo (is_string($tmp=$this->scope["item"]["link"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>"><?php 
}
echo clean_html((isset($this->scope["item"]["title"]) ? $this->scope["item"]["title"]:null));
if ((isset($this->scope["item"]["link"]) ? $this->scope["item"]["link"]:null)) {
?></a><?php 
}?>

            </li>
        <?php 
/* -- foreach end output */
	}
}?>

    </ul>
<?php 
}?>


</div>
<?php  /* end template body */
return $this->buffer . ob_get_clean();
?>