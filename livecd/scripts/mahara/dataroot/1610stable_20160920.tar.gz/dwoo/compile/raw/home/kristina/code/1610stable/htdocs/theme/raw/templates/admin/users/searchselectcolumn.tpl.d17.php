<?php
/* template head */
if (function_exists('Dwoo_Plugin_str')===false)
	$this->getLoader()->loadPlugin('str');
/* end template head */ ob_start(); /* template body */ ?><label class="accessible-hidden sr-only" for="selectusers_<?php echo (is_string($tmp=$this->scope["r"]["id"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>"><?php echo Dwoo_Plugin_str($this, 'selectuser', 'admin', null, "".(is_string($tmp=(isset($this->scope["r"]["firstname"]) ? $this->scope["r"]["firstname"]:null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp)." ".(is_string($tmp=(isset($this->scope["r"]["lastname"]) ? $this->scope["r"]["lastname"]:null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp)."", null, null, null);?></label>
<input name="selectusers" class="selectusers" type="checkbox" id="selectusers_<?php echo (is_string($tmp=$this->scope["r"]["id"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>" value="<?php echo (is_string($tmp=$this->scope["r"]["id"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>">
<?php  /* end template body */
return $this->buffer . ob_get_clean();
?>