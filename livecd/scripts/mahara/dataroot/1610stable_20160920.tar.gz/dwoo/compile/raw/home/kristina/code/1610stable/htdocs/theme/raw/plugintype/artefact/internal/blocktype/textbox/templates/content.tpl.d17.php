<?php
/* template head */
if (function_exists('Dwoo_Plugin_str')===false)
	$this->getLoader()->loadPlugin('str');
if (function_exists('Dwoo_Plugin_list_tags')===false)
	$this->getLoader()->loadPlugin('list_tags');
/* end template head */ ob_start(); /* template body */ ?><div class="panel-body flush">
    <?php echo clean_html((isset($this->scope["text"]) ? $this->scope["text"] : null));?>


    <?php if ((($tmp = (isset($this->scope["artefact"]) ? $this->scope["artefact"] : null)) ? $tmp->get('tags') : null)) {
?>
    <div class="tags">
        <strong><?php echo Dwoo_Plugin_str($this, 'tags', 'mahara', null, null, null, null, null);?>:</strong> <?php echo Dwoo_Plugin_list_tags($this, (is_string($tmp=(($tmp = (isset($this->scope["artefact"]) ? $this->scope["artefact"] : null)) ? $tmp->get('tags') : null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp), (is_string($tmp=(($tmp = (isset($this->scope["artefact"]) ? $this->scope["artefact"] : null)) ? $tmp->get('owner') : null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp));?>

    </div>
    <?php 
}?>

</div>

<?php if ((isset($this->scope["attachments"]) ? $this->scope["attachments"] : null)) {
?>
<div class="has-attachment panel panel-default collapsible">
    <h4 class="panel-heading">
        <a class="text-left collapsed" aria-expanded="false" href="#note-attach-<?php echo (is_string($tmp=$this->scope["blockid"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>" data-toggle="collapse">
            <span class="icon icon-paperclip left" role="presentation" aria-hidden="true"></span>

            <span class="text-small"><?php echo Dwoo_Plugin_str($this, 'attachedfiles', 'artefact.blog', null, null, null, null, null);?></span>
            <span class="metadata">(<?php echo (is_string($tmp=$this->scope["count"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>)</span>
            <span class="icon icon-chevron-down pull-right collapse-indicator" role="presentation" aria-hidden="true"></span>
        </a>
    </h4>
    <div id="note-attach-<?php echo (is_string($tmp=$this->scope["blockid"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>" class="collapse">
        <ul class="list-unstyled list-group">
            <?php 
$_fh2_data = (is_string($tmp=(isset($this->scope["attachments"]) ? $this->scope["attachments"] : null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);
if ($this->isTraversable($_fh2_data) == true)
{
	foreach ($_fh2_data as $this->scope['item'])
	{
/* -- foreach start output */
?>
            <li class="list-group-item">
                <a href="<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'downloadpath',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["item"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>" class="outer-link icon-on-hover">
                    <span class="sr-only">
                        <?php echo Dwoo_Plugin_str($this, 'Download', 'artefact.file', null, null, null, null, null);?> <?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'title',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["item"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>

                    </span>
                </a>
                <?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'iconpath',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["item"]) ? $this->scope["item"]:null), true)) {
?>
                <img class="file-icon" src="<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'iconpath',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["item"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>" alt="">
                <?php 
}
else {
?>
                <span class="icon icon-<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'artefacttype',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["item"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?> left icon-lg text-default" role="presentation" aria-hidden="true"></span>
                <?php 
}?>


                <span class="title list-group-item-heading text-inline">
                    <a href="<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'viewpath',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["item"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>" class="inner-link">
                        <?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'title',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["item"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>

                    </a>
                    <span class="metadata"> -
                        [<?php echo display_size((is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'size',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["item"]) ? $this->scope["item"]:null), true)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp));?>]
                    </span>
                </span>
                <span class="icon icon-download icon-lg pull-right text-watermark icon-action" role="presentation" aria-hidden="true"></span>
            </li>
            <?php 
/* -- foreach end output */
	}
}?>

        </ul>
    </div>
</div>
<?php 
}?>


<?php echo (isset($this->scope["comments"]) ? $this->scope["comments"] : null);?>

<?php  /* end template body */
return $this->buffer . ob_get_clean();
?>