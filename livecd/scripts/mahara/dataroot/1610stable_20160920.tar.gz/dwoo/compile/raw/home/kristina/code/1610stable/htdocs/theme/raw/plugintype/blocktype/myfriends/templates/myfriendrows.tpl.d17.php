<?php
/* template head */
if (class_exists('Dwoo_Plugin_cycle', false)===false)
	$this->getLoader()->loadPlugin('cycle');
if (function_exists('Dwoo_Plugin_profile_icon_url')===false)
	$this->getLoader()->loadPlugin('profile_icon_url');
if (function_exists('Dwoo_Plugin_display_default_name')===false)
	$this->getLoader()->loadPlugin('display_default_name');
if (function_exists('Dwoo_Plugin_str')===false)
	$this->getLoader()->loadPlugin('str');
if (function_exists('Dwoo_Plugin_escape')===false)
	$this->getLoader()->loadPlugin('escape');
/* end template head */ ob_start(); /* template body */ ?><div class="js-masonry user-thumbnails">
<?php 
$_fh4_data = (is_string($tmp=(isset($this->scope["friends"]) ? $this->scope["friends"] : null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);
if ($this->isTraversable($_fh4_data) == true)
{
	foreach ($_fh4_data as $this->scope['row'])
	{
/* -- foreach start output */
?>
    <?php 
$_fh3_data = (is_string($tmp=(isset($this->scope["row"]) ? $this->scope["row"] : null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);
if ($this->isTraversable($_fh3_data) == true)
{
	foreach ($_fh3_data as $this->scope['friend'])
	{
/* -- foreach start output */
?>
        <a href="<?php echo profile_url((is_string($tmp=(isset($this->scope["friend"]) ? $this->scope["friend"] : null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp));?>" class="item user-icon metadata user-icon-larger <?php echo $this->classCall('cycle', array('default', 'd0,d1', true, true, ',', null, false));?>">
            <img src="<?php echo Dwoo_Plugin_profile_icon_url($this, (is_string($tmp=(isset($this->scope["friend"]) ? $this->scope["friend"] : null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp), 100, 100);?>" alt="<?php echo Dwoo_Plugin_str($this, 'profileimagetext', 'mahara', null, Dwoo_Plugin_display_default_name($this, (is_string($tmp=(isset($this->scope["friend"]) ? $this->scope["friend"] : null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp)), null, null, null);?>" with="100" height="100">
            <p class="member-name"><?php echo Dwoo_Plugin_escape($this, Dwoo_Plugin_display_default_name($this, (is_string($tmp=(isset($this->scope["friend"]) ? $this->scope["friend"] : null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp)), 'html', null);?></p>
        </a>
    <?php 
/* -- foreach end output */
	}
}?>

<?php 
/* -- foreach end output */
	}
}?>

</div>

<?php  /* end template body */
return $this->buffer . ob_get_clean();
?>