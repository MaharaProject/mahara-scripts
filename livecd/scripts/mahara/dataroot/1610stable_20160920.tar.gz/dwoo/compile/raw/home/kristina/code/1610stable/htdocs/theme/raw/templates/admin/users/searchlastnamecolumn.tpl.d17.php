<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><a href="<?php echo (is_string($tmp=$this->scope["WWWROOT"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>user/view.php?id=<?php echo (is_string($tmp=$this->scope["r"]["id"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>"><?php echo (is_string($tmp=$this->scope["r"]["lastname"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?></a>
<?php  /* end template body */
return $this->buffer . ob_get_clean();
?>