<?php
/* template head */
if (function_exists('Dwoo_Plugin_str')===false)
	$this->getLoader()->loadPlugin('str');
/* end template head */ ob_start(); /* template body */ ;
if (( (isset($this->scope["editing"]) ? $this->scope["editing"] : null) )) {
?>
    <?php if (( count((is_string($tmp=(isset($this->scope["blogs"]) ? $this->scope["blogs"] : null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp)) == 1 )) {
?>
        <a class="panel-footer <?php if (( count((is_string($tmp=(isset($this->scope["blogs"]) ? $this->scope["blogs"] : null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp)) != 1 )) {
?> hidden<?php 
}?>">
            <span id="blog_<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',    2 => '',  ),), $this->scope["blogs"]["0"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>" class="icon icon-plus left" role="presentation" aria-hidden="true"></span>
            <?php echo Dwoo_Plugin_str($this, 'shortcutnewentry', 'artefact.blog', null, null, null, null, null);?>

        </a>
    <?php 
}
else {
?>
    <div class="panel-footer">
        <label class="text" for="blogselect_<?php echo (is_string($tmp=$this->scope["blockid"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>"><?php echo Dwoo_Plugin_str($this, 'shortcutaddpost', 'artefact.blog', null, null, null, null, null);?></label>
        <div class="input-group">

            <select id="blogselect_<?php echo (is_string($tmp=$this->scope["blockid"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>" class="select form-control">
            <?php 
$_fh3_data = (is_string($tmp=(isset($this->scope["blogs"]) ? $this->scope["blogs"] : null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);
if ($this->isTraversable($_fh3_data) == true)
{
	foreach ($_fh3_data as $this->scope['blog'])
	{
/* -- foreach start output */
?>
                <option value="<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["blog"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>"> <?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'title',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["blog"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?> </option>
            <?php 
/* -- foreach end output */
	}
}?>

            </select>
            <span class="input-group-btn">
                <a class="btn btn-default btnshortcut">
                    <span class="icon icon-plus text-success left" role="presentation" aria-hidden="true"></span> <?php echo Dwoo_Plugin_str($this, 'shortcutadd', 'artefact.blog', null, null, null, null, null);?>

                </a>
            </span>
        </div>
    </div>
    <?php 
}?>

<?php 
}?>

<div class="recentblogpost list-group">
<?php 
$_fh4_data = (is_string($tmp=(isset($this->scope["mostrecent"]) ? $this->scope["mostrecent"] : null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);
if ($this->isTraversable($_fh4_data) == true)
{
	foreach ($_fh4_data as $this->scope['post'])
	{
/* -- foreach start output */
?>
    <div class="list-group-item">
        <a href="<?php echo (is_string($tmp=$this->scope["WWWROOT"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>artefact/artefact.php?artefact=<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["post"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>&amp;view=<?php echo (is_string($tmp=$this->scope["view"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>" class="outer-link">
            <span class="sr-only"><?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'title',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["post"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?></span>
        </a>
        <h4 class="list-group-item-heading text-inline">
            <?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'title',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["post"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>

        </h4>
        <span class="text-small">
            <?php echo Dwoo_Plugin_str($this, 'postedin', 'blocktype.blog/recentposts', null, null, null, null, null);?>

            <a href="<?php echo (is_string($tmp=$this->scope["WWWROOT"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>artefact/artefact.php?artefact=<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'parent',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["post"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>&amp;view=<?php echo (is_string($tmp=$this->scope["view"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>" class="inner-link">
                <?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'parenttitle',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["post"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>

            </a>
        </span>
        <span class="metadata">
            <?php echo Dwoo_Plugin_str($this, 'postedon', 'blocktype.blog/recentposts', null, null, null, null, null);?>

            <?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'displaydate',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["post"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>

        </span>
    </div>
<?php 
/* -- foreach end output */
	}
}?>

</div>
<?php  /* end template body */
return $this->buffer . ob_get_clean();
?>