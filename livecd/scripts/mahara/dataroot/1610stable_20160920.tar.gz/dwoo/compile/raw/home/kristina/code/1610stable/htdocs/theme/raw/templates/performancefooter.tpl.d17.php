<?php
/* template head */
if (function_exists('Dwoo_Plugin_str')===false)
	$this->getLoader()->loadPlugin('str');
/* end template head */ ob_start(); /* template body */ ?><div id="performance-info" class="footer-performance-info">
    <?php if ((isset($this->scope["perf_memory_total"]) ? $this->scope["perf_memory_total"] : null)) {
?>
    <span id="memoryused">
        <?php echo Dwoo_Plugin_str($this, "memoryused", "performance", null, null, null, null, null);?>: <?php echo (is_string($tmp=$this->scope["perf_memory_total_display"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>

    </span> |
    <?php 
}?>

    <?php if ((isset($this->scope["perf_realtime"]) ? $this->scope["perf_realtime"] : null)) {
?>
    <span id="timeused">
        <?php echo Dwoo_Plugin_str($this, "timeused", "performance", null, null, null, null, null);?>: <?php echo number_format((is_string($tmp=(isset($this->scope["perf_realtime"]) ? $this->scope["perf_realtime"] : null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp), 3);?> <?php echo Dwoo_Plugin_str($this, "seconds", "performance", null, null, null, null, null);?>

    </span> |
    <?php 
}?>

    <?php if ((isset($this->scope["perf_includecount"]) ? $this->scope["perf_includecount"] : null)) {
?>
    <span id="included">
        <?php echo Dwoo_Plugin_str($this, "included", "performance", null, null, null, null, null);?>: <?php echo (is_string($tmp=$this->scope["perf_includecount"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>

    </span> |
    <?php 
}?>

    <?php if ((isset($this->scope["perf_dbreads"]) ? $this->scope["perf_dbreads"] : null) || (isset($this->scope["perf_dbwrites"]) ? $this->scope["perf_dbwrites"] : null) || (isset($this->scope["perf_dbcached"]) ? $this->scope["perf_dbcached"] : null)) {
?>
    <span id="dbqueries">
        <?php echo Dwoo_Plugin_str($this, "dbqueries", "performance", null, null, null, null, null);?>: <?php echo (is_string($tmp=$this->scope["perf_dbreads"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?> <?php echo Dwoo_Plugin_str($this, 'reads', 'performance', null, null, null, null, null);?>, <?php echo (is_string($tmp=$this->scope["perf_dbwrites"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?> <?php echo Dwoo_Plugin_str($this, 'writes', 'performance', null, null, null, null, null);?>, <?php echo (is_string($tmp=$this->scope["perf_dbcached"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?> <?php echo Dwoo_Plugin_str($this, 'cached', 'performance', null, null, null, null, null);?>

    </span> |
    <?php 
}?>

    <?php if ((isset($this->scope["perf_ticks"]) ? $this->scope["perf_ticks"] : null)) {
?>
    <span id="posixtimes">
        <?php echo Dwoo_Plugin_str($this, "ticks", "performance", null, null, null, null, null);?>: <?php echo (is_string($tmp=$this->scope["perf_ticks"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?> <?php echo Dwoo_Plugin_str($this, "user", "performance", null, null, null, null, null);?>: <?php echo (is_string($tmp=$this->scope["perf_utime"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>

        <?php echo Dwoo_Plugin_str($this, "sys", "performance", null, null, null, null, null);?>: <?php echo (is_string($tmp=$this->scope["perf_stime"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?> <?php echo Dwoo_Plugin_str($this, "cuser", "performance", null, null, null, null, null);?>: <?php echo (is_string($tmp=$this->scope["perf_cutime"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>

        <?php echo Dwoo_Plugin_str($this, "csys", "performance", null, null, null, null, null);?>: <?php echo (is_string($tmp=$this->scope["perf_cstime"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>

    </span> |
        <?php 
}?>

    <?php if ((isset($this->scope["perf_serverload"]) ? $this->scope["perf_serverload"] : null)) {
?>
    <span id="serverload"><?php echo Dwoo_Plugin_str($this, "serverload", "performance", null, null, null, null, null);?>: <?php echo (is_string($tmp=$this->scope["perf_serverload"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?></span>
    <?php 
}?>

</div>

<?php  /* end template body */
return $this->buffer . ob_get_clean();
?>