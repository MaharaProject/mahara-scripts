<?php
/* template head */
if (function_exists('Dwoo_Plugin_str')===false)
	$this->getLoader()->loadPlugin('str');
if (function_exists('Dwoo_Plugin_escape')===false)
	$this->getLoader()->loadPlugin('escape');
if (function_exists('Dwoo_Plugin_list_tags')===false)
	$this->getLoader()->loadPlugin('list_tags');
if (function_exists('Dwoo_Plugin_truncate')===false)
	$this->getLoader()->loadPlugin('truncate');
/* end template head */ ob_start(); /* template body */ ;

$_fh1_data = (is_string($tmp=(isset($this->scope["posts"]) ? $this->scope["posts"] : null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);
if ($this->isTraversable($_fh1_data) == true)
{
	foreach ($_fh1_data as $this->scope['post'])
	{
/* -- foreach start output */
?>
    <div id="posttitle_<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["post"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>" class="<?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'published',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["post"]) ? $this->scope["post"]:null), true)) {
?> published<?php 
}
else {
?> draft<?php 
}?> list-group-item">
        <div class="post-heading">
            <h2 class="list-group-item-heading">
                <?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'title',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["post"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>

            </h2>

            <div class="list-group-item-controls">
                <span id="poststatus<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["post"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>" class="poststatus text-inline">
                    <?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'published',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["post"]) ? $this->scope["post"]:null), true)) {
?>
                        <?php echo Dwoo_Plugin_str($this, 'published', 'artefact.blog', null, null, null, null, null);?>

                    <?php 
}
else {
?>
                        <?php echo Dwoo_Plugin_str($this, 'draft', 'artefact.blog', null, null, null, null, null);?>

                    <?php 
}?>

                </span>

                <?php if (! $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'locked',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["post"]) ? $this->scope["post"]:null), true)) {
?>
                <span id="changepoststatus<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["post"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>" class="changepoststatus text-inline">
                    <?php echo $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'changepoststatus',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["post"]) ? $this->scope["post"]:null), true);?>

                </span>
                <?php 
}?>


                <?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'locked',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["post"]) ? $this->scope["post"]:null), true)) {
?>
                <span class="locked-post text-muted">
                    <span class="icon icon-lock left" role="presentation" aria-hidden="true"></span>
                    <?php echo Dwoo_Plugin_str($this, 'submittedforassessment', 'view', null, null, null, null, null);?>

                </span>
                <?php 
}
else {
?>
                <div class="btn-group postcontrols">
                    <form name="edit_<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["post"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>" action="<?php echo (is_string($tmp=$this->scope["WWWROOT"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>artefact/blog/post.php" class="form-as-button pull-left">
                        <input type="hidden" name="id" value="<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["post"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>">
                        <button type="submit" class="submit btn btn-default btn-sm" title="<?php echo Dwoo_Plugin_escape($this, Dwoo_Plugin_str($this, 'edit', 'mahara', null, null, null, null, null), 'html', null);?>">
                            <span class="icon icon-pencil icon-lg" role="presentation" aria-hidden="true"></span>
                            <span class="sr-only"><?php echo Dwoo_Plugin_escape($this, Dwoo_Plugin_str($this, 'edit', 'mahara', null, null, null, null, null), 'html', null);?></span>
                        </button>
                    </form>
                    <?php echo $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'delete',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["post"]) ? $this->scope["post"]:null), true);?>

                </div>
                <?php 
}?>

            </div>
        </div>
        <div id="postdetails_<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["post"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>" class="postdetails postdate">
            <span class="icon icon-calendar left" role="presentation" aria-hidden="true"></span>
            <strong>
                <?php echo Dwoo_Plugin_str($this, 'postedon', 'artefact.blog', null, null, null, null, null);?>:
            </strong>
            <?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'ctime',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["post"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>


            <?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'tags',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["post"]) ? $this->scope["post"]:null), true)) {
?>
            <p id="posttags_<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["post"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>" class="tags">
                <span class="icon icon-tags left" role="presentation" aria-hidden="true"></span>
                <strong><?php echo Dwoo_Plugin_str($this, 'tags', 'mahara', null, null, null, null, null);?>:</strong>
                <?php echo Dwoo_Plugin_list_tags($this, (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'tags',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["post"]) ? $this->scope["post"]:null), true)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp), (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'author',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["post"]) ? $this->scope["post"]:null), true)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp));?>

            </p>
            <?php 
}?>

        </div>
        <p id="postdescription_<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["post"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>" class="postdescription">
            <?php echo clean_html($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'description',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["post"]) ? $this->scope["post"]:null), true));?>

        </p>

        <?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'files',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["post"]) ? $this->scope["post"]:null), true)) {
?>
        <div class="has-attachment panel panel-default collapsible" id="postfiles_<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["post"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>">
            <h5 class="panel-heading">
                <a class="text-left collapsed" data-toggle="collapse" href="#attach_<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["post"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>" aria-expanded="false">
                    <span class="icon left icon-paperclip" role="presentation" aria-hidden="true"></span>
                    <span class="text-small"> <?php echo Dwoo_Plugin_str($this, 'attachedfiles', 'artefact.blog', null, null, null, null, null);?> </span>
                     <span class="metadata">
                        (<?php echo count((is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'files',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["post"]) ? $this->scope["post"]:null), true)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp));?>)
                    </span>
                    <span class="icon icon-chevron-down collapse-indicator pull-right" role="presentation" aria-hidden="true"></span>
                </a>
            </h5>
            <div class="collapse" id="attach_<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["post"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>">
                <ul class="list-group list-unstyled">
                <?php 
$_fh0_data = (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'files',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["post"]) ? $this->scope["post"]:null), true)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);
if ($this->isTraversable($_fh0_data) == true)
{
	foreach ($_fh0_data as $this->scope['file'])
	{
/* -- foreach start output */
?>
                    <li class="list-group-item-link">
                        <a href="<?php echo (is_string($tmp=$this->scope["WWWROOT"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>artefact/file/download.php?file=<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'attachment',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["file"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>" <?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'description',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["file"]) ? $this->scope["file"]:null), true)) {
?> title="<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'description',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["file"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>" data-toggle="tooltip"<?php 
}?>>
                            <?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'icon',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["file"]) ? $this->scope["file"]:null), true)) {
?>
                            <img src="<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'icon',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["file"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>" alt="" class="file-icon">
                            <?php 
}
else {
?>
                            <span class="icon icon-<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'artefacttype',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["file"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?> icon-lg text-default left" role="presentation" aria-hidden="true"></span>
                            <?php 
}?>

                            <span class="file-title"><?php echo Dwoo_Plugin_truncate($this, (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'title',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["file"]) ? $this->scope["file"]:null), true)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp), 40, '...', false, false, 'UTF-8');?></span>
                            <span class="file-size">
                            (<?php echo display_size((is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'size',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["file"]) ? $this->scope["file"]:null), true)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp));?>)
                            </span>
                        </a>
                    </li>
                <?php 
/* -- foreach end output */
	}
}?>

                </ul>
            </div>
        </div>
        <?php 
}?>

    </div>
<?php 
/* -- foreach end output */
	}
}?>

<?php  /* end template body */
return $this->buffer . ob_get_clean();
?>