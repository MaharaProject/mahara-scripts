<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><div id="<?php echo (is_string($tmp=$this->scope["id"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>-container" data-rating="<?php echo (is_string($tmp=$this->scope["value"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>"><?php if (! (isset($this->scope["readonly"]) ? $this->scope["readonly"] : null)) {
?><input type=hidden name="rating" id="<?php echo (is_string($tmp=$this->scope["id"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>"><?php 
}?></div>

<script type="application/javascript">
jQuery(document).ready(function() {
    jQuery("#<?php echo (is_string($tmp=$this->scope["id"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>-container").rating('create', {
        coloron:'<?php echo (is_string($tmp=$this->scope["colouron"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>',
        coloroff:'<?php echo (is_string($tmp=$this->scope["colouroff"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>',
        glyph:'icon-<?php echo (is_string($tmp=$this->scope["icon"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>',
        offglyph:'icon-<?php echo (is_string($tmp=$this->scope["officon"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>',
        emptyglyph: <?php echo (is_string($tmp=$this->scope["iconempty"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>,
        limit: <?php echo (is_string($tmp=$this->scope["limit"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>,
        <?php if ((isset($this->scope["onclick"]) ? $this->scope["onclick"] : null)) {
?>
            onClick: <?php echo (is_string($tmp=$this->scope["onclick"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>,
        <?php 
}?>

        <?php if ((isset($this->scope["readonly"]) ? $this->scope["readonly"] : null)) {
?>
            readonly: true,
        <?php 
}?>

    });
});
</script>
<?php  /* end template body */
return $this->buffer . ob_get_clean();
?>