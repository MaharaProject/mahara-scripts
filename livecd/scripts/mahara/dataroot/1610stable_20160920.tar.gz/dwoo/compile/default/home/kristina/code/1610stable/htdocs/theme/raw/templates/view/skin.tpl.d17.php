<?php
/* template head */
if (function_exists('Dwoo_Plugin_include')===false)
	$this->getLoader()->loadPlugin('include');
if (function_exists('Dwoo_Plugin_str')===false)
	$this->getLoader()->loadPlugin('str');
/* end template head */ ob_start(); /* template body */ ;
echo Dwoo_Plugin_include($this, "header.tpl", null, null, null, '_root', null);?>


<a class="btn btn-lg btn-default btn-with-heading" href="<?php echo (is_string($tmp=$this->scope["WWWROOT"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>skin/index.php">
    <span class="icon icon-magic icon-flip-horizontal icon-lg left" role="presentation" aria-hidden="true"></span>
    <?php echo Dwoo_Plugin_str($this, 'manageskins', 'skin', null, null, null, null, null);?>

</a>

<?php echo Dwoo_Plugin_include($this, "view/editviewtabs.tpl", null, null, null, '_root', null, array('selected' => 'skin', 'new' => (is_string($tmp=(isset($this->scope["new"]) ? $this->scope["new"] : null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp), 'issiteview' => (is_string($tmp=(isset($this->scope["issiteview"]) ? $this->scope["issiteview"] : null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp)));?>


<div class="subpage">
    <?php if (! (isset($this->scope["saved"]) ? $this->scope["saved"] : null)) {
?>
    <div class="alert alert-warning">
        <span class="icon icon-lg icon-exclamation-triangle left" role="presentation" aria-hidden="true"></span>
        <?php echo Dwoo_Plugin_str($this, 'notsavedyet', 'skin', null, null, null, null, null);?>

    </div>
    <?php 
}?>


    <?php if ((isset($this->scope["incompatible"]) ? $this->scope["incompatible"] : null)) {
?>
    <div class="alert alert-danger">
        <span class="icon icon-ban" role="presentation" aria-hidden="true"></span>
        <?php echo (is_string($tmp=$this->scope["incompatible"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>

    </div>
    <?php 
}?>


    <div class="row view-container">
        <div class="col-md-3">
            <div class="panel panel-default">
                <h2 class="panel-heading">
                    <?php echo Dwoo_Plugin_str($this, 'currentskin', 'skin', null, null, null, null, null);?>

                </h2>

                <div class="panel-body">
                    <img class="thumbnail" src="<?php echo (is_string($tmp=$this->scope["WWWROOT"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>skin/thumb.php?id=<?php echo (is_string($tmp=$this->scope["currentskin"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>" alt="<?php echo (is_string($tmp=$this->scope["currenttitle"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>">
                    <ul class="metadata unstyled">
                        <li class="title">
                            <span class="h4 text-midtone"><?php echo (isset($this->scope["currenttitle"]) ? $this->scope["currenttitle"] : null);?></span>
                        </li>
                        <?php if ((isset($this->scope["currentmetadata"]) ? $this->scope["currentmetadata"] : null)) {
?>
                            <li class="metadisplayname">
                                <strong><?php echo Dwoo_Plugin_str($this, 'displayname', 'skin', null, null, null, null, null);?>: </strong> <?php echo clean_html((isset($this->scope["currentmetadata"]["displayname"]) ? $this->scope["currentmetadata"]["displayname"]:null));?>

                            </li>
                            <?php if ((isset($this->scope["currentmetadata"]["description"]) ? $this->scope["currentmetadata"]["description"]:null)) {
?>
                            <li class="metadescription">
                                <strong><?php echo Dwoo_Plugin_str($this, 'description', 'skin', null, null, null, null, null);?>: </strong><?php echo clean_html((isset($this->scope["currentmetadata"]["description"]) ? $this->scope["currentmetadata"]["description"]:null));?>

                            </li>
                            <?php 
}?>

                            <li class="metacreationdate">
                                <strong><?php echo Dwoo_Plugin_str($this, 'creationdate', 'skin', null, null, null, null, null);?>: </strong> <?php echo (is_string($tmp=$this->scope["currentmetadata"]["ctime"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>

                            </li>
                            <li class="metamodifieddate">
                                <strong><?php echo Dwoo_Plugin_str($this, 'modifieddate', 'skin', null, null, null, null, null);?>: </strong> <?php echo (is_string($tmp=$this->scope["currentmetadata"]["mtime"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>

                            </li>
                         <?php 
}?>

                    </ul>
                </div>

                <div class="panel-footer has-form">
                    <div class="pull-left">
                        <?php echo (isset($this->scope["form"]) ? $this->scope["form"] : null);?>

                    </div>

                    <?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["defaultskin"]) ? $this->scope["defaultskin"]:null), true) != (isset($this->scope["currentskin"]) ? $this->scope["currentskin"] : null)) {
?>
                    <span class="defaultskin pull-right">
                        <a href="<?php echo (is_string($tmp=$this->scope["WWWROOT"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>view/skin.php?id=<?php echo (is_string($tmp=$this->scope["viewid"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>&skin=<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["defaultskin"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>" class="btn btn-default btn-sm">
                            <span class="icon icon-ban text-danger left" role="presentation" aria-hidden="true"></span>
                            <?php echo $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'title',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["defaultskin"]) ? $this->scope["defaultskin"]:null), true);?>

                        </a>
                    </span>
                    <?php 
}?>

                </div>
            </div>



        </div>
        <div class="col-md-9">
            <div class="collapsible-group skins">
                <div class="panel panel-default collapsible collapsible-group first">
                    <h3 class="panel-heading">
                        <a href="#userskins" data-toggle="collapse" aria-expanded="false" aria-controls="#userskins">
                            <?php echo Dwoo_Plugin_str($this, 'userskins', 'skin', null, null, null, null, null);?>

                            <span class="icon icon-chevron-down collapse-indicator pull-right" role="presentation" aria-hidden="true"></span>
                        </a>
                    </h3>
                    <div id="userskins" class="panel-body collapse in">
                        <?php 
$_fh0_data = (is_string($tmp=(isset($this->scope["userskins"]) ? $this->scope["userskins"] : null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);
if ($this->isTraversable($_fh0_data) == true)
{
	foreach ($_fh0_data as $this->scope['skin'])
	{
/* -- foreach start output */
?>
                            <div class="skin">
                                <a href="<?php echo (is_string($tmp=$this->scope["WWWROOT"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>view/skin.php?id=<?php echo (is_string($tmp=$this->scope["viewid"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>&skin=<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["skin"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>">
                                    <img src="<?php echo (is_string($tmp=$this->scope["WWWROOT"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>skin/thumb.php?id=<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["skin"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>" class="thumbnail" width="180" alt="<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'title',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["skin"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>"/>
                                     <div class="lead text-center text-small">
                                    <?php echo $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'title',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["skin"]) ? $this->scope["skin"]:null), true);?>

                                    </div>
                                </a>
                            </div>
                        <?php 
/* -- foreach end output */
	}
}?>

                    </div>
                </div>
                <?php if ((isset($this->scope["favorskins"]) ? $this->scope["favorskins"] : null)) {
?>
                <div class="panel panel-default collapsible collapsible-group">
                    <h3 class="panel-heading">
                        <a href="#favorskins" data-toggle="collapse" aria-expanded="false" aria-controls="#favorskins" class="collapsed">
                            <?php echo Dwoo_Plugin_str($this, 'favoriteskins', 'skin', null, null, null, null, null);?>

                            <span class="icon icon-chevron-down collapse-indicator pull-right" role="presentation" aria-hidden="true"></span>
                        </a>
                    </h3>
                    <div id="favorskins" class="panel-body collapse">
                        <?php 
$_fh1_data = (is_string($tmp=(isset($this->scope["favorskins"]) ? $this->scope["favorskins"] : null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);
if ($this->isTraversable($_fh1_data) == true)
{
	foreach ($_fh1_data as $this->scope['skin'])
	{
/* -- foreach start output */
?>
                            <div class="skin">
                                <a href="<?php echo (is_string($tmp=$this->scope["WWWROOT"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>view/skin.php?id=<?php echo (is_string($tmp=$this->scope["viewid"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>&skin=<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["skin"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>">
                                    <img src="<?php echo (is_string($tmp=$this->scope["WWWROOT"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>skin/thumb.php?id=<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["skin"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>" class="thumbnail" width="180" alt="<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'title',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["skin"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>"/>
                                     <div class="lead text-center text-small">
                                    <?php echo $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'title',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["skin"]) ? $this->scope["skin"]:null), true);?>

                                    </div>
                                </a>
                            </div>
                        <?php 
/* -- foreach end output */
	}
}?>

                    </div>
                </div>
                <?php 
}?>

                <div class="panel panel-default collapsible collapsible-group last">
                    <h3 class="panel-heading">
                        <a href="#siteskins" data-toggle="collapse" aria-expanded="false" aria-controls="#siteskins" class="collapsed">
                            <?php echo Dwoo_Plugin_str($this, 'siteskins', 'skin', null, null, null, null, null);?>

                            <span class="icon icon-chevron-down collapse-indicator pull-right" role="presentation" aria-hidden="true"></span>
                        </a>
                    </h3>
                    <div id="siteskins" class="panel-body no-footer collapse">
                        <?php 
$_fh2_data = (is_string($tmp=(isset($this->scope["siteskins"]) ? $this->scope["siteskins"] : null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);
if ($this->isTraversable($_fh2_data) == true)
{
	foreach ($_fh2_data as $this->scope['skin'])
	{
/* -- foreach start output */
?>
                            <div class="skin">
                                <a href="<?php echo (is_string($tmp=$this->scope["WWWROOT"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>view/skin.php?id=<?php echo (is_string($tmp=$this->scope["viewid"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>&skin=<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["skin"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>">
                                    <img src="<?php echo (is_string($tmp=$this->scope["WWWROOT"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>skin/thumb.php?id=<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["skin"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>" class="thumbnail" width="180" alt="<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'title',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["skin"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>"/>
                                     <div class="lead text-center text-small">
                                    <?php echo $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'title',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["skin"]) ? $this->scope["skin"]:null), true);?>

                                    </div>
                                </a>
                            </div>
                        <?php 
/* -- foreach end output */
	}
}?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php echo Dwoo_Plugin_include($this, "footer.tpl", null, null, null, '_root', null);?>

<?php  /* end template body */
return $this->buffer . ob_get_clean();
?>