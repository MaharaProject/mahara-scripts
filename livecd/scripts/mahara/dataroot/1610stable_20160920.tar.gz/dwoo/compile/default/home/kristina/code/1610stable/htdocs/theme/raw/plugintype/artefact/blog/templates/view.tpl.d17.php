<?php
/* template head */
if (function_exists('Dwoo_Plugin_include')===false)
	$this->getLoader()->loadPlugin('include');
if (function_exists('Dwoo_Plugin_str')===false)
	$this->getLoader()->loadPlugin('str');
if (function_exists('Dwoo_Plugin_list_tags')===false)
	$this->getLoader()->loadPlugin('list_tags');
/* end template head */ ob_start(); /* template body */ ;
echo Dwoo_Plugin_include($this, "header.tpl", null, null, null, '_root', null);?>

<div class="btn-top-right btn-group btn-group-top">
    <a class="btn btn-default addpost" href="<?php echo (is_string($tmp=$this->scope["WWWROOT"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>artefact/blog/post.php?blog=<?php echo (is_string($tmp=$this->scope["blog"]->get('id')) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>">
        <span class="icon icon-lg icon-plus left" role="presentation" aria-hidden="true"></span>
        <?php echo Dwoo_Plugin_str($this, "addpost", "artefact.blog", null, null, null, null, null);?>

    </a>
    <?php if (! (($tmp = (isset($this->scope["blog"]) ? $this->scope["blog"] : null)) ? $tmp->get('locked') : null)) {
?>
    <a class="btn btn-default settings" href="<?php echo (is_string($tmp=$this->scope["WWWROOT"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>artefact/blog/settings/index.php?id=<?php echo (is_string($tmp=$this->scope["blog"]->get('id')) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>">
        <span class="icon icon-lg icon-cogs left" role="presentation" aria-hidden="true"></span>
        <?php echo Dwoo_Plugin_str($this, "settings", "artefact.blog", null, null, null, null, null);?>

    </a>
    <?php 
}?>

</div>
<div id="myblogs" class="myblogs view-container">
    <p id="blogdescription">
        <?php echo clean_html((($tmp = (isset($this->scope["blog"]) ? $this->scope["blog"] : null)) ? $tmp->get('description') : null));?>

    </p>
    <?php if ((($tmp = (isset($this->scope["blog"]) ? $this->scope["blog"] : null)) ? $tmp->get('tags') : null)) {
?>
    <div class="tags">
        <strong><?php echo Dwoo_Plugin_str($this, 'tags', 'mahara', null, null, null, null, null);?>:</strong> <?php echo Dwoo_Plugin_list_tags($this, (is_string($tmp=(($tmp = (isset($this->scope["blog"]) ? $this->scope["blog"] : null)) ? $tmp->get('tags') : null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp), (is_string($tmp=(($tmp = (isset($this->scope["blog"]) ? $this->scope["blog"] : null)) ? $tmp->get('owner') : null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp));?>

    </div>
    <?php 
}?>


    <?php if ((isset($this->scope["posts"]) ? $this->scope["posts"] : null)) {
?>
    <div id="postlist" class="postlist list-group list-group-lite">
        <?php echo (isset($this->scope["posts"]["tablerows"]) ? $this->scope["posts"]["tablerows"]:null);?>

    </div>
    <div id="blogpost_page_container" class="hidden"><?php echo (isset($this->scope["posts"]["pagination"]) ? $this->scope["posts"]["pagination"]:null);?></div>
    <script>
    addLoadEvent(function() {
        <?php echo (isset($this->scope["posts"]["pagination_js"]) ? $this->scope["posts"]["pagination_js"]:null);?>

        removeElementClass('blogpost_page_container', 'hidden');
        });
    </script>
    <?php 
}
else {
?>
    <div class="metadata">
        <?php echo Dwoo_Plugin_str($this, 'nopostsyet', 'artefact.blog', null, null, null, null, null);?> <?php if (! (($tmp = (isset($this->scope["blog"]) ? $this->scope["blog"] : null)) ? $tmp->get('locked') : null)) {
?><a href="<?php echo (is_string($tmp=$this->scope["WWWROOT"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>artefact/blog/post.php?blog=<?php echo (is_string($tmp=$this->scope["blog"]->get('id')) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>"><?php echo Dwoo_Plugin_str($this, 'addone', 'mahara', null, null, null, null, null);?></a><?php 
}?>

    </div>
    <?php 
}?>


    <?php if ((isset($this->scope["enablemultipleblogstext"]) ? $this->scope["enablemultipleblogstext"] : null)) {
?>
    <p class="alert alert-default">
        <?php echo Dwoo_Plugin_str($this, 'enablemultipleblogstext', 'artefact.blog', null, (is_string($tmp=(isset($this->scope["WWWROOT"]) ? $this->scope["WWWROOT"] : null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp), null, null, null);?></p>
    <?php 
}?>


    <?php if ((isset($this->scope["hiddenblogsnotification"]) ? $this->scope["hiddenblogsnotification"] : null)) {
?>
    <p class="lead text-center">
        <?php echo Dwoo_Plugin_str($this, 'hiddenblogsnotification', 'artefact.blog', null, (is_string($tmp=(isset($this->scope["WWWROOT"]) ? $this->scope["WWWROOT"] : null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp), null, null, null);?></p>
    <?php 
}?>

</div>
<?php echo Dwoo_Plugin_include($this, "footer.tpl", null, null, null, '_root', null);?>

<?php  /* end template body */
return $this->buffer . ob_get_clean();
?>