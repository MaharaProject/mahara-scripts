<?php
/* template head */
if (function_exists('Dwoo_Plugin_str')===false)
	$this->getLoader()->loadPlugin('str');
if (function_exists('Dwoo_Plugin_list_tags')===false)
	$this->getLoader()->loadPlugin('list_tags');
/* end template head */ ob_start(); /* template body */ ?><div class="panel-body flush">
    <?php echo clean_html((isset($this->scope["text"]) ? $this->scope["text"] : null));?>


    <?php if ((($tmp = (isset($this->scope["artefact"]) ? $this->scope["artefact"] : null)) ? $tmp->get('tags') : null)) {
?>
    <div class="tags">
        <strong><?php echo Dwoo_Plugin_str($this, 'tags', 'mahara', null, null, null, null, null);?>:</strong> <?php echo Dwoo_Plugin_list_tags($this, (is_string($tmp=(($tmp = (isset($this->scope["artefact"]) ? $this->scope["artefact"] : null)) ? $tmp->get('tags') : null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp), (is_string($tmp=(($tmp = (isset($this->scope["artefact"]) ? $this->scope["artefact"] : null)) ? $tmp->get('owner') : null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp));?>

    </div>
    <?php 
}?>


    <?php if ((isset($this->scope["annotationfeedbackcount"]) ? $this->scope["annotationfeedbackcount"] : null) || (isset($this->scope["annotationfeedbackcount"]) ? $this->scope["annotationfeedbackcount"] : null) == 0) {
?>
        <?php echo (isset($this->scope["annotationfeedback"]) ? $this->scope["annotationfeedback"] : null);?>

    <?php 
}?>

</div>

<?php if ((isset($this->scope["addannotationscript"]) ? $this->scope["addannotationscript"] : null)) {
?>
    <script type="application/javascript" src="<?php echo (is_string($tmp=$this->scope["addannotationscript"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>"></script>
<?php 
}?>

<?php  /* end template body */
return $this->buffer . ob_get_clean();
?>