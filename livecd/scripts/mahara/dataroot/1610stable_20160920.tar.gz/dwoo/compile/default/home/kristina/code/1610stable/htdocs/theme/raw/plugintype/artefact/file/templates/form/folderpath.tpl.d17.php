<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ;

$_fh0_data = (is_string($tmp=(isset($this->scope["path"]) ? $this->scope["path"] : null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);
$this->globals["foreach"]['path'] = array
(
	"index"		=> 0,
	"iteration"		=> 1,
	"first"		=> null,
	"last"		=> null,
	"total"		=> $this->count($_fh0_data),
);
$_fh0_glob =& $this->globals["foreach"]['path'];
if ($this->isTraversable($_fh0_data) == true)
{
	foreach ($_fh0_data as $this->scope['f'])
	{
		$_fh0_glob["first"] = (string) ($_fh0_glob["index"] === 0);
		$_fh0_glob["last"] = (string) ($_fh0_glob["iteration"] === $_fh0_glob["total"]);
/* -- foreach start output */
?>
    <?php if (! (isset($this->globals["foreach"]["path"]["first"]) ? $this->globals["foreach"]["path"]["first"]:null)) {
?>/ 

    <?php 
}?>

    
    <?php if ((isset($this->globals["foreach"]["path"]["last"]) ? $this->globals["foreach"]["path"]["last"]:null)) {
?>
        <?php echo str_shorten_text((is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'title',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["f"]) ? $this->scope["f"]:null), true)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp), 34);?>

    <?php 
}
else {
?>
        <a href="<?php echo (isset($this->scope["querybase"]) ? $this->scope["querybase"] : null);?>folder=<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["f"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);
if ((isset($this->scope["owner"]) ? $this->scope["owner"] : null)) {
?>&owner=<?php echo (is_string($tmp=$this->scope["owner"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);
if ((isset($this->scope["ownerid"]) ? $this->scope["ownerid"] : null)) {
?>&ownerid=<?php echo (is_string($tmp=$this->scope["ownerid"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);

}

}?>" class="secondary-link changefolder<?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'class',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["f"]) ? $this->scope["f"]:null), true)) {
?> <?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'class',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["f"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);

}?>">
            <?php echo str_shorten_text((is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'title',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["f"]) ? $this->scope["f"]:null), true)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp), 34);?>

        </a>
    <?php 
}?>

<?php 
/* -- foreach end output */
		$_fh0_glob["index"]+=1;
		$_fh0_glob["iteration"]+=1;
	}
}?>


<?php  /* end template body */
return $this->buffer . ob_get_clean();
?>