<?php
/* template head */
if (function_exists('Dwoo_Plugin_str')===false)
	$this->getLoader()->loadPlugin('str');
/* end template head */ ob_start(); /* template body */ ;

$_fh0_data = (is_string($tmp=(isset($this->scope["items"]) ? $this->scope["items"] : null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);
if ($this->isTraversable($_fh0_data) == true)
{
	foreach ($_fh0_data as $this->scope['item'])
	{
/* -- foreach start output */
?>
    <li class="list-group-item text-midtone">
        <a href="<?php echo (is_string($tmp=$this->scope["item"]["url"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>" class="outer-link">
            <span class="sr-only"><?php echo str_shorten_text((is_string($tmp=(isset($this->scope["item"]["name"]) ? $this->scope["item"]["name"]:null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp), 60, true);?></span>
        </a>
        <h5 class="text-inline"><?php echo str_shorten_text((is_string($tmp=(isset($this->scope["item"]["name"]) ? $this->scope["item"]["name"]:null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp), 60, true);?></h5>
        <span class="owner metadata inner-link text-small">
            <?php echo Dwoo_Plugin_str($this, 'by', 'view', null, null, null, null, null);?>

            <a href="<?php echo (is_string($tmp=$this->scope["item"]["ownerurl"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>" class="text-success text-small">
            <?php echo (is_string($tmp=$this->scope["item"]["ownername"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>

            </a>
        </span>

        <div class="detail text-small text-midtone">
            <?php echo Dwoo_Plugin_str($this, 'timeofsubmission', 'view', null, null, null, null, null);?>:
            <?php echo format_date((is_string($tmp=(isset($this->scope["item"]["submittedtime"]) ? $this->scope["item"]["submittedtime"]:null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp));?>


            <?php if ((isset($this->scope["item"]["submittedstatus"]) ? $this->scope["item"]["submittedstatus"]:null) == '2') {
?>-
            <?php echo Dwoo_Plugin_str($this, 'submittedpendingrelease', 'view', null, null, null, null, null);?>

            <?php 
}?>

        </div>

    </li>
<?php 
/* -- foreach end output */
	}
}?>

<?php  /* end template body */
return $this->buffer . ob_get_clean();
?>