<?php
/* template head */
if (function_exists('Dwoo_Plugin_include')===false)
	$this->getLoader()->loadPlugin('include');
if (function_exists('Dwoo_Plugin_str')===false)
	$this->getLoader()->loadPlugin('str');
/* end template head */ ob_start(); /* template body */ ;
echo Dwoo_Plugin_include($this, "header.tpl", null, null, null, '_root', null);?>

<div class="btn-top-right btn-group btn-group-top">
    <a class="btn btn-default settings" href="<?php echo (is_string($tmp=$this->scope["WWWROOT"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>artefact/blog/new/index.php<?php if ((isset($this->scope["institutionname"]) ? $this->scope["institutionname"] : null)) {
?>?institution=<?php echo (is_string($tmp=$this->scope["institutionname"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);

}
if ((isset($this->scope["group"]) ? $this->scope["group"] : null)) {
?>?group=<?php echo (is_string($tmp=$this->scope["group"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);

}?>">
        <span class="icon icon-lg icon-plus left" role="presentation" aria-hidden="true"></span>
        <?php echo Dwoo_Plugin_str($this, "addblog", "artefact.blog", null, null, null, null, null);?>

    </a>
</div>
<?php if (! $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'data',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["blogs"]) ? $this->scope["blogs"]:null), true)) {
?>
<p class="no-results"><?php echo Dwoo_Plugin_str($this, 'youhavenoblogs', 'artefact.blog', null, null, null, null, null);?></p>
<?php 
}
else {
?>
<div class="rel view-container">
    <div class="panel-items">
        <div id="bloglist">
            <?php echo $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'tablerows',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["blogs"]) ? $this->scope["blogs"]:null), true);?>

        </div>
        <div class="panel-pagination">
            <?php echo $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'pagination',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["blogs"]) ? $this->scope["blogs"]:null), true);?>

        </div>
    </div>
</div>
<?php 
}?>

<?php echo Dwoo_Plugin_include($this, "footer.tpl", null, null, null, '_root', null);?>

<?php  /* end template body */
return $this->buffer . ob_get_clean();
?>