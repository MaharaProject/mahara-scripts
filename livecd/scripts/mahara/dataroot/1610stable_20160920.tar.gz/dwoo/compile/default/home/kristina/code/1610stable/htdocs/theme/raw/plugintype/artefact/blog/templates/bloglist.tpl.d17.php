<?php
/* template head */
if (function_exists('Dwoo_Plugin_str')===false)
	$this->getLoader()->loadPlugin('str');
if (function_exists('Dwoo_Plugin_escape')===false)
	$this->getLoader()->loadPlugin('escape');
/* end template head */ ob_start(); /* template body */ ;

$_fh0_data = (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'data',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["blogs"]) ? $this->scope["blogs"]:null), true)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);
if ($this->isTraversable($_fh0_data) == true)
{
	foreach ($_fh0_data as $this->scope['blog'])
	{
/* -- foreach start output */
?>
<div class="panel <?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'locked',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["blog"]) ? $this->scope["blog"]:null), true)) {
?>panel-warning<?php 
}
else {
?> panel-default<?php 
}?> blog panel-half">
    <h3 class="panel-heading has-link">
        <a class="title-link title" href="<?php echo (is_string($tmp=$this->scope["WWWROOT"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>artefact/blog/view/index.php?id=<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["blog"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>">
        <?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'title',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["blog"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>

        <?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'postcount',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["blog"]) ? $this->scope["blog"]:null), true) == 0) {
?>
            <span class="metadata post-count">
                <?php echo Dwoo_Plugin_str($this, 'nopostsyet', 'artefact.blog', null, null, null, null, null);?>

            </span>
        <?php 
}
else {
?>
            <span class="metadata post-count">
                <?php echo Dwoo_Plugin_str($this, 'nposts', 'artefact.blog', null, (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'postcount',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["blog"]) ? $this->scope["blog"]:null), true)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp), null, null, null);?>

            </span>
        <?php 
}?>

         <span class="icon icon-arrow-right pull-right link-indicator" role="presentation" aria-hidden="true"></span>
        </a>
    </h3>

    <div id="blogdesc" class="panel-body">
        <a class="link-unstyled" href="<?php echo (is_string($tmp=$this->scope["WWWROOT"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>artefact/blog/view/index.php?id=<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["blog"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>">
        <?php echo clean_html($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'description',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["blog"]) ? $this->scope["blog"]:null), true));?>

        </a>
    </div>

    <div class="panel-footer has-form">
        <a href="<?php echo (is_string($tmp=$this->scope["WWWROOT"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>artefact/blog/post.php?blog=<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["blog"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>" class="btn btn-default btn-sm">
            <span class="icon icon-plus icon-lg left" role="presentation" aria-hidden="true"></span>
            <?php echo Dwoo_Plugin_str($this, 'addpost', 'artefact.blog', null, null, null, null, null);?>

        </a>
        <div class="btn-group pull-right">
            <?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'locked',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["blog"]) ? $this->scope["blog"]:null), true)) {
?>
                <span class="text-small"><?php echo Dwoo_Plugin_str($this, 'submittedforassessment', 'view', null, null, null, null, null);?></span>
            <?php 
}
else {
?>
            <a href="<?php echo (is_string($tmp=$this->scope["WWWROOT"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>artefact/blog/settings/index.php?id=<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["blog"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>" title="<?php echo Dwoo_Plugin_escape($this, Dwoo_Plugin_str($this, 'settingsspecific', 'mahara', null, $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'title',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["blog"]) ? $this->scope["blog"]:null), true), null, null, null), 'html', null);?>" class="btn btn-default btn-sm btn-group-item">
                <span class="icon icon-pencil icon-lg" role="presentation" aria-hidden="true"></span>
                <span class="sr-only"><?php echo Dwoo_Plugin_str($this, 'edit', 'mahara', null, null, null, null, null);?></span>
            </a>
            <?php echo $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'deleteform',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["blog"]) ? $this->scope["blog"]:null), true);?>

            <?php 
}?>

        </div>
    </div>
</div>
<?php 
/* -- foreach end output */
	}
}?>

<?php  /* end template body */
return $this->buffer . ob_get_clean();
?>