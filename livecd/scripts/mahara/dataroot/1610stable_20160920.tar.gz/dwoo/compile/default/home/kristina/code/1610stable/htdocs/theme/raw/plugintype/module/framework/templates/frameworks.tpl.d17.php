<?php
/* template head */
if (function_exists('Dwoo_Plugin_include')===false)
	$this->getLoader()->loadPlugin('include');
if (function_exists('Dwoo_Plugin_str')===false)
	$this->getLoader()->loadPlugin('str');
/* end template head */ ob_start(); /* template body */ ;
echo Dwoo_Plugin_include($this, "header.tpl", null, null, null, '_root', null);?>


<div class="btn-group btn-group-top only-button">
    <a class="btn btn-default btn-group-item pull-left" href="<?php echo (is_string($tmp=$this->scope["wwwroot"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>admin/extensions/pluginconfig.php?plugintype=module&pluginname=framework">
        <span class="icon icon-plus icon-lg left" role="presentation" aria-hidden="true"></span>
        <span class="btn-title"><?php echo Dwoo_Plugin_str($this, "addframework", "module.framework", null, null, null, null, null);?></span>
    </a>
</div>

<h4><?php echo Dwoo_Plugin_str($this, "frameworks", "module.framework", null, null, null, null, null);?></h4>
<p class="lead"><?php echo Dwoo_Plugin_str($this, "frameworksdesc", "module.framework", null, null, null, null, null);?></p>

<table class="listing table table-striped text-small">
<thead>
    <tr>
        <th><?php echo Dwoo_Plugin_str($this, "name", 'mahara', null, null, null, null, null);?></th>
        <th><?php echo Dwoo_Plugin_str($this, "usedincollections", "module.framework", null, null, null, null, null);?></th>
        <th><?php echo Dwoo_Plugin_str($this, "selfassess", "module.framework", null, null, null, null, null);?></th>
        <th><?php echo Dwoo_Plugin_str($this, "active", 'mahara', null, null, null, null, null);?></th>
    </tr>
</thead>
<tbody>
<?php 
$_fh0_data = (is_string($tmp=(isset($this->scope["frameworks"]) ? $this->scope["frameworks"] : null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);
if ($this->isTraversable($_fh0_data) == true)
{
	foreach ($_fh0_data as $this->scope['k']=>$this->scope['item'])
	{
/* -- foreach start output */
?>
    <tr>
        <td><?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'name',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["item"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?></td>
        <td><?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'collections',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["item"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?></td>
        <td><?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'selfassess',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["item"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?></td>
        <td class="buttonscell framework"><?php echo $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'activationswitch',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["item"]) ? $this->scope["item"]:null), true);?>

        <script type="application/javascript">
            jQuery('#framework<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["item"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>_enabled').on('change', function() {
                // save switch
                jQuery.post(config.wwwroot + 'module/framework/frameworks.json.php', jQuery('#framework<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["item"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>').serialize())
                .done(function(data) {
                    console.log(data);
                });
            });
        </script>
        <?php echo $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'delete',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["item"]) ? $this->scope["item"]:null), true);?></td>
    </tr>
<?php 
/* -- foreach end output */
	}
}?>

</tbody>
</table>

<?php echo Dwoo_Plugin_include($this, "footer.tpl", null, null, null, '_root', null);?>

<?php  /* end template body */
return $this->buffer . ob_get_clean();
?>