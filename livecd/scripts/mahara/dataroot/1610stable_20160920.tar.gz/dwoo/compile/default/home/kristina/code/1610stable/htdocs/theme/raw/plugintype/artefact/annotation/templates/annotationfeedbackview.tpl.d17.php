<?php
/* template head */
if (function_exists('Dwoo_Plugin_str')===false)
	$this->getLoader()->loadPlugin('str');
/* end template head */ ob_start(); /* template body */ ;
if (! (isset($this->scope["editing"]) ? $this->scope["editing"] : null)) {
?>
    <div id="annotationfeedbackview_<?php echo (is_string($tmp=$this->scope["blockid"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>" class="annotation-feedback">
        <?php if ((isset($this->scope["annotationfeedback"]) ? $this->scope["annotationfeedback"] : null) != 0) {
?>
            <ul id="annotationfeedbacktable_<?php echo (is_string($tmp=$this->scope["blockid"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>"class="annotationfeedbacktable flush list-group list-group-lite list-unstyled">
                <?php echo $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'tablerows',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["annotationfeedback"]) ? $this->scope["annotationfeedback"]:null), true);?>

            </ul>
            <?php echo $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'pagination',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["annotationfeedback"]) ? $this->scope["annotationfeedback"]:null), true);?>

        <?php 
}?>

        <?php if ((isset($this->scope["allowfeedback"]) ? $this->scope["allowfeedback"] : null)) {
?>
        <div class="annotationfeedback">
            <a id="feedback_<?php echo (is_string($tmp=$this->scope["blockid"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>" class="placeannotationfeedback link-blocktype last" data-toggle="modal-docked" data-target="#annotation_feedback_<?php echo (is_string($tmp=$this->scope["blockid"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>" href="#">
                <span class="icon icon-plus" role="presentation" aria-hidden="true"></span>
                <?php echo Dwoo_Plugin_str($this, 'placeannotationfeedback', 'artefact.annotation', null, null, null, null, null);?>

            </a>
        </div>
        <?php 
}?>

        <div id="annotation_feedback_<?php echo (is_string($tmp=$this->scope["blockid"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>" class="feedbacktable modal modal-docked">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <button class="close" data-dismiss="modal-docked">
                            <span class="times">&times;</span>
                            <span class="sr-only"><?php echo Dwoo_Plugin_str($this, 'Close', 'mahara', null, null, null, null, null);?></span>
                        </button>
                        <h4 class="modal-title">
                            <span class="icon icon-lg icon-annotation" role="presentation" aria-hidden="true"></span>
                            <?php echo Dwoo_Plugin_str($this, 'placeannotationfeedback', 'artefact.annotation', null, null, null, null, null);?>

                        </h4>
                    </div>
                    <div class="modal-body">
                        <?php if ((isset($this->scope["allowfeedback"]) ? $this->scope["allowfeedback"] : null) && ! (isset($this->scope["editing"]) ? $this->scope["editing"] : null)) {
?>
                        <div id="add_annotation_feedback_<?php echo (is_string($tmp=$this->scope["blockid"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>">
                            <?php echo (isset($this->scope["addannotationfeedbackform"]) ? $this->scope["addannotationfeedbackform"] : null);?>

                        </div>
                        <?php 
}?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php 
}?>

<?php  /* end template body */
return $this->buffer . ob_get_clean();
?>