<?php
/* template head */
if (function_exists('Dwoo_Plugin_str')===false)
	$this->getLoader()->loadPlugin('str');
/* end template head */ ob_start(); /* template body */ ;
if (( count((is_string($tmp=(isset($this->scope["r"]["email"]) ? $this->scope["r"]["email"]:null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp)) == 0 )) {
?>
<div class="error">
    <?php echo Dwoo_Plugin_str($this, 'noemailfound', 'admin', null, null, null, null, null);?>

</div>
<?php 
}
else {
?>
    <?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'primary',  ),  3 =>   array (    0 => '',    1 => '',    2 => '',    3 => '',  ),), (isset($this->scope["r"]["email"]["0"]) ? $this->scope["r"]["email"]["0"]:null), true)) {
?>
    <div>
        <?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'title',  ),  3 =>   array (    0 => '',    1 => '',    2 => '',    3 => '',  ),), $this->scope["r"]["email"]["0"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);
if (( count((is_string($tmp=(isset($this->scope["r"]["email"]) ? $this->scope["r"]["email"]:null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp)) > 1 && $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'duplicated',  ),  3 =>   array (    0 => '',    1 => '',    2 => '',    3 => '',  ),), (isset($this->scope["r"]["email"]["0"]) ? $this->scope["r"]["email"]["0"]:null), true) )) {
?> *<?php 
}?>

    </div>
    <?php 
}?>

    <?php if (( count((is_string($tmp=(isset($this->scope["r"]["email"]) ? $this->scope["r"]["email"]:null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp)) > 1 )) {
?>
    <div>
      (
        <?php 
$_fh3_data = (is_string($tmp=(isset($this->scope["r"]["email"]) ? $this->scope["r"]["email"]:null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);
$this->globals["foreach"]['addr'] = array
(
	"index"		=> 0,
	"iteration"		=> 1,
	"first"		=> null,
	"last"		=> null,
	"total"		=> $this->count($_fh3_data),
);
$_fh3_glob =& $this->globals["foreach"]['addr'];
if ($this->isTraversable($_fh3_data) == true)
{
	foreach ($_fh3_data as $this->scope['e'])
	{
		$_fh3_glob["first"] = (string) ($_fh3_glob["index"] === 0);
		$_fh3_glob["last"] = (string) ($_fh3_glob["iteration"] === $_fh3_glob["total"]);
/* -- foreach start output */
?>
          <?php if (! (isset($this->globals["foreach"]["addr"]["first"]) ? $this->globals["foreach"]["addr"]["first"]:null)) {

echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'title',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["e"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);
if (( count((is_string($tmp=(isset($this->scope["r"]["email"]) ? $this->scope["r"]["email"]:null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp)) > 1 && $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'duplicated',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["e"]) ? $this->scope["e"]:null), true) )) {
?> *<?php 
}?>

          <?php if (! (isset($this->globals["foreach"]["addr"]["last"]) ? $this->globals["foreach"]["addr"]["last"]:null)) {
?>, <?php 
}?>

        <?php 
}

/* -- foreach end output */
		$_fh3_glob["index"]+=1;
		$_fh3_glob["iteration"]+=1;
	}
}?>

      )
    </div>
    <?php 
}?>

<?php 
}?>

<?php  /* end template body */
return $this->buffer . ob_get_clean();
?>