<?php
/* template head */
if (function_exists('Dwoo_Plugin_str')===false)
	$this->getLoader()->loadPlugin('str');
if (function_exists('Dwoo_Plugin_list_tags')===false)
	$this->getLoader()->loadPlugin('list_tags');
if (function_exists('Dwoo_Plugin_escape')===false)
	$this->getLoader()->loadPlugin('escape');
if (function_exists('Dwoo_Plugin_include')===false)
	$this->getLoader()->loadPlugin('include');
/* end template head */ ob_start(); /* template body */ ;
if ((isset($this->scope["filelist"]) ? $this->scope["filelist"] : null)) {
?>
<div class="filelist-container">
    <table id="<?php echo (is_string($tmp=$this->scope["prefix"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>_filelist" class="tablerenderer filelist table table-hover">
        <thead>
            <tr>
                <th class="icon-cell"></th>
                <th><?php echo Dwoo_Plugin_str($this, 'Name', 'artefact.file', null, null, null, null, null);?></th>
                <th class="hidden-xs"><?php echo Dwoo_Plugin_str($this, 'Description', 'artefact.file', null, null, null, null, null);?></th>
                <th class="filesize">
                    <?php echo Dwoo_Plugin_str($this, 'Size', 'artefact.file', null, null, null, null, null);?>

                </th>
                <?php if (! (isset($this->scope["showtags"]) ? $this->scope["showtags"] : null) && ! (isset($this->scope["editmeta"]) ? $this->scope["editmeta"] : null)) {
?>
                <th class="filedate">
                    <?php echo Dwoo_Plugin_str($this, 'Date', 'artefact.file', null, null, null, null, null);?>

                </th>
                <?php 
}?>

                <?php if (! (isset($this->scope["selectable"]) ? $this->scope["selectable"] : null)) {
?>
                <th class="right nowrap">
                </th>
                <?php 
}?>

                <?php if (( (isset($this->scope["showtags"]) ? $this->scope["showtags"] : null) && (isset($this->scope["editmeta"]) ? $this->scope["editmeta"] : null) ) || (isset($this->scope["selectable"]) ? $this->scope["selectable"] : null)) {
?>
                <th class="right nowrap"></th>
                <?php 
}?>

            </tr>
        </thead>

        <tbody>
        <?php 
$_fh1_data = (is_string($tmp=(isset($this->scope["filelist"]) ? $this->scope["filelist"] : null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);
if ($this->isTraversable($_fh1_data) == true)
{
	foreach ($_fh1_data as $this->scope['file'])
	{
/* -- foreach start output */
?>
            <?php if (! (isset($this->scope["publishing"]) ? $this->scope["publishing"] : null) || ! $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'permissions',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["file"]) ? $this->scope["file"]:null), true) || $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'can_republish',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["file"]) ? $this->scope["file"]:null), true)) {
?>
                <?php echo $this->assignInScope(1, 'publishable');?>

            <?php 
}
else {
?>
                <?php echo $this->assignInScope(0, 'publishable');?>

            <?php 
}?>


            <tr id="file:<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["file"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>" class="file-item <?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'isparent',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["file"]) ? $this->scope["file"]:null), true)) {
?> parentfolder<?php 
}
if ((isset($this->scope["highlight"]) ? $this->scope["highlight"] : null) && (isset($this->scope["highlight"]) ? $this->scope["highlight"] : null) == $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["file"]) ? $this->scope["file"]:null), true)) {
?> active<?php 
}
if ($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'artefacttype',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["file"]) ? $this->scope["file"]:null), true) == 'folder') {
?> folder<?php 
}
else {

if (! (isset($this->scope["publishable"]) ? $this->scope["publishable"] : null)) {
?> disabled <?php 
}
if ($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'artefacttype',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["file"]) ? $this->scope["file"]:null), true) == 'profileicon') {
?> profileicon<?php 
}

}
if ((isset($this->scope["edit"]) ? $this->scope["edit"] : null) == $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["file"]) ? $this->scope["file"]:null), true)) {
?> hidden<?php 
}
if ((isset($this->scope["selectable"]) ? $this->scope["selectable"] : null) && ( $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'artefacttype',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["file"]) ? $this->scope["file"]:null), true) != 'folder' || (isset($this->scope["selectfolders"]) ? $this->scope["selectfolders"] : null) ) && (isset($this->scope["publishable"]) ? $this->scope["publishable"] : null) && ! $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'isparent',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["file"]) ? $this->scope["file"]:null), true)) {
?> js-file-select <?php 
}
else {
?> no-hover<?php 
}
if ($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'locked',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["file"]) ? $this->scope["file"]:null), true)) {
?> warning<?php 
}?>" <?php if ((isset($this->scope["selectable"]) ? $this->scope["selectable"] : null) && ( $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'artefacttype',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["file"]) ? $this->scope["file"]:null), true) != 'folder' || (isset($this->scope["selectfolders"]) ? $this->scope["selectfolders"] : null) ) && (isset($this->scope["publishable"]) ? $this->scope["publishable"] : null) && ! $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'isparent',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["file"]) ? $this->scope["file"]:null), true)) {
?> data-id="<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["file"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>" data-select="select-file" <?php 
}?> <?php if (! (isset($this->scope["publishable"]) ? $this->scope["publishable"] : null) && $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'artefacttype',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["file"]) ? $this->scope["file"]:null), true) != 'folder') {
?> title="<?php echo Dwoo_Plugin_str($this, 'notpublishable', 'artefact.file', null, null, null, null, null);?>"<?php 
}?>>

            <?php echo $this->assignInScope($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'title',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["file"]) ? $this->scope["file"]:null), true), 'displaytitle');?>

            <td class="icon-cell">

                <?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'isparent',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["file"]) ? $this->scope["file"]:null), true)) {
?>
                    <?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'artefacttype',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["file"]) ? $this->scope["file"]:null), true) == 'folder') {
?>
                        <a href="<?php echo (isset($this->scope["querybase"]) ? $this->scope["querybase"] : null);?>folder=<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["file"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);
if ((isset($this->scope["owner"]) ? $this->scope["owner"] : null)) {
?>&owner=<?php echo (is_string($tmp=$this->scope["owner"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);
if ((isset($this->scope["ownerid"]) ? $this->scope["ownerid"] : null)) {
?>&ownerid=<?php echo (is_string($tmp=$this->scope["ownerid"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);

}

}?>" id="changefolder-icon:<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["file"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>" class="changefolder">
                            <span class="icon-level-up icon icon-lg text-default" role="presentation" aria-hidden="true">
                            </span>
                            <span class="sr-only">
                                <?php echo Dwoo_Plugin_str($this, 'folder', 'artefact.file', null, null, null, null, null);?>:<?php echo (is_string($tmp=$this->scope["displaytitle"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>

                            </span>
                        </a>
                    <?php 
}?>

                <?php 
}
else {
?>
                    <?php if ((isset($this->scope["editable"]) ? $this->scope["editable"] : null)) {
?>
                    <div class="icon-drag" id="drag:<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["file"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>" tabindex="0">
                        <span class="sr-only"><?php echo Dwoo_Plugin_str($this, 'clickanddragtomovefile', 'artefact.file', null, (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'title',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["file"]) ? $this->scope["file"]:null), true)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp), null, null, null);?></span>
                    <?php 
}?>

                    <?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'artefacttype',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["file"]) ? $this->scope["file"]:null), true) == 'folder') {
?>
                        <?php if ((isset($this->scope["selectable"]) ? $this->scope["selectable"] : null)) {
?>
                        <a href="<?php echo (isset($this->scope["querybase"]) ? $this->scope["querybase"] : null);?>folder=<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["file"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);
if ((isset($this->scope["owner"]) ? $this->scope["owner"] : null)) {
?>&owner=<?php echo (is_string($tmp=$this->scope["owner"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);
if ((isset($this->scope["ownerid"]) ? $this->scope["ownerid"] : null)) {
?>&ownerid=<?php echo (is_string($tmp=$this->scope["ownerid"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);

}

}?>" id="changefolder:<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["file"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>" class="changefolder" title="<?php echo Dwoo_Plugin_str($this, 'folder', 'artefact.file', null, null, null, null, null);?> <?php echo (is_string($tmp=$this->scope["displaytitle"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>">
                            <span class="icon icon-plus expand-indicator" role="presentation" aria-hidden="true"></span><span class="icon-folder-open icon icon-lg" role="presentation" aria-hidden="true"></span>
                        </a>
                        <?php 
}
else {
?>
                            <span class="icon-folder-open icon icon-lg " role="presentation" aria-hidden="true"></span>
                        <?php 
}?>

                    <?php 
}
else {
?>
                        <?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'icon',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["file"]) ? $this->scope["file"]:null), true)) {
?>
                            <img role="presentation" aria-hidden="true" src="<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'icon',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["file"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>" title="<?php echo Dwoo_Plugin_str($this, 'clickanddragtomovefile', 'artefact.file', null, (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'title',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["file"]) ? $this->scope["file"]:null), true)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp), null, null, null);?>" alt="<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'title',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["file"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>">
                        <?php 
}
else {
?>
                            <span class="icon icon-<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'artefacttype',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["file"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?> icon-lg" role="presentation" aria-hidden="true"></span>
                        <?php 
}?>

                    <?php 
}?>

                <?php 
}?>

            </td>

            <td class="filename">
                <?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'artefacttype',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["file"]) ? $this->scope["file"]:null), true) == 'folder') {
?>
                    <a href="<?php echo (isset($this->scope["querybase"]) ? $this->scope["querybase"] : null);?>folder=<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["file"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);
if ((isset($this->scope["owner"]) ? $this->scope["owner"] : null)) {
?>&owner=<?php echo (is_string($tmp=$this->scope["owner"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);
if ((isset($this->scope["ownerid"]) ? $this->scope["ownerid"] : null)) {
?>&ownerid=<?php echo (is_string($tmp=$this->scope["ownerid"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);

}

}?>" id="changefolder:<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["file"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>" class="inner-link changefolder">
                        <span class="sr-only"><?php echo Dwoo_Plugin_str($this, 'folder', 'artefact.file', null, null, null, null, null);?>:</span>
                        <span class="display-title <?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'isparent',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["file"]) ? $this->scope["file"]:null), true)) {
?>accessible-hidden<?php 
}?>"><?php echo (is_string($tmp=$this->scope["displaytitle"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?></span>
                    </a>
                <?php 
}
elseif (! (isset($this->scope["publishable"]) ? $this->scope["publishable"] : null)) {
?>
                    <span class="display-title"><?php echo (is_string($tmp=$this->scope["displaytitle"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?></span>
                <?php 
}
else {
?>
                    <a href="<?php echo (is_string($tmp=$this->scope["WWWROOT"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>artefact/file/download.php?file=<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["file"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>" title="<?php echo Dwoo_Plugin_str($this, 'downloadfile', 'artefact.file', null, (is_string($tmp=(isset($this->scope["displaytitle"]) ? $this->scope["displaytitle"] : null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp), null, null, null);?>" class="file-download-link inner-link <?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'artefacttype',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["file"]) ? $this->scope["file"]:null), true) == 'image') {
?>img-modal-preview<?php 
}?>">
                        <span class="display-title"><?php echo (is_string($tmp=$this->scope["displaytitle"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?></span>
                    </a>
                <?php 
}?>

            </td>
            <td class="filedescription hidden-xs">
                <?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'description',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["file"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>

                <?php if ((isset($this->scope["showtags"]) ? $this->scope["showtags"] : null)) {
?>
                    <?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'tags',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["file"]) ? $this->scope["file"]:null), true)) {
?>
                    <div class="tags filetags text-small">
                        <strong><?php echo Dwoo_Plugin_str($this, 'tags', 'mahara', null, null, null, null, null);?>:</strong>
                        <span>
                            <?php echo Dwoo_Plugin_list_tags($this, (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'tags',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["file"]) ? $this->scope["file"]:null), true)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp), (is_string($tmp=(isset($this->scope["showtags"]) ? $this->scope["showtags"] : null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp));?>

                        </span>
                    </div>
                    <?php 
}?>

                <?php 
}?>

            </td>

            <?php if ((isset($this->scope["showtags"]) ? $this->scope["showtags"] : null) && (isset($this->scope["editmeta"]) ? $this->scope["editmeta"] : null)) {
?>
            <td class="filesize"><?php echo (($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'size',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["file"]) ? $this->scope["file"]:null), true)) ? $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'size',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["file"]) ? $this->scope["file"]:null), true) : '');?></td>
            <?php 
}?>

            <?php if (! (isset($this->scope["showtags"]) ? $this->scope["showtags"] : null) && ! (isset($this->scope["editmeta"]) ? $this->scope["editmeta"] : null)) {
?>
            <td class="filesize"><?php echo (($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'size',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["file"]) ? $this->scope["file"]:null), true)) ? $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'size',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["file"]) ? $this->scope["file"]:null), true) : '');?></td>
            <td class="filedate"><?php echo (($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'mtime',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["file"]) ? $this->scope["file"]:null), true)) ? $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'mtime',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["file"]) ? $this->scope["file"]:null), true) : '');?></td>
            <?php 
}?>

            <?php if ((isset($this->scope["editmeta"]) ? $this->scope["editmeta"] : null) || (isset($this->scope["selectable"]) ? $this->scope["selectable"] : null)) {
?>
            <td class="right s nowrap text-right">
                <div class="btn-group">
                <?php if ((isset($this->scope["selectable"]) ? $this->scope["selectable"] : null) && ( $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'artefacttype',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["file"]) ? $this->scope["file"]:null), true) != 'folder' || (isset($this->scope["selectfolders"]) ? $this->scope["selectfolders"] : null) ) && (isset($this->scope["publishable"]) ? $this->scope["publishable"] : null) && ! $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'isparent',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["file"]) ? $this->scope["file"]:null), true)) {
?>
                    <button type="submit" class="btn btn-xs btn-default" name="<?php echo (is_string($tmp=$this->scope["prefix"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>_select[<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["file"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>]" id="<?php echo (is_string($tmp=$this->scope["prefix"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>_select_<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["file"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>" title="<?php echo Dwoo_Plugin_str($this, 'select', 'mahara', null, null, null, null, null);?>">
                        <span class="icon icon-check icon-lg" role="presentation" aria-hidden="true"></span>
                        <span class="sr-only"><?php echo Dwoo_Plugin_str($this, 'select', 'mahara', null, null, null, null, null);?></span>
                    </button>
                <?php 
}?>

                <?php if ((isset($this->scope["editmeta"]) ? $this->scope["editmeta"] : null)) {
?>
                    <?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'locked',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["file"]) ? $this->scope["file"]:null), true)) {
?>
                        <span class="dull text-muted"><?php echo Dwoo_Plugin_str($this, 'Submitted', 'view', null, null, null, null, null);?></span>
                    <?php 
}
elseif (! $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'isparent',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["file"]) ? $this->scope["file"]:null), true)) {
?>
                        <?php if (! ((is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'can_edit',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["file"]) ? $this->scope["file"]:null), true)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp) !== null) || $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'can_edit',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["file"]) ? $this->scope["file"]:null), true) !== 0) {
?>
                        <button name="<?php echo (is_string($tmp=$this->scope["prefix"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>_edit[<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["file"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>]" class="btn btn-default btn-xs" title="<?php echo Dwoo_Plugin_str($this, 'edit', 'mahara', null, null, null, null, null);?>">
                            <span class="icon icon-pencil icon-lg" role="presentation" aria-hidden="true"></span>
                            <span class="sr-only"><?php echo Dwoo_Plugin_escape($this, (isset($this->scope["edittext"]) ? $this->scope["edittext"] : null), 'html', null);?></span>
                        </button>
                        <?php 
}?>

                    <?php 
}?>

                <?php 
}?>

                </div>
            </td>
            <?php 
}?>

            <!-- Ensure space for 3 buttons (in the case of a really long single line string in a user input field -->
            <?php if ((isset($this->scope["editable"]) ? $this->scope["editable"] : null) && ! $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'isparent',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["file"]) ? $this->scope["file"]:null), true)) {
?>
            <td class="text-right control-buttons <?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'artefacttype',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["file"]) ? $this->scope["file"]:null), true) == 'archive') {
?>includes-unzip<?php 
}?>">
                <?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'locked',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["file"]) ? $this->scope["file"]:null), true)) {
?>
                    <span class="dull text-muted">
                        <?php echo Dwoo_Plugin_str($this, 'Submitted', 'view', null, null, null, null, null);?>

                    </span>
                <?php 
}
elseif (! ((is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'can_edit',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["file"]) ? $this->scope["file"]:null), true)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp) !== null) || $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'can_edit',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["file"]) ? $this->scope["file"]:null), true) != 0) {
?>
                    <div class="btn-group">
                        <?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'artefacttype',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["file"]) ? $this->scope["file"]:null), true) == 'archive') {
?>
                        <a href="<?php echo (is_string($tmp=$this->scope["WWWROOT"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>artefact/file/extract.php?file=<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["file"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>" title="<?php echo Dwoo_Plugin_str($this, 'Decompress', 'artefact.file', null, null, null, null, null);?>" class="btn btn-default btn-xs">
                            <span class="icon icon-file-archive-o icon-lg" role="presentation" aria-hidden="true"></span>
                            <span class="sr-only">
                                <?php echo Dwoo_Plugin_escape($this, Dwoo_Plugin_str($this, 'decompressspecific', 'artefact.file', null, (isset($this->scope["displaytitle"]) ? $this->scope["displaytitle"] : null), null, null, null), 'html', null);?>

                            </span>
                        </a>
                        <?php 
}?>


                        <?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'artefacttype',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["file"]) ? $this->scope["file"]:null), true) == 'folder') {
?>
                            <?php echo $this->assignInScope(Dwoo_Plugin_str($this, 'editfolderspecific', 'artefact.file', null, (is_string($tmp=(isset($this->scope["displaytitle"]) ? $this->scope["displaytitle"] : null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp), null, null, null), 'edittext');?>

                            <?php echo $this->assignInScope(Dwoo_Plugin_str($this, 'deletefolderspecific', 'artefact.file', null, (is_string($tmp=(isset($this->scope["displaytitle"]) ? $this->scope["displaytitle"] : null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp), null, null, null), 'deletetext');?>

                        <?php 
}
else {
?>
                            <?php echo $this->assignInScope(Dwoo_Plugin_str($this, 'editspecific', 'mahara', null, (is_string($tmp=(isset($this->scope["displaytitle"]) ? $this->scope["displaytitle"] : null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp), null, null, null), 'edittext');?>

                            <?php echo $this->assignInScope(Dwoo_Plugin_str($this, 'deletespecific', 'mahara', null, (is_string($tmp=(isset($this->scope["displaytitle"]) ? $this->scope["displaytitle"] : null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp), null, null, null), 'deletetext');?>

                        <?php 
}?>


                        <button name="<?php echo (is_string($tmp=$this->scope["prefix"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>_edit[<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["file"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>]" class="btn btn-default btn-xs">
                            <span class="icon icon-pencil icon-lg" role="presentation" aria-hidden="true"></span>
                            <span class="sr-only"><?php echo Dwoo_Plugin_escape($this, (isset($this->scope["edittext"]) ? $this->scope["edittext"] : null), 'html', null);?></span>
                        </button>

                        <button name="<?php echo (is_string($tmp=$this->scope["prefix"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>_delete[<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["file"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>]" class="btn btn-default btn-xs">
                            <span class="icon icon-trash text-danger icon-lg" role="presentation" aria-hidden="true"></span>
                            <span class="sr-only"><?php echo Dwoo_Plugin_escape($this, (isset($this->scope["deletetext"]) ? $this->scope["deletetext"] : null), 'html', null);?></span>
                        </button>
                    </div>
                <?php 
}?>

            </td>
            <?php 
}?>

        </tr>
        <?php if ((isset($this->scope["edit"]) ? $this->scope["edit"] : null) == $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["file"]) ? $this->scope["file"]:null), true)) {
?>
            <?php echo Dwoo_Plugin_include($this, "artefact:file:form/editfile.tpl", null, null, null, '_root', null, array('prefix' => (is_string($tmp=(isset($this->scope["prefix"]) ? $this->scope["prefix"] : null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp), 'fileinfo' => (is_string($tmp=(isset($this->scope["file"]) ? $this->scope["file"] : null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp), 'groupinfo' => (is_string($tmp=(isset($this->scope["groupinfo"]) ? $this->scope["groupinfo"] : null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp)));?>

        <?php 
}?>


        <?php 
/* -- foreach end output */
	}
}?>

        </tbody>
    </table>
</div>
<?php if (! (isset($this->scope["selectable"]) ? $this->scope["selectable"] : null) && (isset($this->scope["downloadfolderaszip"]) ? $this->scope["downloadfolderaszip"] : null)) {
?>
    <a id="downloadfolder" class="panel-footer text-small" href="<?php echo (is_string($tmp=$this->scope["WWWROOT"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>artefact/file/downloadfolder.php?<?php echo (isset($this->scope["folderparams"]) ? $this->scope["folderparams"] : null);?>">
        <span class="icon icon-download" role="presentation" aria-hidden="true"></span>
        <span><?php echo Dwoo_Plugin_str($this, 'downloadfolderziplink', 'artefact.file', null, null, null, null, null);?></span>
    </a>
<?php 
}?>


<?php 
}
else {
?>
<div class="panel-body">
    <p class="no-results">
        <?php echo Dwoo_Plugin_str($this, 'nofilesfound', 'artefact.file', null, null, null, null, null);?>

    </p>
</div>
<?php 
}?>

<?php  /* end template body */
return $this->buffer . ob_get_clean();
?>