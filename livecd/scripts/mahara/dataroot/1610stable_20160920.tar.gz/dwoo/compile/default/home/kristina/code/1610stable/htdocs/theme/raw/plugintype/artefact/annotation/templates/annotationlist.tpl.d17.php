<?php
/* template head */
if (function_exists('Dwoo_Plugin_profile_icon_url')===false)
	$this->getLoader()->loadPlugin('profile_icon_url');
if (function_exists('Dwoo_Plugin_display_default_name')===false)
	$this->getLoader()->loadPlugin('display_default_name');
if (function_exists('Dwoo_Plugin_str')===false)
	$this->getLoader()->loadPlugin('str');
if (function_exists('Dwoo_Plugin_display_name')===false)
	$this->getLoader()->loadPlugin('display_name');
/* end template head */ ob_start(); /* template body */ ;

$_fh0_data = (is_string($tmp=(isset($this->scope["data"]) ? $this->scope["data"] : null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);
if ($this->isTraversable($_fh0_data) == true)
{
	foreach ($_fh0_data as $this->scope['item'])
	{
/* -- foreach start output */
?>
<li class="<?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'highlight',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["item"]) ? $this->scope["item"]:null), true)) {
?> list-group-item-warning<?php 
}
if ($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'makepublicform',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["item"]) ? $this->scope["item"]:null), true)) {
?> list-group-item-warning<?php 
}?> list-group-item">
    <div class="usericon-heading">
        <span class="user-icon small-icon pull-left" role="presentation" aria-hidden="true">
            <?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'author',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["item"]) ? $this->scope["item"]:null), true)) {
?>
                <img src="<?php echo Dwoo_Plugin_profile_icon_url($this, (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'author',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["item"]) ? $this->scope["item"]:null), true)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp), 25, 25);?>" alt="<?php echo Dwoo_Plugin_str($this, 'profileimagetext', 'mahara', null, Dwoo_Plugin_display_default_name($this, (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'author',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["item"]) ? $this->scope["item"]:null), true)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp)), null, null, null);?>">
            <?php 
}
else {
?>
                <img src="<?php echo Dwoo_Plugin_profile_icon_url($this, null, 20, 20);?>" alt="<?php echo Dwoo_Plugin_str($this, 'profileimagetextanonymous', 'mahara', null, null, null, null, null);?>">
            <?php 
}?>

        </span>
        <h5 class="list-group-item-heading pull-left">
            <?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'author',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["item"]) ? $this->scope["item"]:null), true)) {
?>
            <a href="<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',    1 => '->',  ),  2 =>   array (    0 => 'author',    1 => 'profileurl',  ),  3 =>   array (    0 => '',    1 => '',    2 => '',  ),), $this->scope["item"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>">
            <?php 
}?>

                <span><?php echo Dwoo_Plugin_display_name($this, (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'author',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["item"]) ? $this->scope["item"]:null), true)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp), null, false, false);?></span>
            <?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'author',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["item"]) ? $this->scope["item"]:null), true)) {
?>
            </a>
            <?php 
}?>


            <br />

            <span class="postedon text-small">
            <?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'date',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["item"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>

            <?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'updated',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["item"]) ? $this->scope["item"]:null), true)) {
?>
                [<?php echo Dwoo_Plugin_str($this, 'Updated', 'mahara', null, null, null, null, null);?>: <?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'updated',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["item"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>]
            <?php 
}?>

            </span>
        </h5>
        <div class="btn-group btn-group-top">
            <?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'deleteform',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["item"]) ? $this->scope["item"]:null), true)) {
?>
                <?php echo $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'deleteform',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["item"]) ? $this->scope["item"]:null), true);?>

            <?php 
}?>

            <?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'canedit',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["item"]) ? $this->scope["item"]:null), true)) {
?>
            <a href="<?php echo (is_string($tmp=$this->scope["WWWROOT"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>artefact/annotation/edit.php?id=<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'id',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["item"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>&amp;viewid=<?php echo (is_string($tmp=$this->scope["viewid"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>" class="btn btn-default pull-left">
                <span class="icon icon-lg icon-pencil text-default" role="presentation" aria-hidden="true"></span>
                <span class="sr-only"><?php echo Dwoo_Plugin_str($this, 'edit', 'mahara', null, null, null, null, null);?></span>
            </a>
            <?php 
}?>

        </div>
    </div>

    <?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'deletedmessage',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["item"]) ? $this->scope["item"]:null), true)) {
?>
        <div class="metadata content-text">
            <?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'deletedmessage',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["item"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>

        </div>
    <?php 
}
else {
?>
        <div class="content-text">
            <?php echo clean_html($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'description',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["item"]) ? $this->scope["item"]:null), true));?>

        </div>

        <?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'attachmessage',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["item"]) ? $this->scope["item"]:null), true)) {
?>
        <div class="attachmessage">
            <?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'attachmessage',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["item"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>

        </div>
        <?php 
}?>


        <div class="metadata">
            <?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'pubmessage',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["item"]) ? $this->scope["item"]:null), true)) {
?>
            <em class="privatemessage">
                <?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'pubmessage',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["item"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?> -
            </em>
            <?php 
}?>


            <?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'makepublicform',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["item"]) ? $this->scope["item"]:null), true)) {
?>
                <?php echo $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'makepublicform',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["item"]) ? $this->scope["item"]:null), true);?>

            <?php 
}?>


            <?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'makepublicrequested',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["item"]) ? $this->scope["item"]:null), true)) {
?>
            <span class="icon icon-lock text-default left" role="presentation" aria-hidden="true"></span>
            <?php 
}?>

        </div>
    <?php 
}?>

</li>
<?php 
/* -- foreach end output */
	}
}?>

<?php  /* end template body */
return $this->buffer . ob_get_clean();
?>