<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?>/* <?php echo (is_string($tmp=$this->scope["view_text_font_notice"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?> */
<?php echo (isset($this->scope["view_text_font_face"]) ? $this->scope["view_text_font_face"] : null);?>

/* <?php echo (is_string($tmp=$this->scope["view_heading_font_notice"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?> */
<?php echo (isset($this->scope["view_heading_font_face"]) ? $this->scope["view_heading_font_face"] : null);?>

body {
    background-color: <?php echo (is_string($tmp=$this->scope["body_background_color"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>;
    background-image: <?php echo (isset($this->scope["body_background_image"]) ? $this->scope["body_background_image"] : null);?>;
    background-repeat: <?php echo (is_string($tmp=$this->scope["body_background_repeat"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>;
    background-attachment: <?php echo (is_string($tmp=$this->scope["body_background_attachment"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>;
    background-position: <?php echo (is_string($tmp=$this->scope["body_background_position"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>;
}

/* we want some elements to have a solid background irrespective of user settings */
body > .main-content > .row {
    background-color: #FFFFFF;
}
@media (min-width: 768px) {
    body > .main-content > .row {
        border-top-left-radius: 3px;
        border-top-right-radius: 3px;
        border-bottom-right-radius: 3px;
        border-bottom-left-radius: 3px;
        margin-bottom: 20px; /* to show the user's custom body background, if set */
    }
}
@media (max-width: 767px) {
    .main-content {
        padding-top: 0 !important;
    }
}


/** all other custom settings should be scoped to be within .user-page-content **/
/* with the exception of the page title and page description */

/* page settings (also page description) */

.user-page-content,
.user-page-content .panel .panel-body table,
.user-page-content .panel-body ul,
#view-description {
    font-family: <?php echo (isset($this->scope["view_text_font_family"]) ? $this->scope["view_text_font_family"] : null);?>;
    color: <?php echo (is_string($tmp=$this->scope["view_text_font_color"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>;
    <?php if ((isset($this->scope["view_text_font_size"]) ? $this->scope["view_text_font_size"] : null) != 'medium') {
?>
        font-size: <?php echo (is_string($tmp=$this->scope["view_text_font_size"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>;
    <?php 
}?>

}

.user-page-content pre {
    color: <?php echo (is_string($tmp=$this->scope["view_text_font_color"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>;
    <?php if ((isset($this->scope["view_text_font_size"]) ? $this->scope["view_text_font_size"] : null) != 'medium') {
?>
        font-size: <?php echo (is_string($tmp=$this->scope["view_text_font_size"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>;
    <?php 
}?>

}


/* links and headings */

.user-page-content a,
.user-page-content a:link,
.user-page-content a:visited {
    color: <?php echo (is_string($tmp=$this->scope["view_link_normal_color"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>;
    text-decoration: <?php echo (is_string($tmp=$this->scope["view_link_normal_underline"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>;
}
.user-page-content a:hover,
.user-page-content a:active {
    color: <?php echo (is_string($tmp=$this->scope["view_link_hover_color"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>;
    text-decoration: <?php echo (is_string($tmp=$this->scope["view_link_hover_underline"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>;
}
.user-page-content h1,
.user-page-content h2,
.user-page-content h3,
.user-page-content .panel-body h3,
.user-page-content h4,
.user-page-content h5,
.user-page-content h6,
.user-page-content .list-group-item-heading,
#viewh1 {
    color: <?php echo (is_string($tmp=$this->scope["view_text_heading_color"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>;
    font-family: <?php echo (isset($this->scope["view_heading_font_family"]) ? $this->scope["view_heading_font_family"] : null);?>;
    font-weight: bold;
}


/* blocks */

.user-page-content .panel .title:not(.feedtitle) {
    font-weight: bold;
    color: <?php echo (is_string($tmp=$this->scope["view_text_emphasized_color"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>;
    font-family: <?php echo (isset($this->scope["view_heading_font_family"]) ? $this->scope["view_heading_font_family"] : null);?>;
    border-color: <?php echo (is_string($tmp=$this->scope["view_text_emphasized_color"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>;
}
.user-page-content .panel .title a,
.user-page-content .panel .title a:link,
.user-page-content .panel .title a:visited,
.user-page-content .panel .title a:active {
    color: <?php echo (is_string($tmp=$this->scope["view_text_emphasized_color"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>;
    text-decoration: none;
}
.user-page-content .panel .title a:hover {
    color: <?php echo (is_string($tmp=$this->scope["view_link_hover_color"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>;
    text-decoration: none;
}
.user-page-content .link-blocktype:hover {
    background-color: transparent;
}
.user-page-content .panel {
    background-color: transparent; /* take away default white panel bg */
}


/* list groups */

.user-page-content .list-group-item {
    background-color: transparent;
}
.user-page-content .panel > .block .list-group .list-group-item {
    border-color: <?php echo (is_string($tmp=$this->scope["view_text_emphasized_color"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>;
}


/* pagination */

.user-page-content .pagination > .active > a,
.user-page-content .pagination > .active > a:focus,
.user-page-content .pagination > .active > a:hover,
.user-page-content .pagination > .active > span,
.user-page-content .pagination > .active > span:focus,
.user-page-content .pagination > .active > span:hover {
    background-color: <?php echo (is_string($tmp=$this->scope["view_link_normal_color"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>;
}


/** advanced: custom css **/

<?php echo (isset($this->scope["view_custom_css"]) ? $this->scope["view_custom_css"] : null);?>

<?php  /* end template body */
return $this->buffer . ob_get_clean();
?>