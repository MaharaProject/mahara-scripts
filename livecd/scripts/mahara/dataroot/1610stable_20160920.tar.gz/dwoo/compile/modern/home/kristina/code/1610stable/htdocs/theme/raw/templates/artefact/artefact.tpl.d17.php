<?php
/* template head */
if (function_exists('Dwoo_Plugin_include')===false)
	$this->getLoader()->loadPlugin('include');
if (function_exists('Dwoo_Plugin_str')===false)
	$this->getLoader()->loadPlugin('str');
/* end template head */ ob_start(); /* template body */ ;
echo Dwoo_Plugin_include($this, "header.tpl", null, null, null, '_root', null);?>


<div class="row">
    <div class="col-md-9">

        <?php if ((isset($this->scope["notrudeform"]) ? $this->scope["notrudeform"] : null)) {
?>
        <div class="message deletemessage alert alert-danger">
            <?php echo (isset($this->scope["notrudeform"]) ? $this->scope["notrudeform"] : null);?>

        </div>
        <?php 
}?>


        <h1 class="page-header">
            <?php if (count((is_string($tmp=(isset($this->scope["artefactpath"]) ? $this->scope["artefactpath"] : null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp)) == 0) {
?>
                <?php echo (is_string($tmp=$this->scope["artefacttitle"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>

            <?php 
}
else {
?>
                <?php 
$_fh0_data = (is_string($tmp=(isset($this->scope["artefactpath"]) ? $this->scope["artefactpath"] : null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);
if ($this->isTraversable($_fh0_data) == true)
{
	foreach ($_fh0_data as $this->scope['a'])
	{
/* -- foreach start output */
?>
                    <span class="lead text-small">
                        <a href="<?php echo (is_string($tmp=$this->scope["a"]["url"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>">
                            <?php echo (is_string($tmp=$this->scope["a"]["title"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>

                        </a> /
                    </span>
                <?php 
/* -- foreach end output */
	}
}?>

                <br>
                <span class="subsection-heading"><?php echo (is_string($tmp=$this->scope["artefacttitle"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?></span>
            <?php 
}?>

            <span class="metadata">
                | <?php echo $this->scope["view"]->display_title();?>

                <?php if ((isset($this->scope["hasfeed"]) ? $this->scope["hasfeed"] : null)) {
?>
                <a href="<?php echo (is_string($tmp=$this->scope["feedlink"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>">
                    <span class="icon-rss icon pull-right" role="presentation" aria-hidden="true"></span>
                </a>
                <?php 
}?>

            </span>
        </h1>

        <div class="btn-top-right btn-group btn-group-top pull-right">
            <?php if ((isset($this->scope["LOGGEDIN"]) ? $this->scope["LOGGEDIN"] : null)) {
?>
            <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                <span class="icon icon-ellipsis-h" role="presentation" aria-hidden="true"></span>
                <span class="sr-only"><?php echo Dwoo_Plugin_str($this, "more...", 'mahara', null, null, null, null, null);?></span>
            </button>
            <ul class="dropdown-menu dropdown-menu-right" role="menu">
                <li>
                    <a id="toggle_watchlist_link" class="watchlist" href="">

                        <?php if ((isset($this->scope["viewbeingwatched"]) ? $this->scope["viewbeingwatched"] : null)) {
?>
                            <span class="icon icon-eye-slash left" role="presentation" aria-hidden="true"></span>
                        <?php 
}
else {
?>
                            <span class="icon icon-eye left" role="presentation" aria-hidden="true"></span>
                        <?php 
}?>


                        <?php if ((isset($this->scope["artefact"]) ? $this->scope["artefact"] : null)) {
?>
                            <?php if ((isset($this->scope["viewbeingwatched"]) ? $this->scope["viewbeingwatched"] : null)) {
?>
                                <?php echo Dwoo_Plugin_str($this, 'removefromwatchlistartefact', 'view', null, (is_string($tmp=(($tmp = (isset($this->scope["view"]) ? $this->scope["view"] : null)) ? $tmp->get('title') : null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp), null, null, null);?>

                            <?php 
}
else {
?>
                                <?php echo Dwoo_Plugin_str($this, 'addtowatchlistartefact', 'view', null, (is_string($tmp=(($tmp = (isset($this->scope["view"]) ? $this->scope["view"] : null)) ? $tmp->get('title') : null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp), null, null, null);?>

                            <?php 
}?>

                        <?php 
}
else {
?>
                            <?php if ((isset($this->scope["viewbeingwatched"]) ? $this->scope["viewbeingwatched"] : null)) {
?>
                                <?php echo Dwoo_Plugin_str($this, 'removefromwatchlist', 'view', null, null, null, null, null);?>

                            <?php 
}
else {
?>
                                <?php echo Dwoo_Plugin_str($this, 'addtowatchlist', 'view', null, null, null, null, null);?>

                            <?php 
}?>

                        <?php 
}?>

                    </a>
                </li>
                <li>
                    <a id="objection_link" class="objection" href="#" data-toggle="modal" data-target="#report-form">
                        <span class="icon icon-lg icon-flag text-danger left" role="presentation" aria-hidden="true"></span>
                        <?php echo Dwoo_Plugin_str($this, 'reportobjectionablematerial', 'mahara', null, null, null, null, null);?>

                    </a>
                </li>
            <?php 
}?>

        </div>

        <div id="view" class="view-pane">
            <div id="bottom-pane" class="panel panel-secondary">
                <div id="column-container" class="no-heading view-container">
                <?php echo (isset($this->scope["artefact"]) ? $this->scope["artefact"] : null);?>

                </div>
            </div>
        </div>

        <div class="viewfooter view-container">
            <div class="comment-container">
                <?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'count',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["feedback"]) ? $this->scope["feedback"]:null), true) || (isset($this->scope["enablecomments"]) ? $this->scope["enablecomments"] : null)) {
?>
                    <h3 class="title"><?php echo Dwoo_Plugin_str($this, "Comments", "artefact.comment", null, null, null, null, null);?></h3>
                    <div id="feedbacktable" class="feedbacktable commentlist js-feedbackbase">
                        <?php echo $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'tablerows',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["feedback"]) ? $this->scope["feedback"]:null), true);?>

                    </div>
                    <?php echo $this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'pagination',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["feedback"]) ? $this->scope["feedback"]:null), true);?>

                <?php 
}?>

                <div id="viewmenu" class="view-menu">
                    <?php echo Dwoo_Plugin_include($this, "view/viewmenuartefact.tpl", null, null, null, '_root', null);?>

                </div>
            </div>

            <?php if ((isset($this->scope["LOGGEDIN"]) ? $this->scope["LOGGEDIN"] : null)) {
?>
            <div class="modal fade" id="report-form">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <h4 class="modal-title">
                                <span class="icon icon-lg icon-flag text-danger left" role="presentation" aria-hidden="true"></span>
                                <?php echo Dwoo_Plugin_str($this, 'reportobjectionablematerial', 'mahara', null, null, null, null, null);?>

                            </h4>
                        </div>
                        <div class="modal-body">
                            <?php echo (isset($this->scope["objectionform"]) ? $this->scope["objectionform"] : null);?>

                        </div>
                    </div>
                </div>
            </div>
            <?php 
}?>

        </div>
    </div>
</div>

<?php echo Dwoo_Plugin_include($this, "footer.tpl", null, null, null, '_root', null);?>

<?php  /* end template body */
return $this->buffer . ob_get_clean();
?>