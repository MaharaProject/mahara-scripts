<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ?><div class="imageblock panel-body" itemscope itemtype="http://schema.org/ImageObject">
    <div class="image">
        <a href="<?php echo (is_string($tmp=$this->scope["url"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>">
            <img src="<?php echo (is_string($tmp=$this->scope["src"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>" alt="<?php echo (is_string($tmp=$this->scope["description"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>" itemprop="contentURL">
        </a>
    </div>

    <?php if ((isset($this->scope["showdescription"]) ? $this->scope["showdescription"] : null)) {
?>
    <div class="detail" itemprop="description">
        <?php echo (is_string($tmp=$this->scope["description"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>

    </div>
    <?php 
}?>

</div>

<?php echo (isset($this->scope["comments"]) ? $this->scope["comments"] : null);?>

<?php  /* end template body */
return $this->buffer . ob_get_clean();
?>