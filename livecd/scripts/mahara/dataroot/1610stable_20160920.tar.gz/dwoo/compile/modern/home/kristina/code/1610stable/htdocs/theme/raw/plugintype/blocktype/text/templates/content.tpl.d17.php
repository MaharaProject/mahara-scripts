<?php
/* template head */
/* end template head */ ob_start(); /* template body */ ;
if ((isset($this->scope["text"]) ? $this->scope["text"] : null)) {
?>
<div class="textblock panel-body flush">
<?php echo clean_html((isset($this->scope["text"]) ? $this->scope["text"] : null));?>

</div>
<?php 
}
 /* end template body */
return $this->buffer . ob_get_clean();
?>