<?php
/* template head */
if (function_exists('Dwoo_Plugin_str')===false)
	$this->getLoader()->loadPlugin('str');
/* end template head */ ob_start(); /* template body */ ?><div id="collectionnavwrap" class="collection-nav">
    <?php if (count((is_string($tmp=(isset($this->scope["collection"]) ? $this->scope["collection"] : null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp)) > 1) {
?>
        <button type="button" class="btn btn-default prevpage invisible">
            <span class="icon left icon-chevron-left" role="presentation" aria-hidden="true"></span>
            <?php echo Dwoo_Plugin_str($this, "prevpage", "collection", null, null, null, null, null);?>

        </button>
        <button type="button" class="btn btn-default nextpage invisible">   <?php echo Dwoo_Plugin_str($this, "nextpage", "collection", null, null, null, null, null);?>

            <span class="icon right icon-chevron-right" role="presentation" aria-hidden="true"></span>
        </button>
    <?php 
}?>


    <?php if ((isset($this->scope["maintitle"]) ? $this->scope["maintitle"] : null)) {
?><h2><?php echo Dwoo_Plugin_str($this, "Collection", "collection", null, null, null, null, null);?>: <?php echo (isset($this->scope["maintitle"]) ? $this->scope["maintitle"] : null);?></h2><?php 
}?>



    <p class="navlabel"><?php echo Dwoo_Plugin_str($this, "navtopage", "collection", null, null, null, null, null);?></p>
    <nav class="custom-dropdown dropdown">
        <ul class="hidden">
            <?php 
$_fh4_data = (is_string($tmp=(isset($this->scope["collection"]) ? $this->scope["collection"] : null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);
$this->globals["foreach"]['page'] = array
(
	"index"		=> 0,
);
$_fh4_glob =& $this->globals["foreach"]['page'];
if ($this->isTraversable($_fh4_data) == true)
{
	foreach ($_fh4_data as $this->scope['view'])
	{
/* -- foreach start output */
?>
            <li>
                <?php if ($this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'view',  ),  3 =>   array (    0 => '',    1 => '',  ),), (isset($this->scope["view"]) ? $this->scope["view"]:null), true) == (isset($this->scope["viewid"]) ? $this->scope["viewid"] : null)) {
?>
                    <?php $this->scope["currentindex"]=(isset($this->globals["foreach"]["page"]["index"]) ? $this->globals["foreach"]["page"]["index"]:null)?>

                    <span data-index="<?php echo (is_string($tmp=$this->globals["foreach"]["page"]["index"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>" data-location="<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'fullurl',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["view"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>"><?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'title',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["view"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?></span>
                <?php 
}
else {
?>
                    <a href="<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'fullurl',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["view"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>" data-index="<?php echo (is_string($tmp=$this->globals["foreach"]["page"]["index"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>" data-location="<?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'fullurl',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["view"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>"><?php echo (is_string($tmp=$this->readVarInto(array (  1 =>   array (    0 => '->',  ),  2 =>   array (    0 => 'title',  ),  3 =>   array (    0 => '',    1 => '',  ),), $this->scope["view"], false)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?></a>
                <?php 
}?>

            </li>
            <?php 
/* -- foreach end output */
		$_fh4_glob["index"]+=1;
	}
}?>

        </ul>
        <span class="picker form-control"><?php echo Dwoo_Plugin_str($this, "viewingpage", "collection", null, null, null, null, null);?><span id="currentindex" data-currentindex="<?php echo (is_string($tmp=$this->scope["currentindex"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp);?>"><?php echo (is_string($tmp=$this->scope["currentindex"]) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp)+1;?></span>/<?php echo count((is_string($tmp=(isset($this->scope["collection"]) ? $this->scope["collection"] : null)) ? htmlspecialchars($tmp, ENT_QUOTES, $this->charset) : $tmp));?></span>
    </nav>
</div>
<?php  /* end template body */
return $this->buffer . ob_get_clean();
?>